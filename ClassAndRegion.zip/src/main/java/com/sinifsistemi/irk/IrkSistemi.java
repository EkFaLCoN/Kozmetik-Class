/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.irk;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.AreaEffectCloudApplyEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.Inventory;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * IRK SISTEMI
 *
 * - Sinif secildikten SONRA irk secim ekrani acilir (tek seferlik).
 * - Ayni irktan oyuncular birbirine HICBIR sekilde zarar veremez
 *   (yakin dovus, ok, mizrak, iksir, patlama, ates...).
 *   Arena dunyalari, arena bolgeleri ve duello izni bunun disindadir.
 * - Irk pasifleri SINIF yeteneklerinin UZERINE eklenir; ayri attribute
 *   anahtarlari kullanildigi icin sinif modifier'larini ezmez.
 * - Oyuncunun ismi irk renginde gorunur ve yaninda irk bayragi tasir
 *   (tab listesi, bas ustu isim ve sohbet).
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class IrkSistemi implements Listener {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final DateTimeFormatter BICIM = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;

    // Veri
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Irk> onbellek = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, String> tarihler = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private File dosya;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private FileConfiguration veri;

    // Menu akisi
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Long> sonUyari = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Long> sonAcilis = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Set<UUID> menusuAcik = new HashSet<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final long ACILIS_ARALIGI = 1500L;

    // Duello / arena gecici izinleri
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Set<String> duelloIzinleri = new HashSet<>();

    // Pasif attribute
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<String, NamespacedKey> anahtarlar = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Attribute HAREKET_HIZI;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask gorev;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask skorGorevi;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public IrkSistemi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
        this.HAREKET_HIZI = coz("MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Field alan = Attribute.class.getField(ad);
                if (alan.get(null) instanceof Attribute a) {
                    return a;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // sonraki aday
            }
        }
        eklenti.getLogger().warning("Irk: hareket hizi attribute'u bulunamadi.");
        return null;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private NamespacedKey anahtar(String ad) {
        return anahtarlar.computeIfAbsent(ad, a -> new NamespacedKey(eklenti, "irk_" + a));
    }

    // ================= Yasam dongusu =================

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void baslat() {
        yukle();
        takimlariKur();
        Bukkit.getPluginManager().registerEvents(this, eklenti);

        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                menuDenetimi(oyuncu);
                pasifUygula(oyuncu);
            }
        }, 40L, 20L);

        skorKur();
        skorGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, this::skorlariYaz, 20L, 10L);

        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            gorunumGuncelle(oyuncu);
        }
        eklenti.getLogger().info("Irk sistemi etkin. " + onbellek.size() + " kayit yuklendi.");
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void durdur() {
        if (skorGorevi != null) {
            skorGorevi.cancel();
            skorGorevi = null;
        }
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            pasifTemizle(oyuncu);
        }
        kaydet();
    }

    // ================= Veri =================

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void yukle() {
        onbellek.clear();
        tarihler.clear();
        dosya = new File(eklenti.getDataFolder(), "irklar.yml");
        if (!dosya.exists()) {
            try {
                if (!eklenti.getDataFolder().exists()) {
                    eklenti.getDataFolder().mkdirs();
                }
                dosya.createNewFile();
            } catch (IOException hata) {
                eklenti.getLogger().warning("irklar.yml olusturulamadi: " + hata.getMessage());
            }
        }
        veri = YamlConfiguration.loadConfiguration(dosya);

        if (veri.isConfigurationSection("oyuncular")) {
            for (String anahtarAdi : veri.getConfigurationSection("oyuncular").getKeys(false)) {
                try {
                    UUID kimlik = UUID.fromString(anahtarAdi);
                    Irk irk = Irk.bul(veri.getString("oyuncular." + anahtarAdi + ".irk"));
                    if (irk != null) {
                        onbellek.put(kimlik, irk);
                        tarihler.put(kimlik, veri.getString("oyuncular." + anahtarAdi + ".tarih", "-"));
                    }
                } catch (IllegalArgumentException yoksay) {
                    eklenti.getLogger().warning("Gecersiz UUID atlandi: " + anahtarAdi);
                }
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kaydet() {
        if (veri == null || dosya == null) {
            return;
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().warning("irklar.yml kaydedilemedi: " + hata.getMessage());
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Irk getIrk(Player oyuncu) {
        return oyuncu == null ? null : onbellek.get(oyuncu.getUniqueId());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Irk getIrk(UUID kimlik) {
        return onbellek.get(kimlik);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String getTarih(UUID kimlik) {
        return tarihler.getOrDefault(kimlik, "-");
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean irkiVar(Player oyuncu) {
        return getIrk(oyuncu) != null;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void ayarla(UUID kimlik, String ad, Irk irk) {
        String tarih = LocalDateTime.now().format(BICIM);
        onbellek.put(kimlik, irk);
        tarihler.put(kimlik, tarih);
        veri.set("oyuncular." + kimlik + ".ad", ad);
        veri.set("oyuncular." + kimlik + ".irk", irk.kod());
        veri.set("oyuncular." + kimlik + ".tarih", tarih);
        kaydet();

        Player oyuncu = Bukkit.getPlayer(kimlik);
        if (oyuncu != null) {
            pasifYenidenUygula(oyuncu);
            gorunumGuncelle(oyuncu);
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void sifirla(UUID kimlik) {
        onbellek.remove(kimlik);
        tarihler.remove(kimlik);
        veri.set("oyuncular." + kimlik, null);
        kaydet();

        Player oyuncu = Bukkit.getPlayer(kimlik);
        if (oyuncu != null) {
            pasifTemizle(oyuncu);
            gorunumGuncelle(oyuncu);
            menuyuTazele(oyuncu);
        }
    }

    // ================= Gorunum: isim rengi + bayrak =================

    /** Config'ten bayrak simgesini okur (varsayilan ⚑). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String bayrak(Irk irk) {
        String simge = eklenti.getConfig().getString("irk.bayrak-simgesi", "⚑");
        return irk.basitRenkliAd().replace(irk.ad(), simge);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private String takimAdi(Irk irk) {
        return "irk_" + irk.kod();
    }

    /** Her irk icin scoreboard takimi kurar: renk + bayrak oneki. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void takimlariKur() {
        Scoreboard tahta = Bukkit.getScoreboardManager().getMainScoreboard();
        String simge = eklenti.getConfig().getString("irk.bayrak-simgesi", "⚑");

        for (Irk irk : Irk.values()) {
            Team takim = tahta.getTeam(takimAdi(irk));
            if (takim == null) {
                takim = tahta.registerNewTeam(takimAdi(irk));
            }
            NamedTextColor renk = irk == Irk.EMBERON ? NamedTextColor.RED : NamedTextColor.AQUA;

            takim.color(renk);
            takim.prefix(MiniMessage.miniMessage()
                    .deserialize(irk.basitRenkliAd().replace(irk.ad(), simge) + " "));
            // Vanilla dostu ates kapali; asil kontrol olay tabanlidir
            takim.setAllowFriendlyFire(false);
            takim.setCanSeeFriendlyInvisibles(true);
        }
    }

    /** Oyuncuyu irk takimina yazar; isim rengi ve bayragi buradan gelir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void gorunumGuncelle(Player oyuncu) {
        if (!eklenti.getConfig().getBoolean("irk.isim-rengi", true)) {
            return;
        }
        Scoreboard tahta = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Irk irk : Irk.values()) {
            Team takim = tahta.getTeam(takimAdi(irk));
            if (takim != null) {
                takim.removeEntry(oyuncu.getName());
            }
        }
        Irk irk = getIrk(oyuncu);
        if (irk == null) {
            return;
        }
        Team takim = tahta.getTeam(takimAdi(irk));
        if (takim != null) {
            takim.addEntry(oyuncu.getName());
        }
    }

    /** Sohbette gosterilecek onek: bayrak + renkli isim. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Component sohbetOneki(Player oyuncu) {
        Irk irk = getIrk(oyuncu);
        if (irk == null) {
            return Component.text(oyuncu.getName());
        }
        String simge = eklenti.getConfig().getString("irk.bayrak-simgesi", "⚑");
        return Mesaj.ayristir(irk.basitRenkliAd().replace(irk.ad(), simge)
                + " " + irk.renk() + oyuncu.getName());
    }

    // ================= Pasifler (sinifin UZERINE eklenir) =================

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void pasifYenidenUygula(Player oyuncu) {
        pasifTemizle(oyuncu);
        pasifUygula(oyuncu);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void pasifUygula(Player oyuncu) {
        Irk irk = getIrk(oyuncu);
        if (irk != Irk.RHODAR || HAREKET_HIZI == null) {
            return;
        }
        double oran = eklenti.getConfig().getDouble("irk.rhodar.hareket-hizi-yuzde", 0.06);
        if (oran == 0.0 || modifierVar(oyuncu, "rhodar_hiz")) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(HAREKET_HIZI);
            if (ornek == null) {
                return;
            }
            ornek.addModifier(new AttributeModifier(anahtar("rhodar_hiz"), oran,
                    AttributeModifier.Operation.ADD_SCALAR, EquipmentSlotGroup.ANY));
        } catch (RuntimeException | NoSuchMethodError hata) {
            eklenti.getLogger().warning("Irk pasifi uygulanamadi: " + hata.getMessage());
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void pasifTemizle(Player oyuncu) {
        if (HAREKET_HIZI == null) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(HAREKET_HIZI);
            if (ornek == null) {
                return;
            }
            // Plugin adi degisse bile eski kayitlar temizlensin diye
            // anahtarin namespace'i degil, ADI karsilastirilir.
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                NamespacedKey k = mod.getKey();
                if (k != null && k.getKey().equals("irk_rhodar_hiz")) {
                    ornek.removeModifier(mod);
                }
            }
        } catch (RuntimeException yoksay) {
            // oyuncu cikmis olabilir
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean modifierVar(Player oyuncu, String ad) {
        try {
            AttributeInstance ornek = oyuncu.getAttribute(HAREKET_HIZI);
            if (ornek == null) {
                return false;
            }
            for (AttributeModifier mod : ornek.getModifiers()) {
                NamespacedKey k = mod.getKey();
                if (k != null && k.getKey().equals("irk_" + ad)) {
                    return true;
                }
            }
        } catch (RuntimeException yoksay) {
            return false;
        }
        return false;
    }

    // ================= Ayni irk PvP korumasi =================

    /** Saldirandan sorumlu oyuncuyu bulur (ok, iksir, TNT dahil). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Player sorumlu(Entity vuran) {
        if (vuran instanceof Player oyuncu) {
            return oyuncu;
        }
        if (vuran instanceof Projectile mermi) {
            ProjectileSource kaynak = mermi.getShooter();
            if (kaynak instanceof Player oyuncu) {
                return oyuncu;
            }
        }
        if (vuran instanceof TNTPrimed tnt && tnt.getSource() instanceof Player oyuncu) {
            return oyuncu;
        }
        if (vuran instanceof AreaEffectCloud bulut
                && bulut.getSource() instanceof Player oyuncu) {
            return oyuncu;
        }
        return null;
    }

    /**
     * Bu iki oyuncu birbirine vurabilir mi?
     * Ayni irktalarsa hayir - arena/duel istisnasi yoksa.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean vurabilir(Player saldiran, Player hedef) {
        if (saldiran == null || hedef == null || saldiran.equals(hedef)) {
            return true;
        }
        Irk a = getIrk(saldiran);
        Irk b = getIrk(hedef);
        if (a == null || b == null || a != b) {
            return true;   // irksiz veya farkli irk -> serbest
        }
        return istisnaBolge(saldiran) || istisnaBolge(hedef) || duelloVar(saldiran, hedef);
    }

    // ---- Datapack koprusu: cv.irk skoru ----
    // 0 = irksiz VEYA arena/duello (datapack silahlari vurabilir), 1.. = irk (ayni deger = ayni irk)

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void skorKur() {
        Scoreboard tahta = Bukkit.getScoreboardManager().getMainScoreboard();
        if (tahta.getObjective("cv.irk") == null) {
            tahta.registerNewObjective("cv.irk", org.bukkit.scoreboard.Criteria.DUMMY,
                    net.kyori.adventure.text.Component.text("cv.irk"));
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void skorlariYaz() {
        Scoreboard tahta = Bukkit.getScoreboardManager().getMainScoreboard();
        org.bukkit.scoreboard.Objective hedef = tahta.getObjective("cv.irk");
        if (hedef == null) {
            skorKur();
            hedef = tahta.getObjective("cv.irk");
        }
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            Irk irk = getIrk(oyuncu);
            int deger = 0;
            if (irk != null && !istisnaBolge(oyuncu) && !duelloda(oyuncu)) {
                deger = irk.ordinal() + 1;
            }
            hedef.getScore(oyuncu.getName()).setScore(deger);
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean duelloda(Player oyuncu) {
        String kimlik = oyuncu.getUniqueId().toString();
        for (String satir : duelloIzinleri) {
            if (satir.contains(kimlik)) {
                return true;
            }
        }
        return false;
    }

    /** Arena dunyasi veya arena kutusu icinde mi? */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean istisnaBolge(Player oyuncu) {
        List<String> dunyalar = eklenti.getConfig().getStringList("irk.arena-dunyalari");
        if (dunyalar.contains(oyuncu.getWorld().getName())) {
            return true;
        }
        for (String satir : eklenti.getConfig().getStringList("irk.arena-bolgeleri")) {
            // bicim: dunya,x1,y1,z1,x2,y2,z2
            String[] p = satir.split(",");
            if (p.length != 7) {
                continue;
            }
            try {
                if (!oyuncu.getWorld().getName().equalsIgnoreCase(p[0].trim())) {
                    continue;
                }
                double x1 = Math.min(Double.parseDouble(p[1]), Double.parseDouble(p[4]));
                double y1 = Math.min(Double.parseDouble(p[2]), Double.parseDouble(p[5]));
                double z1 = Math.min(Double.parseDouble(p[3]), Double.parseDouble(p[6]));
                double x2 = Math.max(Double.parseDouble(p[1]), Double.parseDouble(p[4]));
                double y2 = Math.max(Double.parseDouble(p[2]), Double.parseDouble(p[5]));
                double z2 = Math.max(Double.parseDouble(p[3]), Double.parseDouble(p[6]));
                var k = oyuncu.getLocation();
                if (k.getX() >= x1 && k.getX() <= x2
                        && k.getY() >= y1 && k.getY() <= y2
                        && k.getZ() >= z1 && k.getZ() <= z2) {
                    return true;
                }
            } catch (NumberFormatException yoksay) {
                eklenti.getLogger().warning("Gecersiz arena bolgesi: " + satir);
            }
        }
        return false;
    }

    // ---- Duello API'si (duello eklentin bunu cagirir) ----

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private String ciftAnahtari(UUID a, UUID b) {
        return a.compareTo(b) < 0 ? a + ":" + b : b + ":" + a;
    }

    /** Iki oyuncunun ayni irktan olsalar bile vurusmasina izin verir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void duelloIzniVer(UUID a, UUID b) {
        duelloIzinleri.add(ciftAnahtari(a, b));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void duelloIzniKaldir(UUID a, UUID b) {
        duelloIzinleri.remove(ciftAnahtari(a, b));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean duelloVar(Player a, Player b) {
        return duelloIzinleri.contains(ciftAnahtari(a.getUniqueId(), b.getUniqueId()));
    }

    // ---- Olaylar ----

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void hasar(EntityDamageByEntityEvent olay) {
        if (!(olay.getEntity() instanceof Player hedef)) {
            return;
        }
        Player saldiran = sorumlu(olay.getDamager());
        if (saldiran == null) {
            return;
        }

        if (!vurabilir(saldiran, hedef)) {
            olay.setCancelled(true);
            uyarPvp(saldiran, hedef);
            return;
        }

        // EMBERON pasifi: yakin dovusten alinan hasar azalir
        if (getIrk(hedef) == Irk.EMBERON && olay.getDamager() instanceof Player) {
            double carpan = eklenti.getConfig()
                    .getDouble("irk.emberon.alinan-yakin-dovus-carpani", 0.92);
            olay.setDamage(olay.getDamage() * carpan);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void yanma(EntityCombustByEntityEvent olay) {
        if (!(olay.getEntity() instanceof Player hedef)) {
            return;
        }
        Player saldiran = sorumlu(olay.getCombuster());
        if (saldiran != null && !vurabilir(saldiran, hedef)) {
            olay.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void iksir(PotionSplashEvent olay) {
        Player atan = sorumlu(olay.getPotion());
        if (atan == null) {
            return;
        }
        for (LivingEntity varlik : new ArrayList<>(olay.getAffectedEntities())) {
            if (varlik instanceof Player hedef && !vurabilir(atan, hedef)) {
                olay.setIntensity(hedef, 0.0);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void bulut(AreaEffectCloudApplyEvent olay) {
        Player kaynak = sorumlu(olay.getEntity());
        if (kaynak == null) {
            return;
        }
        olay.getAffectedEntities().removeIf(
                varlik -> varlik instanceof Player hedef && !vurabilir(kaynak, hedef));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void uyarPvp(Player saldiran, Player hedef) {
        long simdi = System.currentTimeMillis();
        Long son = sonUyari.get(saldiran.getUniqueId());
        if (son != null && simdi - son < 3000L) {
            return;
        }
        sonUyari.put(saldiran.getUniqueId(), simdi);
        Irk irk = getIrk(saldiran);
        Mesaj.gonder(saldiran, "irk-ayni-taraf",
                Mesaj.degisken("irk", irk == null ? "-" : irk.basitRenkliAd(),
                        "oyuncu", hedef.getName()));
    }

    // ================= Menu akisi =================

    /** Sinifi olan ama irki olmayan oyuncuya irk menusunu acar. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void menuDenetimi(Player oyuncu) {
        if (!zorunlu(oyuncu)) {
            return;
        }
        if (menusuAcik.contains(oyuncu.getUniqueId())) {
            return;
        }
        if (oyuncu.getOpenInventory().getTopInventory().getHolder()
                instanceof IrkMenusu acikMenu) {
            if (acikMenu.getMevcutIrk() != null) {
                menuyuTazele(oyuncu);   // irki sifirlanmis, menu bayat
                return;
            }
            menusuAcik.add(oyuncu.getUniqueId());
            return;
        }
        menuAc(oyuncu, true);
    }

    /**
     * Irk secimi zorunlu mu?
     * Once SINIF secilmis olmali; sinifi yoksa once o menu cikar.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean zorunlu(Player oyuncu) {
        if (!oyuncu.isOnline() || irkiVar(oyuncu)) {
            return false;
        }
        if (!eklenti.getDepo().sinifiVar(oyuncu)) {
            return false;   // sirada once sinif var
        }
        if (eklenti.getConfig().getBoolean("irk.menu-kapatilabilir", false)) {
            return false;
        }
        return !oyuncu.hasPermission("irk.menu.muaf");
    }

    /** Oyuncu su AN itibariyla irk degistiremiyor mu? */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean kilitliMi(Player oyuncu) {
        if (getIrk(oyuncu) == null) {
            return false;
        }
        if (!eklenti.getConfig().getBoolean("irk.bir-kere-secim", true)) {
            return false;
        }
        return !oyuncu.hasPermission("irk.degistir");
    }

    /** Irk sifirlandiktan sonra ekranda duran bayat menuyu tazeler. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuyuTazele(Player oyuncu) {
        menusuAcik.remove(oyuncu.getUniqueId());
        sonAcilis.remove(oyuncu.getUniqueId());
        oyuncu.closeInventory();
        Bukkit.getScheduler().runTaskLater(eklenti, () -> {
            if (zorunlu(oyuncu)) {
                menuAc(oyuncu, false);
            }
        }, 2L);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuAc(Player oyuncu, boolean uyar) {
        long simdi = System.currentTimeMillis();
        Long son = sonAcilis.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < ACILIS_ARALIGI) {
            return;
        }
        sonAcilis.put(oyuncu.getUniqueId(), simdi);
        if (uyar) {
            Mesaj.gonder(oyuncu, "irk-secim-zorunlu");
        }
        new IrkMenusu(eklenti, this, oyuncu).ac();
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuAcildi(InventoryOpenEvent olay) {
        if (olay.getInventory().getHolder() instanceof IrkMenusu
                && olay.getPlayer() instanceof Player oyuncu) {
            menusuAcik.add(oyuncu.getUniqueId());
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuKapandi(InventoryCloseEvent olay) {
        if (!(olay.getInventory().getHolder() instanceof IrkMenusu)) {
            return;
        }
        if (!(olay.getPlayer() instanceof Player oyuncu)) {
            return;
        }
        menusuAcik.remove(oyuncu.getUniqueId());
        if (zorunlu(oyuncu)) {
            Bukkit.getScheduler().runTaskLater(eklenti, () -> {
                if (zorunlu(oyuncu)) {
                    menuAc(oyuncu, true);
                }
            }, 3L);
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuSurukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof IrkMenusu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuTiklama(InventoryClickEvent olay) {
        Inventory ust = olay.getView().getTopInventory();
        if (!(ust.getHolder() instanceof IrkMenusu menu)) {
            return;
        }
        olay.setCancelled(true);

        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        int slot = olay.getRawSlot();
        if (slot < 0 || slot >= ust.getSize()) {
            return;
        }

        Irk secilen = menu.irkSlotta(slot);
        if (secilen == null) {
            return;
        }

        // Kilit, menunun acildigi ana degil TIKLAMA anina gore hesaplanir;
        // aksi halde /raceadmin reset sonrasi ekranda duran eski menu
        // hala kilitli davranir ve oyuncu irk secemez.
        if (kilitliMi(oyuncu)) {
            Irk mevcut = getIrk(oyuncu);
            Mesaj.gonder(oyuncu, "irk-zaten-var",
                    Mesaj.degisken("irk", mevcut == null ? "-" : mevcut.basitRenkliAd()));
            oyuncu.playSound(oyuncu.getLocation(), "entity.villager.no", 1.0f, 0.8f);
            oyuncu.closeInventory();
            return;
        }
        if (getIrk(oyuncu) == secilen) {
            return;
        }

        ayarla(oyuncu.getUniqueId(), oyuncu.getName(), secilen);
        oyuncu.closeInventory();
        oyuncu.playSound(oyuncu.getLocation(), "ui.toast.challenge_complete", 1.0f, 1.0f);

        Mesaj.gonder(oyuncu, "irk-secildi", Mesaj.degisken("irk", secilen.renkliAd()));
        oyuncu.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
        oyuncu.sendMessage(Mesaj.ayristir(" " + bayrak(secilen) + " " + secilen.renkliAd()));
        oyuncu.sendMessage(Mesaj.ayristir(""));
        oyuncu.sendMessage(Mesaj.ayristir(" <gold><bold>" + secilen.pasifAdi()));
        for (String satir : secilen.pasifler()) {
            oyuncu.sendMessage(Mesaj.ayristir(" " + satir));
        }
        oyuncu.sendMessage(Mesaj.ayristir(""));
        oyuncu.sendMessage(Mesaj.ayristir(" <gray>Artık aynı ırktan kimseye vuramazsın."));
        oyuncu.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));

        oyuncu.showTitle(net.kyori.adventure.title.Title.title(
                Mesaj.ayristir(secilen.renkliAd()),
                Mesaj.ayristir("<gray>Safını seçtin.")));
    }

    // ================= Giris / cikis =================

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void giris(PlayerJoinEvent olay) {
        Player oyuncu = olay.getPlayer();
        Bukkit.getScheduler().runTaskLater(eklenti, () -> {
            if (!oyuncu.isOnline()) {
                return;
            }
            gorunumGuncelle(oyuncu);
            pasifUygula(oyuncu);
        }, 45L);
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void cikis(PlayerQuitEvent olay) {
        UUID kimlik = olay.getPlayer().getUniqueId();
        menusuAcik.remove(kimlik);
        sonUyari.remove(kimlik);
        sonAcilis.remove(kimlik);
        duelloIzinleri.removeIf(satir -> satir.contains(kimlik.toString()));
    }

    // ================= Yardimci =================

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public List<Player> irktakiler(Irk irk) {
        List<Player> liste = new ArrayList<>();
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            if (getIrk(oyuncu) == irk) {
                liste.add(oyuncu);
            }
        }
        return liste;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String kodListesi() {
        StringBuilder sb = new StringBuilder();
        for (Irk irk : Irk.values()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(irk.kod().toLowerCase(Locale.ROOT));
        }
        return sb.toString();
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
