/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.irk;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Irk secim ekrani. Sinif secildikten SONRA acilir.
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class IrkMenusu implements InventoryHolder {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final IrkSistemi sistem;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Player oyuncu;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Irk mevcut;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final boolean kilitli;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<Integer, Irk> slotlar = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Inventory envanter;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public IrkMenusu(SinifSistemi eklenti, IrkSistemi sistem, Player oyuncu) {
        this.eklenti = eklenti;
        this.sistem = sistem;
        this.oyuncu = oyuncu;
        this.mevcut = sistem.getIrk(oyuncu);
        boolean birKere = eklenti.getConfig().getBoolean("irk.bir-kere-secim", true);
        this.kilitli = mevcut != null && birKere && !oyuncu.hasPermission("irk.degistir");
        olustur();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void olustur() {
        int satir = Math.max(3, Math.min(6, eklenti.getConfig().getInt("irk.menu-satir-sayisi", 5)));
        String baslik = eklenti.getConfig().getString("irk.menu-baslik",
                "<dark_gray>» <gradient:#FF6B4A:#6BC4FF><bold>IRKINI SEÇ</bold></gradient> <dark_gray>«");

        envanter = Bukkit.createInventory(this, satir * 9, Mesaj.ayristir(baslik));

        Material dolguMat = materyal(
                eklenti.getConfig().getString("irk.dolgu-materyali", "GRAY_STAINED_GLASS_PANE"),
                Material.GRAY_STAINED_GLASS_PANE);
        ItemStack dolgu = new ItemStack(dolguMat);
        ItemMeta dolguMeta = dolgu.getItemMeta();
        dolguMeta.displayName(Component.empty());
        dolgu.setItemMeta(dolguMeta);
        for (int i = 0; i < envanter.getSize(); i++) {
            envanter.setItem(i, dolgu);
        }

        // Iki irk: orta satirda simetrik yerlestirilir
        Irk[] irklar = Irk.values();
        int ortaSatir = (satir / 2) * 9;
        int[] hedefSlotlar = {ortaSatir + 2, ortaSatir + 6};

        for (int i = 0; i < irklar.length && i < hedefSlotlar.length; i++) {
            int slot = hedefSlotlar[i];
            if (slot >= envanter.getSize()) {
                continue;
            }
            slotlar.put(slot, irklar[i]);
            envanter.setItem(slot, irkEsyasi(irklar[i]));
        }

        envanter.setItem(ortaSatir + 4, bilgiEsyasi());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private ItemStack irkEsyasi(Irk irk) {
        ItemStack esya = new ItemStack(irk.ikon());
        ItemMeta meta = esya.getItemMeta();
        meta.displayName(Mesaj.esya(irk.renkliAd()));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (String satir : irk.aciklama()) {
            lore.add(Mesaj.esya(satir));
        }
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<gold><bold>" + irk.pasifAdi()));
        for (String satir : irk.pasifler()) {
            lore.add(Mesaj.esya(satir));
        }
        lore.add(Mesaj.esya("<dark_gray>Bu özellik sınıf yeteneklerine <white>eklenir<dark_gray>."));
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<gray>İsmin " + irk.basitRenkliAd() + " <gray>renginde görünür"));
        lore.add(Mesaj.esya("<gray>ve yanında " + sistem.bayrak(irk) + " <gray>bayrağı taşırsın."));
        lore.add(Component.empty());

        if (mevcut == irk) {
            lore.add(Mesaj.esya("<green><bold>» MEVCUT IRKIN «"));
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        } else if (kilitli) {
            lore.add(Mesaj.esya("<red><bold>» ZATEN BİR IRKIN VAR «"));
        } else {
            lore.add(Mesaj.esya("<green><bold>» SEÇMEK İÇİN TIKLA «"));
            if (eklenti.getConfig().getBoolean("irk.bir-kere-secim", true)) {
                lore.add(Mesaj.esya("<dark_red>Bu seçim geri alınamaz!"));
            }
        }

        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        esya.setItemMeta(meta);
        return esya;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private ItemStack bilgiEsyasi() {
        ItemStack esya = new ItemStack(Material.BOOK);
        ItemMeta meta = esya.getItemMeta();
        meta.displayName(Mesaj.esya("<gold><bold>Irk Nedir?"));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<gray>Sınıfın <white>ne yaptığını<gray>, ırkın ise"));
        lore.add(Mesaj.esya("<gray><white>kimin yanında<gray> savaştığını belirler."));
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<red>⚔ <gray>Aynı ırktan oyunculara <white>vuramazsın<gray>."));
        lore.add(Mesaj.esya("<red>⚔ <gray>Farklı ırktan olan herkes <white>hedeftir<gray>."));
        lore.add(Mesaj.esya("<dark_gray>(Arena ve düello bölgeleri hariç)"));
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<gray>Irk pasifi, sınıf yeteneklerinin"));
        lore.add(Mesaj.esya("<gray><white>üzerine eklenir<gray> — birini seçmek"));
        lore.add(Mesaj.esya("<gray>diğerinden vazgeçmek değildir."));
        lore.add(Component.empty());
        if (eklenti.getConfig().getBoolean("irk.bir-kere-secim", true)) {
            lore.add(Mesaj.esya("<red>⚠ <gray>Irk seçimi <white>yalnızca 1 kez<gray> yapılır."));
        }
        meta.lore(lore);
        esya.setItemMeta(meta);
        return esya;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Material materyal(String ad, Material varsayilan) {
        if (ad == null) {
            return varsayilan;
        }
        Material m = Material.matchMaterial(ad.toUpperCase(Locale.ROOT));
        return m == null ? varsayilan : m;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Irk irkSlotta(int slot) {
        return slotlar.get(slot);
    }

    /** Menu olusturuldugu andaki irk (bayatlik tespiti icin). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Irk getMevcutIrk() {
        return mevcut;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean isKilitli() {
        return kilitli;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void ac() {
        oyuncu.openInventory(envanter);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    @Override
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Inventory getInventory() {
        return envanter;
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
