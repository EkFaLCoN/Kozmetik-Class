/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.HedefKorumasi;
import com.sinifsistemi.silah.Silah;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Ayışığı Yayı (Okçu): çekiş animasyonu efektleri, Ay Oku (tam gergin atış),
 * Yıldız Yağmuru (her 4. tam atış) ve Ay Salvosu (Shift + sol tık).
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class OkcuYayi implements Listener {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String YOL = "silahlar.ayisigi_yayi.";
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ETIKET_TAM = "cv_ayisigi_tam";
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ETIKET_YILDIZ = "cv_ayisigi_yildiz";
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ETIKET_SALVO = "cv_ayisigi_salvo";

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final class Cekis {
        final long baslangic = System.currentTimeMillis();
        int asama = 0;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Cekis> cekenler = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Integer> tamSayac = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<String, Long> bekleme = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask gorev;

    public OkcuYayi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void baslat() {
        kapat();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, this::cekisGorevi, 2L, 2L);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kapat() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        cekenler.clear();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private double cfg(String anahtar, double varsayilan) {
        return eklenti.getConfig().getDouble(YOL + anahtar, varsayilan);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean yayMi(ItemStack esya) {
        return eklenti.getSilahYoneticisi().tani(esya) == Silah.AYISIGI_YAYI;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean dusman(Player o, Entity e) {
        return e instanceof LivingEntity l && !l.isDead() && !l.equals(o)
                && !(e instanceof Player p && (p.getGameMode() == org.bukkit.GameMode.SPECTATOR
                || com.sinifsistemi.PartiKoprusu.ayniParti(o, p)))
                && !HedefKorumasi.korunuyor(o, l);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean beklemeVar(Player o, String ad, int sn) {
        String anahtar = o.getUniqueId() + ":" + ad;
        long simdi = System.currentTimeMillis();
        Long son = bekleme.get(anahtar);
        if (son != null && simdi - son < sn * 1000L) {
            long kalan = (sn * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(o, "yetenek-bekleme", Mesaj.degisken("saniye", String.valueOf(kalan)));
            return true;
        }
        bekleme.put(anahtar, simdi);
        return false;
    }

    // ------------------------------------------------------------ Cekis animasyonu

    @EventHandler(priority = EventPriority.MONITOR)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void cekmeBasla(PlayerInteractEvent olay) {
        Action eylem = olay.getAction();
        if (eylem != Action.RIGHT_CLICK_AIR && eylem != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player o = olay.getPlayer();
        ItemStack elde = olay.getHand() == EquipmentSlot.OFF_HAND
                ? o.getInventory().getItemInOffHand() : o.getInventory().getItemInMainHand();
        if (!yayMi(elde) || !eklenti.getSinifKilidi().kullanabilir(o, elde)) {
            return;
        }
        cekenler.putIfAbsent(o.getUniqueId(), new Cekis());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void cekisGorevi() {
        long simdi = System.currentTimeMillis();
        for (UUID kimlik : new ArrayList<>(cekenler.keySet())) {
            Player o = Bukkit.getPlayer(kimlik);
            Cekis c = cekenler.get(kimlik);
            if (o == null || c == null || !o.isOnline()) {
                cekenler.remove(kimlik);
                continue;
            }
            long gecen = simdi - c.baslangic;
            boolean elde = yayMi(o.getInventory().getItemInMainHand())
                    || yayMi(o.getInventory().getItemInOffHand());
            if (!elde || (gecen > 300 && !o.isHandRaised())) {
                cekenler.remove(kimlik);
                continue;
            }
            double oran = Math.min(1.0, gecen / 1000.0);
            Location yay = yayKonumu(o);
            World w = o.getWorld();

            // yaya dogru akan isik halkasi (oran arttikca daralir)
            double r = 0.7 * (1.0 - oran) + 0.12;
            double donus = gecen / 140.0;
            int nokta = 3 + (int) (oran * 4);
            for (int i = 0; i < nokta; i++) {
                double a = donus + Math.PI * 2 * i / nokta;
                Vector yon = o.getLocation().getDirection();
                Vector u = yon.clone().crossProduct(new Vector(0, 1, 0));
                if (u.lengthSquared() < 0.0001) {
                    u = new Vector(1, 0, 0);
                }
                u.normalize();
                Vector v = u.clone().crossProduct(yon).normalize();
                Location p = yay.clone().add(u.clone().multiply(Math.cos(a) * r))
                        .add(v.clone().multiply(Math.sin(a) * r));
                w.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0.0,
                        new Particle.DustOptions(Color.fromRGB(120, 225, 255), 0.9f));
            }
            if (oran >= 0.65 && c.asama < 1) {
                c.asama = 1;
                w.playSound(yay, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 1.2f);
                w.spawnParticle(Particle.END_ROD, yay, 6, 0.15, 0.15, 0.15, 0.02);
            }
            if (oran >= 1.0 && c.asama < 2) {
                c.asama = 2;
                w.playSound(yay, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.9f);
                w.playSound(yay, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.8f, 1.5f);
                w.spawnParticle(Particle.END_ROD, yay, 14, 0.25, 0.25, 0.25, 0.04);
                o.sendActionBar(Mesaj.esya("<aqua>☾ <white>Ay Oku hazır <aqua>☾"));
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Location yayKonumu(Player o) {
        Location g = o.getEyeLocation();
        Vector yon = g.getDirection();
        Vector sag = yon.clone().crossProduct(new Vector(0, 1, 0));
        if (sag.lengthSquared() < 0.0001) {
            sag = new Vector(1, 0, 0);
        }
        sag.normalize();
        return g.clone().add(yon.multiply(1.0)).add(sag.multiply(0.25)).add(0, -0.3, 0);
    }

    // ------------------------------------------------------------ Atis

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void atis(EntityShootBowEvent olay) {
        if (!(olay.getEntity() instanceof Player o) || !yayMi(olay.getBow())) {
            return;
        }
        cekenler.remove(o.getUniqueId());
        if (!(olay.getProjectile() instanceof AbstractArrow ok)) {
            return;
        }
        boolean tam = olay.getForce() >= 0.95f;
        if (!tam) {
            iz(ok, false);
            return;
        }
        ok.addScoreboardTag(ETIKET_TAM);
        ok.setVelocity(ok.getVelocity().multiply(1.0 + cfg("tam-atis-hiz-bonusu", 0.15)));
        ok.setCritical(true);

        int sayi = tamSayac.merge(o.getUniqueId(), 1, Integer::sum);
        int her = Math.max(1, (int) cfg("yildiz-her", 4));
        boolean yildiz = sayi % her == 0;
        if (yildiz) {
            ok.addScoreboardTag(ETIKET_YILDIZ);
            o.sendActionBar(Mesaj.esya("<gold>✦ <white>Yıldız Oku <gold>✦"));
        }
        o.getWorld().playSound(o.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 0.8f, yildiz ? 1.1f : 1.6f);
        iz(ok, yildiz);
    }

    /** Okun arkasinda isik izi; tam atista spiral, yildiz okunda altin parilti. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void iz(AbstractArrow ok, boolean yildiz) {
        boolean tam = ok.getScoreboardTags().contains(ETIKET_TAM)
                || ok.getScoreboardTags().contains(ETIKET_SALVO);
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!ok.isValid() || ok.isOnGround() || ++n > 120) {
                    cancel();
                    return;
                }
                World w = ok.getWorld();
                Location l = ok.getLocation();
                w.spawnParticle(Particle.END_ROD, l, 1, 0, 0, 0, 0.0);
                w.spawnParticle(Particle.DUST, l, 1, 0.04, 0.04, 0.04, 0.0,
                        new Particle.DustOptions(Color.fromRGB(120, 225, 255), 0.9f));
                if (tam) {
                    Vector v = ok.getVelocity();
                    if (v.lengthSquared() < 0.0001) {
                        return;
                    }
                    Vector yon = v.clone().normalize();
                    Vector u = yon.clone().crossProduct(new Vector(0, 1, 0));
                    if (u.lengthSquared() < 0.0001) {
                        u = new Vector(1, 0, 0);
                    }
                    u.normalize();
                    Vector p = u.clone().crossProduct(yon).normalize();
                    double a = n * 0.9;
                    for (int k = 0; k < 2; k++) {
                        double aa = a + Math.PI * k;
                        Location s = l.clone().add(u.clone().multiply(Math.cos(aa) * 0.28))
                                .add(p.clone().multiply(Math.sin(aa) * 0.28));
                        w.spawnParticle(Particle.DUST, s, 1, 0, 0, 0, 0.0,
                                yildiz ? new Particle.DustOptions(Color.fromRGB(255, 210, 90), 1.1f)
                                        : new Particle.DustOptions(Color.fromRGB(170, 130, 255), 1.0f));
                    }
                }
            }
        }.runTaskTimer(eklenti, 1L, 1L);
    }

    // ------------------------------------------------------------ Isabet

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void hasar(EntityDamageByEntityEvent olay) {
        if (!(olay.getDamager() instanceof AbstractArrow ok) || !ok.getScoreboardTags().contains(ETIKET_TAM)) {
            return;
        }
        if (!(ok.getShooter() instanceof Player o) || !(olay.getEntity() instanceof LivingEntity h)) {
            return;
        }
        olay.setDamage(olay.getDamage() * (1.0 + cfg("tam-atis-hasar-bonusu", 0.20)));
        int sn = (int) cfg("isaret-suresi", 4);
        if (sn > 0) {
            h.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, sn * 20, 0, false, false, false));
        }
        World w = h.getWorld();
        Location m = h.getLocation().add(0, h.getHeight() / 2, 0);
        w.spawnParticle(Particle.CRIT, m, 12, 0.3, 0.3, 0.3, 0.15);
        w.spawnParticle(Particle.END_ROD, m, 10, 0.3, 0.3, 0.3, 0.08);
        o.playSound(o.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.8f, 1.5f);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void carpma(ProjectileHitEvent olay) {
        if (!(olay.getEntity() instanceof AbstractArrow ok)) {
            return;
        }
        boolean tam = ok.getScoreboardTags().contains(ETIKET_TAM);
        boolean yildiz = ok.getScoreboardTags().contains(ETIKET_YILDIZ);
        if (!tam && !ok.getScoreboardTags().contains(ETIKET_SALVO)) {
            return;
        }
        Location l = ok.getLocation();
        World w = l.getWorld();
        if (w == null) {
            return;
        }
        w.spawnParticle(Particle.END_ROD, l, 14, 0.25, 0.25, 0.25, 0.12);
        w.playSound(l, Sound.BLOCK_AMETHYST_BLOCK_BREAK, 0.9f, 1.4f);
        if (tam) {
            for (int i = 0; i < 18; i++) {
                double a = Math.PI * 2 * i / 18.0;
                w.spawnParticle(Particle.DUST, l.getX() + Math.cos(a) * 0.9, l.getY() + 0.1,
                        l.getZ() + Math.sin(a) * 0.9, 1, 0, 0, 0, 0.0,
                        new Particle.DustOptions(Color.fromRGB(120, 225, 255), 1.2f));
            }
        }
        if (yildiz && ok.getShooter() instanceof Player o) {
            ok.removeScoreboardTag(ETIKET_YILDIZ);
            yildizYagmuru(o, l);
        }
    }

    /** Yildiz Yagmuru: hedef bolgeye pespese yildizlar duser, alan hasari verir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void yildizYagmuru(Player o, Location merkez) {
        int adet = Math.max(1, (int) cfg("yildiz-adedi", 6));
        double yaricap = cfg("yildiz-yaricap", 3.5);
        double hasar = cfg("yildiz-hasari", 6.0);
        double vurus = cfg("yildiz-vurus-yaricapi", 1.8);
        World w = merkez.getWorld();
        if (w == null) {
            return;
        }
        w.playSound(merkez, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.8f);
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                if (i++ >= adet || !o.isOnline()) {
                    cancel();
                    return;
                }
                ThreadLocalRandom r = ThreadLocalRandom.current();
                double a = r.nextDouble() * Math.PI * 2;
                double d = r.nextDouble() * yaricap;
                Location t = merkez.clone().add(Math.cos(a) * d, 0, Math.sin(a) * d);
                for (int k = 0; k < 14; k++) {
                    w.spawnParticle(Particle.END_ROD, t.clone().add(0, k * 0.55, 0), 1, 0.03, 0.03, 0.03, 0.0);
                }
                w.spawnParticle(Particle.DUST, t.clone().add(0, 0.2, 0), 14, 0.35, 0.15, 0.35, 0.0,
                        new Particle.DustOptions(Color.fromRGB(255, 210, 90), 1.4f));
                w.spawnParticle(Particle.CRIT, t.clone().add(0, 0.3, 0), 10, 0.3, 0.2, 0.3, 0.2);
                w.playSound(t, Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 0.9f, 1.0f + r.nextFloat() * 0.6f);
                w.playSound(t, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 0.9f, 1.2f);
                for (Entity e : new ArrayList<>(w.getNearbyEntities(t, vurus, vurus, vurus))) {
                    if (dusman(o, e)) {
                        ((LivingEntity) e).damage(hasar, o);
                    }
                }
            }
        }.runTaskTimer(eklenti, 6L, 4L);
    }

    // ------------------------------------------------------------ Ay Salvosu

    @EventHandler(priority = EventPriority.HIGH)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void salvoTik(PlayerInteractEvent olay) {
        Action eylem = olay.getAction();
        if (eylem != Action.LEFT_CLICK_AIR && eylem != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        if (olay.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player o = olay.getPlayer();
        ItemStack elde = o.getInventory().getItemInMainHand();
        if (!o.isSneaking() || !yayMi(elde) || !eklenti.getSinifKilidi().kullanabilir(o, elde)) {
            return;
        }
        if (HedefKorumasi.yetenekYasak(o)) {
            HedefKorumasi.yasakUyar(o);
            return;
        }
        if (beklemeVar(o, "salvo", (int) cfg("salvo-bekleme", 12))) {
            return;
        }
        salvo(o);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void salvo(Player o) {
        int adet = Math.max(1, (int) cfg("salvo-ok-sayisi", 5));
        double aci = cfg("salvo-aci", 11.0);
        double hiz = cfg("salvo-hizi", 2.6);
        double hasar = cfg("salvo-ok-hasari", 2.2);
        Vector yon = o.getEyeLocation().getDirection();
        World w = o.getWorld();
        for (int i = 0; i < adet; i++) {
            double sapma = (i - (adet - 1) / 2.0) * aci;
            Vector v = yon.clone().rotateAroundY(Math.toRadians(sapma)).normalize().multiply(hiz);
            Arrow ok = o.launchProjectile(Arrow.class, v);
            ok.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            ok.setDamage(hasar);
            ok.setCritical(true);
            ok.addScoreboardTag(ETIKET_SALVO);
            iz(ok, false);
            Bukkit.getScheduler().runTaskLater(eklenti, ok::remove, 100L);
        }
        Location g = o.getEyeLocation().add(yon.clone().multiply(1.0));
        for (int i = 0; i < 24; i++) {
            double a = Math.PI * 2 * i / 24.0;
            Vector u = yon.clone().crossProduct(new Vector(0, 1, 0));
            if (u.lengthSquared() < 0.0001) {
                u = new Vector(1, 0, 0);
            }
            u.normalize();
            Vector p = u.clone().crossProduct(yon).normalize();
            w.spawnParticle(Particle.DUST, g.clone().add(u.clone().multiply(Math.cos(a) * 0.9))
                    .add(p.clone().multiply(Math.sin(a) * 0.9)), 1, 0, 0, 0, 0.0,
                    new Particle.DustOptions(Color.fromRGB(170, 130, 255), 1.3f));
        }
        w.spawnParticle(Particle.END_ROD, g, 12, 0.2, 0.2, 0.2, 0.1);
        w.playSound(o.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 1.3f);
        w.playSound(o.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 1.6f);
        w.playSound(o.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.9f, 1.3f);
    }

    // ------------------------------------------------------------ temizlik

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void cikis(PlayerQuitEvent olay) {
        UUID k = olay.getPlayer().getUniqueId();
        cekenler.remove(k);
        tamSayac.remove(k);
        bekleme.keySet().removeIf(x -> x.startsWith(k.toString()));
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
