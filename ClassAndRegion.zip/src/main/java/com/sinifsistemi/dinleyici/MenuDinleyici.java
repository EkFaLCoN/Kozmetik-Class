/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.menu.SinifMenusu;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class MenuDinleyici implements Listener {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Long> sonUyari = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Long> sonAcilis = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Set<UUID> menusuAcik = new HashSet<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask denetimGorevi;

    /** Ayni oyuncuya bu araliktan daha sik menu acilmaz (ms). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final long ACILIS_ARALIGI = 1500L;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public MenuDinleyici(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void tiklamaOlayi(InventoryClickEvent olay) {
        Inventory ustEnvanter = olay.getView().getTopInventory();
        if (!(ustEnvanter.getHolder() instanceof SinifMenusu menu)) {
            return;
        }

        olay.setCancelled(true);

        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        // Ust envantere mi tiklandi? Referans karsilastirmasi yerine slot araligi
        // kullanilir; getClickedInventory() bazi surumlerde farkli bir sarmalayici
        // nesne dondurdugu icin equals() guvenilir degildir.
        int rawSlot = olay.getRawSlot();
        if (rawSlot < 0 || rawSlot >= ustEnvanter.getSize()) {
            return;
        }
        if (olay.getCurrentItem() == null || olay.getCurrentItem().getType().isAir()) {
            return;
        }

        Sinif secilen = menu.sinifSlotta(rawSlot);
        if (secilen == null) {
            return;
        }

        // Kilit durumu menunun acildigi andaki degil, TIKLAMA anindaki
        // veriye gore hesaplanir. Aksi halde admin /classadmin reset
        // yaptiktan sonra ekranda duran eski menu hala kilitli davranir.
        if (kilitliMi(oyuncu)) {
            Sinif mevcut = eklenti.getDepo().getSinif(oyuncu);
            ses(oyuncu, "ENTITY_VILLAGER_NO");
            Mesaj.gonder(oyuncu, "zaten-sinifin-var",
                    Mesaj.degisken("sinif", mevcut == null ? "-" : mevcut.basitRenkliAd()));
            oyuncu.closeInventory();
            return;
        }

        Sinif mevcut = eklenti.getDepo().getSinif(oyuncu);
        if (mevcut == secilen) {
            ses(oyuncu, "ENTITY_VILLAGER_NO");
            return;
        }

        eklenti.getDepo().ayarla(oyuncu.getUniqueId(), oyuncu.getName(), secilen);
        eklenti.getYetenekYoneticisi().yenidenUygula(oyuncu);

        oyuncu.closeInventory();
        ses(oyuncu, eklenti.getConfig().getString("menu.secim-sesi", "ENTITY_PLAYER_LEVELUP"));

        Mesaj.gonder(oyuncu, "secim-basarili", Mesaj.degisken("sinif", secilen.renkliAd()));
        oyuncu.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
        oyuncu.sendMessage(Mesaj.ayristir(" " + secilen.renkliAd()));
        oyuncu.sendMessage(Mesaj.ayristir(""));
        for (String satir : secilen.yetenekler()) {
            oyuncu.sendMessage(Mesaj.ayristir(" " + satir));
        }
        oyuncu.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));

        oyuncu.showTitle(net.kyori.adventure.title.Title.title(
                Mesaj.ayristir(secilen.renkliAd()),
                Mesaj.ayristir("<gray>Yeni yolun hayırlı olsun!")
        ));
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void surukleOlayi(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof SinifMenusu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void acilmaOlayi(InventoryOpenEvent olay) {
        if (olay.getInventory().getHolder() instanceof SinifMenusu
                && olay.getPlayer() instanceof Player oyuncu) {
            menusuAcik.add(oyuncu.getUniqueId());
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void cikisOlayi(PlayerQuitEvent olay) {
        UUID kimlik = olay.getPlayer().getUniqueId();
        menusuAcik.remove(kimlik);
        sonUyari.remove(kimlik);
        sonAcilis.remove(kimlik);
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kapatmaOlayi(InventoryCloseEvent olay) {
        if (!(olay.getInventory().getHolder() instanceof SinifMenusu)) {
            return;
        }
        if (!(olay.getPlayer() instanceof Player oyuncu)) {
            return;
        }
        menusuAcik.remove(oyuncu.getUniqueId());

        if (!zorunlu(oyuncu)) {
            return;
        }

        // Sinif secmeden kapatti -> kisa gecikmeyle tekrar ac
        Bukkit.getScheduler().runTaskLater(eklenti, () -> menuyuAc(oyuncu, true), 3L);
    }

    /** Oyuncu su AN itibariyla sinif degistiremiyor mu? */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean kilitliMi(Player oyuncu) {
        if (eklenti.getDepo().getSinif(oyuncu) == null) {
            return false;   // sinifi yok -> serbestce secebilir
        }
        if (!eklenti.getConfig().getBoolean("ayarlar.bir-kere-secim", true)) {
            return false;
        }
        return !oyuncu.hasPermission("sinif.degistir");
    }

    /**
     * Menuyu acar. Ayni oyuncuya cok sik acilmasini engelleyerek
     * "acilip kapanma" dongusunu imkansiz kilar.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuyuAc(Player oyuncu, boolean uyar) {
        menuyuAc(oyuncu, uyar, false);
    }

    /**
     * @param zorla true ise acilis araligi (throttle) yok sayilir. Sinif
     *              sifirlandiginda ekranda duran bayat menuyu aninda
     *              tazelemek icin kullanilir.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuyuAc(Player oyuncu, boolean uyar, boolean zorla) {
        if (!zorunlu(oyuncu)) {
            return;
        }
        long simdi = System.currentTimeMillis();
        if (!zorla) {
            Long son = sonAcilis.get(oyuncu.getUniqueId());
            if (son != null && simdi - son < ACILIS_ARALIGI) {
                return;
            }
        }
        sonAcilis.put(oyuncu.getUniqueId(), simdi);

        if (uyar) {
            uyarSinirli(oyuncu);
        }
        new SinifMenusu(eklenti, oyuncu).ac();
    }

    /**
     * Sinif sifirlandiktan sonra cagrilir: acik duran ESKI menu nesnesi
     * atilir, yerine sinifsiz (kilitsiz) yeni bir menu acilir.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuyuTazele(Player oyuncu) {
        menusuAcik.remove(oyuncu.getUniqueId());
        sonAcilis.remove(oyuncu.getUniqueId());
        Bukkit.getScheduler().runTaskLater(eklenti,
                () -> menuyuAc(oyuncu, false, true), 2L);
    }

    /**
     * Oyuncunun sinif secim menusune mahkum olup olmadigi.
     * Sadece "menu-kapatilabilir: true" ayari veya "sinif.menu.muaf" izni kacis saglar.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean zorunlu(Player oyuncu) {
        if (!oyuncu.isOnline()) {
            return false;
        }
        if (eklenti.getDepo().sinifiVar(oyuncu)) {
            return false;
        }
        if (eklenti.getConfig().getBoolean("ayarlar.menu-kapatilabilir", false)) {
            return false;
        }
        return !oyuncu.hasPermission("sinif.menu.muaf");
    }

    /** Menu her acildiginda spam olmasin diye uyariyi sinirlar. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void uyarSinirli(Player oyuncu) {
        long simdi = System.currentTimeMillis();
        Long son = sonUyari.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < 10000L) {
            return;
        }
        sonUyari.put(oyuncu.getUniqueId(), simdi);
        Mesaj.gonder(oyuncu, "menu-zorunlu");
    }

    /**
     * Denetim gorevi: sinifsiz bir oyuncunun menusu herhangi bir sebeple
     * kapaliysa (olum, dunya degisimi, komut, baska bir eklenti, /close vb.)
     * menuyu tekrar onune getirir.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void gorevBaslat() {
        gorevDurdur();
        long aralik = Math.max(5L, eklenti.getConfig().getLong("ayarlar.menu-denetim-araligi", 20L));
        denetimGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                if (!zorunlu(oyuncu)) {
                    continue;
                }
                // Menusu zaten acik olanlara dokunma
                if (menusuAcik.contains(oyuncu.getUniqueId())) {
                    continue;
                }
                if (oyuncu.getOpenInventory().getTopInventory().getHolder()
                        instanceof SinifMenusu acikMenu) {
                    // Sinifi sifirlanmis ama ekranda hala eski (kilitli) menu
                    // duruyorsa onu tazele; yoksa oyuncu hicbir sinifi secemez.
                    if (acikMenu.getMevcutSinif() != null) {
                        menuyuTazele(oyuncu);
                        continue;
                    }
                    menusuAcik.add(oyuncu.getUniqueId());
                    continue;
                }
                menuyuAc(oyuncu, true);
            }
        }, 40L, aralik);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void gorevDurdur() {
        if (denetimGorevi != null) {
            denetimGorevi.cancel();
            denetimGorevi = null;
        }
    }

    /**
     * Ses adini surumden bagimsiz sekilde calar.
     * "ENTITY_PLAYER_LEVELUP" -> "entity.player.levelup"
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void ses(Player oyuncu, String sesAdi) {
        if (sesAdi == null || sesAdi.isBlank()) {
            return;
        }
        String anahtar = sesAdi.toLowerCase(Locale.ROOT).replace('_', '.');
        try {
            oyuncu.playSound(oyuncu.getLocation(), anahtar, 1.0f, 1.0f);
        } catch (Exception yoksay) {
            // Gecersiz ses adi -> sessizce gec
        }
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
