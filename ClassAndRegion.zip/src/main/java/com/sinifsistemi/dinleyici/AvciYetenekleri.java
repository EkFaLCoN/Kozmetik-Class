package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.HedefKorumasi;
import com.sinifsistemi.silah.KanamaYoneticisi;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Kurtboğan (Avcı mızrağı): Av İşareti, Av Atılımı, Av Ağı.
 * Hedef seçimi diğer silahlarla aynı korumaları kullanır (HedefKorumasi).
 */
final class AvciYetenekleri {

    private static final String YOL = "silahlar.kurtbogan.";

    private record Isaret(UUID hedef, long bitis) {}

    private final SinifSistemi eklenti;
    private final Set<UUID> hasarIcinde;
    private final Map<UUID, Isaret> isaretler = new HashMap<>();
    private final Map<String, Long> bekleme = new HashMap<>();

    AvciYetenekleri(SinifSistemi eklenti, Set<UUID> hasarIcinde) {
        this.eklenti = eklenti;
        this.hasarIcinde = hasarIcinde;
    }

    private double cfg(String anahtar, double varsayilan) {
        return eklenti.getConfig().getDouble(YOL + anahtar, varsayilan);
    }

    private boolean dusman(Player o, Entity e) {
        return e instanceof LivingEntity l && !l.isDead() && !l.equals(o)
                && !(e instanceof Player p && (p.getGameMode() == org.bukkit.GameMode.SPECTATOR
                || com.sinifsistemi.PartiKoprusu.ayniParti(o, p)))
                && !HedefKorumasi.korunuyor(o, l);
    }

    private boolean beklemeVar(Player o, String ad, int sn) {
        String anahtar = o.getUniqueId() + ":" + ad;
        long simdi = System.currentTimeMillis();
        Long son = bekleme.get(anahtar);
        if (son != null && simdi - son < sn * 1000L) {
            long kalan = (sn * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(o, "yetenek-bekleme", Mesaj.degisken("saniye", String.valueOf(kalan)));
            return true;
        }
        bekleme.put(anahtar, simdi);
        return false;
    }

    // ------------------------------------------------------------ Av Isareti (pasif)

    private void isaretle(Player o, LivingEntity h) {
        int sn = (int) cfg("isaret-suresi", 8);
        isaretler.put(o.getUniqueId(), new Isaret(h.getUniqueId(), System.currentTimeMillis() + sn * 1000L));
        h.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, sn * 20, 0, false, false, false));
        h.getWorld().spawnParticle(Particle.DUST, h.getLocation().add(0, h.getHeight() + 0.4, 0), 10, 0.2, 0.1, 0.2, 0.0,
                new Particle.DustOptions(Color.fromRGB(255, 150, 40), 1.3f));
        o.sendActionBar(Mesaj.esya("<gold>🎯 <white>Av işaretlendi <gray>(" + sn + " sn)"));
    }

    private boolean isaretli(Player o, LivingEntity h) {
        Isaret is = isaretler.get(o.getUniqueId());
        return is != null && is.hedef().equals(h.getUniqueId()) && System.currentTimeMillis() < is.bitis();
    }

    private void kanat(Player o, LivingEntity h) {
        int sn = (int) cfg("kanama-suresi", 5);
        double hasar = cfg("kanama-hasari", 1.2);
        if (sn > 0 && hasar > 0) {
            eklenti.getKanamaYoneticisi().uygula(h, o, sn, hasar, 0.0);
            KanamaYoneticisi.parcacik(h.getLocation());
        }
    }

    /** Duz vurus: isaretli hedefe fazla hasar; degilse isaretle + kanat. */
    void vurus(EntityDamageByEntityEvent olay, Player saldiran) {
        if (!(olay.getEntity() instanceof LivingEntity h)) {
            return;
        }
        if (isaretli(saldiran, h)) {
            olay.setDamage(olay.getDamage() * (1.0 + cfg("isaret-hasar-bonusu", 0.25)));
            h.getWorld().spawnParticle(Particle.CRIT, h.getLocation().add(0, 1.0, 0), 10, 0.3, 0.4, 0.3, 0.1);
            saldiran.playSound(saldiran.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.8f, 0.8f);
        } else {
            isaretle(saldiran, h);
            kanat(saldiran, h);
        }
    }

    // ------------------------------------------------------------ kullanim

    void kullan(Player o) {
        if (HedefKorumasi.yetenekYasak(o)) {
            HedefKorumasi.yasakUyar(o);
            return;
        }
        if (o.isSneaking()) {
            if (beklemeVar(o, "ag", (int) cfg("ag-bekleme", 30))) {
                return;
            }
            avAgi(o);
        } else {
            if (beklemeVar(o, "atilim", (int) cfg("atilim-bekleme", 14))) {
                return;
            }
            atilim(o);
        }
    }

    // ------------------------------------------------------------ Av Atilimi

    private void atilim(Player o) {
        Vector yon = o.getLocation().getDirection().setY(0);
        if (yon.lengthSquared() < 0.0001) {
            yon = new Vector(0, 0, 1);
        }
        yon.normalize();
        double guc = cfg("atilim-gucu", 1.6);
        o.setVelocity(yon.clone().multiply(guc).setY(0.22));
        o.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, (int) cfg("atilim-hiz-suresi", 3) * 20, 1, true, false, true));
        o.getWorld().playSound(o.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
        o.getWorld().playSound(o.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.8f, 1.3f);

        double hasar = cfg("atilim-hasari", 7.0);
        double r = cfg("atilim-yaricap", 2.4);
        Set<UUID> vurulan = new HashSet<>();
        Vector yonF = yon;
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!o.isOnline() || o.isDead() || ++n > 9) {
                    cancel();
                    return;
                }
                Location m = o.getLocation().add(0, 1.0, 0);
                o.getWorld().spawnParticle(Particle.SWEEP_ATTACK, m.clone().add(yonF.clone().multiply(0.8)), 1, 0, 0, 0, 0);
                o.getWorld().spawnParticle(Particle.CRIT, m, 4, 0.3, 0.3, 0.3, 0.05);
                for (Entity e : new ArrayList<>(o.getNearbyEntities(r, r, r))) {
                    if (!dusman(o, e) || vurulan.contains(e.getUniqueId())) {
                        continue;
                    }
                    LivingEntity h = (LivingEntity) e;
                    vurulan.add(h.getUniqueId());
                    hasarIcinde.add(o.getUniqueId());
                    try {
                        h.damage(hasar, o);
                    } finally {
                        hasarIcinde.remove(o.getUniqueId());
                    }
                    h.setVelocity(h.getVelocity().add(yonF.clone().multiply(0.5).setY(0.3)));
                    isaretle(o, h);
                    kanat(o, h);
                    h.getWorld().playSound(h.getLocation(), Sound.ITEM_TRIDENT_HIT, 1.0f, 1.0f);
                }
            }
        }.runTaskTimer(eklenti, 1L, 1L);
    }

    // ------------------------------------------------------------ Av Agi

    private void avAgi(Player o) {
        double r = cfg("ag-menzili", 5.0);
        double hasar = cfg("ag-hasari", 5.0);
        int sn = (int) cfg("ag-suresi", 3);
        Location m = o.getLocation();
        o.getWorld().playSound(m, Sound.ENTITY_EVOKER_FANGS_ATTACK, 1.0f, 0.8f);
        o.getWorld().playSound(m, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.7f);
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40.0;
            o.getWorld().spawnParticle(Particle.DUST, m.getX() + Math.cos(a) * r, m.getY() + 0.2, m.getZ() + Math.sin(a) * r,
                    1, 0, 0, 0, 0.0, new Particle.DustOptions(Color.fromRGB(255, 150, 40), 1.4f));
        }
        LivingEntity sonHedef = null;
        for (Entity e : new ArrayList<>(o.getNearbyEntities(r, r, r))) {
            if (!dusman(o, e)) {
                continue;
            }
            LivingEntity h = (LivingEntity) e;
            hasarIcinde.add(o.getUniqueId());
            try {
                h.damage(hasar, o);
            } finally {
                hasarIcinde.remove(o.getUniqueId());
            }
            h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, sn * 20, 4, true, true, true));
            h.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, sn * 20, 128, true, false, false));
            kanat(o, h);
            h.getWorld().spawnParticle(Particle.CRIT, h.getLocation().add(0, 0.2, 0), 12, 0.3, 0.1, 0.3, 0.05);
            sonHedef = h;
        }
        if (sonHedef != null) {
            isaretle(o, sonHedef);
        }
    }

    // ------------------------------------------------------------ temizlik

    void cikis(UUID kimlik) {
        isaretler.remove(kimlik);
        bekleme.keySet().removeIf(k -> k.startsWith(kimlik.toString()));
    }

    void kapat() {
        isaretler.clear();
    }
}
