/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.HedefKorumasi;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Saman Gurzu (Rahip): Sifa Cemberi, Ruh Dalgasi, Ata Ruhlari pasifi, Ruh Emisi.
 * Dost = oyuncunun kendisi ve ayni irktan oyuncular. Dusman = vurulabilir her canli.
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
final class SamanYetenekleri {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String YOL = "silahlar.saman_gurzu.";

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Set<UUID> hasarIcinde;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<String, Long> bekleme = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Cember> cemberler = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask gorev;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final class Cember {
        UUID sahip;
        Location konum;
        long bitis;
        int sayac;
    }

    SamanYetenekleri(SinifSistemi eklenti, Set<UUID> hasarIcinde) {
        this.eklenti = eklenti;
        this.hasarIcinde = hasarIcinde;
    }

    // ------------------------------------------------------------ yardimcilar

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean dost(Player o, Entity e) {
        if (!(e instanceof Player p) || p.isDead() || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
            return false;
        }
        if (p.equals(o)) {
            return true;
        }
        // Destek silahi: yalnizca kendine ve parti uyelerine (irk arkadasi artik dahil degil)
        return com.sinifsistemi.PartiKoprusu.ayniParti(o, p);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean dusman(Player o, Entity e) {
        return e instanceof LivingEntity l && !l.isDead() && !l.equals(o)
                && !(e instanceof Player p && dost(o, p))
                && !HedefKorumasi.korunuyor(o, l);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void iyilestir(LivingEntity h, double miktar) {
        double tavan = h.getMaxHealth();
        h.setHealth(Math.min(tavan, h.getHealth() + miktar));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private double cfg(String anahtar, double varsayilan) {
        return eklenti.getConfig().getDouble(YOL + anahtar, varsayilan);
    }

    // ------------------------------------------------------------ kullanim

    void kullan(Player o) {
        if (HedefKorumasi.yetenekYasak(o)) {
            HedefKorumasi.yasakUyar(o);
            return;
        }
        boolean dalga = o.isSneaking();
        int sn = eklenti.getConfig().getInt(YOL + (dalga ? "dalga-bekleme" : "cember-bekleme"), dalga ? 30 : 25);
        String anahtar = o.getUniqueId() + (dalga ? ":d" : ":t");
        long simdi = System.currentTimeMillis();
        Long son = bekleme.get(anahtar);
        if (son != null && simdi - son < sn * 1000L) {
            long kalan = (sn * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(o, "yetenek-bekleme", Mesaj.degisken("saniye", String.valueOf(kalan)));
            return;
        }
        bekleme.put(anahtar, simdi);
        if (dalga) {
            ruhDalgasi(o);
        } else {
            cemberAc(o);
        }
    }

    // ------------------------------------------------------------ Ruh Dalgasi

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void ruhDalgasi(Player o) {
        double r = cfg("dalga-menzili", 7.0);
        double sifa = cfg("dalga-sifa", 6.0);
        double hasar = cfg("dalga-hasari", 9.0);
        double savurma = cfg("dalga-savurma", 0.9);
        Location m = o.getLocation();
        o.getWorld().playSound(m, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1.0f, 1.2f);
        o.getWorld().playSound(m, Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.6f);
        halka(m, r, Particle.SOUL_FIRE_FLAME);
        halka(m.clone().add(0, 0.6, 0), r * 0.6, Particle.END_ROD);

        hasarIcinde.add(o.getUniqueId());
        try {
            for (Entity e : new ArrayList<>(o.getNearbyEntities(r, r, r))) {
                if (!(e instanceof LivingEntity h)) {
                    continue;
                }
                if (dost(o, e)) {
                    iyilestir(h, sifa);
                    h.getWorld().spawnParticle(Particle.HEART, h.getLocation().add(0, 1.8, 0), 4, 0.3, 0.3, 0.3, 0.0);
                } else if (dusman(o, e)) {
                    h.damage(hasar, o);
                    Vector yon = h.getLocation().toVector().subtract(m.toVector()).setY(0);
                    if (yon.lengthSquared() > 0.0001) {
                        h.setVelocity(h.getVelocity().add(yon.normalize().multiply(savurma).setY(0.35)));
                    }
                    h.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 80, 0, false, true, true));
                    h.getWorld().spawnParticle(Particle.SOUL, h.getLocation().add(0, 1, 0), 6, 0.3, 0.4, 0.3, 0.02);
                }
            }
            iyilestir(o, sifa);
        } finally {
            hasarIcinde.remove(o.getUniqueId());
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void halka(Location m, double r, Particle p) {
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40.0;
            m.getWorld().spawnParticle(p, m.getX() + Math.cos(a) * r, m.getY() + 0.2, m.getZ() + Math.sin(a) * r,
                    1, 0, 0, 0, 0.0);
        }
    }

    // ------------------------------------------------------------ Sifa Cemberi

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void cemberAc(Player o) {
        Cember eski = cemberler.remove(o.getUniqueId());
        if (eski != null) {
            kaldir(eski);
        }
        Location yer = o.getLocation().clone();
        yer.setPitch(0f);
        Cember t = new Cember();
        t.sahip = o.getUniqueId();
        t.konum = yer;
        t.bitis = System.currentTimeMillis() + (long) (eklenti.getConfig().getInt(YOL + "cember-suresi", 12) * 1000L);
        cemberler.put(o.getUniqueId(), t);

        o.getWorld().playSound(yer, Sound.BLOCK_BELL_RESONATE, 1.0f, 0.6f);
        o.getWorld().playSound(yer, Sound.ENTITY_WARDEN_HEARTBEAT, 1.0f, 1.2f);
        o.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, yer.clone().add(0, 0.3, 0), 25, 0.5, 0.2, 0.5, 0.05);

        if (gorev == null) {
            gorev = Bukkit.getScheduler().runTaskTimer(eklenti, this::tik, 5L, 5L);
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void tik() {
        long simdi = System.currentTimeMillis();
        double r = cfg("cember-menzili", 6.0);
        int yen = (int) cfg("cember-yenilenme", 1);
        Iterator<Cember> it = cemberler.values().iterator();
        while (it.hasNext()) {
            Cember t = it.next();
            Player sahip = Bukkit.getPlayer(t.sahip);
            if (sahip == null || !sahip.isOnline() || simdi >= t.bitis
                    || HedefKorumasi.bolgedeMi(t.konum)) {
                kaldir(t);
                it.remove();
                continue;
            }
            t.sayac++;
            Location m = t.konum;
            // halka + yukselen ruh isigi
            double acisi = t.sayac * 0.5;
            for (int i = 0; i < 6; i++) {
                double a = acisi + Math.PI * 2 * i / 6.0;
                m.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, m.getX() + Math.cos(a) * r,
                        m.getY() + 0.15, m.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
            }
            for (int i = 0; i < 4; i++) {
                double a2 = -acisi * 1.5 + Math.PI * 2 * i / 4.0;
                m.getWorld().spawnParticle(Particle.END_ROD, m.getX() + Math.cos(a2) * r * 0.5,
                        m.getY() + 0.1, m.getZ() + Math.sin(a2) * r * 0.5, 1, 0, 0, 0, 0.0);
            }
            m.getWorld().spawnParticle(Particle.END_ROD, m.getX(), m.getY() + 0.3 + (t.sayac % 8) * 0.3, m.getZ(),
                    2, 0.1, 0.0, 0.1, 0.0);

            if (t.sayac % 4 != 0) {
                continue;   // etki saniyede bir
            }
            for (Entity e : m.getWorld().getNearbyEntities(m, r, r, r)) {
                if (!(e instanceof LivingEntity h)) {
                    continue;
                }
                double dx = h.getLocation().getX() - m.getX();
                double dz = h.getLocation().getZ() - m.getZ();
                if (dx * dx + dz * dz > r * r) {
                    continue;
                }
                if (dost(sahip, e)) {
                    h.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 45, yen, true, true, true));
                    h.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 45, 0, true, false, true));
                } else if (dusman(sahip, e)) {
                    h.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 45, 0, true, true, true));
                    h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 45, 0, true, true, true));
                    h.getWorld().spawnParticle(Particle.DUST, h.getLocation().add(0, 1.0, 0), 4, 0.3, 0.4, 0.3, 0.0,
                            new Particle.DustOptions(Color.fromRGB(70, 236, 214), 1.0f));
                }
            }
        }
        if (cemberler.isEmpty() && gorev != null) {
            gorev.cancel();
            gorev = null;
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void kaldir(Cember t) {
        t.konum.getWorld().spawnParticle(Particle.POOF, t.konum.clone().add(0, 0.3, 0), 14, 0.5, 0.1, 0.5, 0.02);
    }

    // ------------------------------------------------------------ pasifler

    /** Ata Ruhlari: elde tutarken Direnc I; yakindaki dostlara Yenilenme I. */
    void pasif(Player o) {
        if (HedefKorumasi.yetenekYasak(o)) {
            return;
        }
        o.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 30, 0, true, false, false));
        double r = cfg("pasif-menzil", 6.0);
        for (Entity e : o.getNearbyEntities(r, r, r)) {
            if (e instanceof Player p && dost(o, p)) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 30, 0, true, false, false));
            }
        }
    }

    /** Duz vurus: Cember Gucu (+hasar) ve Ruh Emisi (can calma). */
    void vurus(EntityDamageByEntityEvent olay, Player saldiran) {
        double carpan = 1.0;
        Cember t = cemberler.get(saldiran.getUniqueId());
        if (t != null && t.konum.getWorld().equals(saldiran.getWorld())) {
            double r = cfg("cember-menzili", 6.0);
            if (t.konum.distanceSquared(saldiran.getLocation()) <= r * r) {
                carpan += cfg("cember-hasar-bonusu", 0.25);
            }
        }
        olay.setDamage(olay.getDamage() * carpan);
        double emis = olay.getDamage() * cfg("can-emis-orani", 0.20);
        if (emis > 0) {
            iyilestir(saldiran, emis);
            saldiran.getWorld().spawnParticle(Particle.SOUL, saldiran.getLocation().add(0, 1.2, 0), 3, 0.3, 0.4, 0.3, 0.02);
        }
        if (olay.getEntity() instanceof LivingEntity h) {
            h.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, h.getLocation().add(0, 1.0, 0), 8, 0.3, 0.4, 0.3, 0.03);
        }
    }

    // ------------------------------------------------------------ temizlik

    void kapat() {
        for (Cember t : cemberler.values()) {
            kaldir(t);
        }
        cemberler.clear();
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
    }

    void cikis(UUID kimlik) {
        Cember t = cemberler.remove(kimlik);
        if (t != null) {
            kaldir(t);
        }
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
