package com.sinifsistemi;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.UUID;

/** PartySistemi'ne yansima ile baglanir (yumusak bagimlilik). Yoksa parti yok sayilir. */
public final class PartiKoprusu {

    private PartiKoprusu() {
    }

    /** a ve b ayni partideyse true. */
    public static boolean ayniParti(Player a, Player b) {
        try {
            Plugin p = Bukkit.getPluginManager().getPlugin("PartySistemi");
            if (p == null || !p.isEnabled()) {
                return false;
            }
            Method m = p.getClass().getMethod("getMembersOf", UUID.class);
            Object sonuc = m.invoke(p, a.getUniqueId());
            return sonuc instanceof Collection<?> uyeler && uyeler.contains(b.getUniqueId());
        } catch (ReflectiveOperationException | RuntimeException hata) {
            return false;
        }
    }
}
