/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.duello;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * Tek bir duello oturumu.
 *
 * Basta iki oyuncunun envanteri, cani, acligi, efektleri ve konumu
 * yedeklenir; duello bitince aynen geri yuklenir. Boylece harcanan
 * iksirler, oklar ve zirh dayanikliligi geri gelir.
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class DuelloOturumu {

    /** Bir oyuncunun duello oncesi tam durumu. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public static class Yedek {
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final ItemStack[] envanter;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final ItemStack[] zirh;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final ItemStack yanEl;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final double can;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final double maxCan;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final int aclik;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final float doygunluk;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final Location konum;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final List<PotionEffect> efektler;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final int deneyimSeviyesi;
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        final float deneyimIlerleme;

        Yedek(Player oyuncu) {
            this.envanter = kopyala(oyuncu.getInventory().getContents());
            this.zirh = kopyala(oyuncu.getInventory().getArmorContents());
            this.yanEl = oyuncu.getInventory().getItemInOffHand().clone();
            this.can = oyuncu.getHealth();
            this.maxCan = oyuncu.getMaxHealth();
            this.aclik = oyuncu.getFoodLevel();
            this.doygunluk = oyuncu.getSaturation();
            this.konum = oyuncu.getLocation().clone();
            this.efektler = new ArrayList<>(oyuncu.getActivePotionEffects());
            this.deneyimSeviyesi = oyuncu.getLevel();
            this.deneyimIlerleme = oyuncu.getExp();
        }

        /** Esyalarin KENDISINI kopyalar: dizi.clone() yalnizca canli esyalara referans tutar,
         *  duelloda tuketilen esyalar (ok, yemek...) geri yuklemede eksik kalirdi. */
        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        private static ItemStack[] kopyala(ItemStack[] kaynak) {
            ItemStack[] sonuc = new ItemStack[kaynak.length];
            for (int i = 0; i < kaynak.length; i++) {
                sonuc[i] = kaynak[i] == null ? null : kaynak[i].clone();
            }
            return sonuc;
        }

        /** Oyuncuyu duello oncesi haline dondurur. */
        void geriYukle(Player oyuncu) {
            // Duelloda kazanilan/kaybedilen her sey silinir
            oyuncu.getInventory().clear();
            oyuncu.getInventory().setContents(envanter);
            oyuncu.getInventory().setArmorContents(zirh);
            oyuncu.getInventory().setItemInOffHand(yanEl);

            for (PotionEffect efekt : new ArrayList<>(oyuncu.getActivePotionEffects())) {
                oyuncu.removePotionEffect(efekt.getType());
            }
            for (PotionEffect efekt : efektler) {
                oyuncu.addPotionEffect(efekt);
            }

            oyuncu.setHealth(Math.min(can, oyuncu.getMaxHealth()));
            oyuncu.setFoodLevel(aclik);
            oyuncu.setSaturation(doygunluk);
            oyuncu.setLevel(deneyimSeviyesi);
            oyuncu.setExp(deneyimIlerleme);
            oyuncu.setFireTicks(0);
            oyuncu.updateInventory();
        }

        // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
        public Location konum() {
            return konum;
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final UUID birinci;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final UUID ikinci;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Yedek birinciYedek;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Yedek ikinciYedek;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final GuvenliBolge bolge;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final long baslangic;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean bitti;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public DuelloOturumu(Player a, Player b, GuvenliBolge bolge) {
        this.birinci = a.getUniqueId();
        this.ikinci = b.getUniqueId();
        this.birinciYedek = new Yedek(a);
        this.ikinciYedek = new Yedek(b);
        this.bolge = bolge;
        this.baslangic = System.currentTimeMillis();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public UUID birinci() {
        return birinci;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public UUID ikinci() {
        return ikinci;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public GuvenliBolge bolge() {
        return bolge;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean bittiMi() {
        return bitti;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void bitir() {
        this.bitti = true;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public long gecenSaniye() {
        return (System.currentTimeMillis() - baslangic) / 1000L;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean icerir(UUID kimlik) {
        return birinci.equals(kimlik) || ikinci.equals(kimlik);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public UUID rakip(UUID kimlik) {
        if (birinci.equals(kimlik)) {
            return ikinci;
        }
        if (ikinci.equals(kimlik)) {
            return birinci;
        }
        return null;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Yedek yedek(UUID kimlik) {
        return birinci.equals(kimlik) ? birinciYedek : ikinciYedek;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Collection<UUID> katilimcilar() {
        return List.of(birinci, ikinci);
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
