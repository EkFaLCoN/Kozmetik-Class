/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi.duello;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

/**
 * Guvenli bolge: merkez + yaricap (silindir).
 *
 * - Icinde normal PvP KAPALIDIR
 * - Duello YALNIZCA burada atilabilir
 * - Duello sirasinda oyuncular disari cikamaz
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class GuvenliBolge {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final String ad;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final String dunyaAdi;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final double x;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final double y;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final double z;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final double yaricap;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public GuvenliBolge(String ad, String dunyaAdi, double x, double y, double z, double yaricap) {
        this.ad = ad;
        this.dunyaAdi = dunyaAdi;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaricap = yaricap;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public static GuvenliBolge konumdan(String ad, Location konum, double yaricap) {
        return new GuvenliBolge(ad, konum.getWorld().getName(),
                konum.getX(), konum.getY(), konum.getZ(), yaricap);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String ad() {
        return ad;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String dunyaAdi() {
        return dunyaAdi;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public double yaricap() {
        return yaricap;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Location merkez() {
        World dunya = Bukkit.getWorld(dunyaAdi);
        return dunya == null ? null : new Location(dunya, x, y, z);
    }

    /** Yatay mesafeye bakar; yukseklik sinirsizdir (silindir). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean icinde(Location konum) {
        if (konum == null || konum.getWorld() == null) {
            return false;
        }
        if (!konum.getWorld().getName().equalsIgnoreCase(dunyaAdi)) {
            return false;
        }
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        return (dx * dx + dz * dz) <= (yaricap * yaricap);
    }

    /** Merkeze olan yatay mesafe. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public double mesafe(Location konum) {
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Bolge disina cikan oyuncuyu sinirin hemen icine geri getirecek konum.
     * Yonu korur, sadece merkeze dogru ceker.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Location sinirIcineCek(Location konum) {
        Location merkez = merkez();
        if (merkez == null) {
            return konum;
        }
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        double uzaklik = Math.sqrt(dx * dx + dz * dz);
        if (uzaklik < 0.0001) {
            return merkez;
        }
        double hedef = yaricap - 1.5;
        double oran = hedef / uzaklik;
        Location yeni = konum.clone();
        yeni.setX(x + dx * oran);
        yeni.setZ(z + dz * oran);
        return yeni;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String kayitSatiri() {
        return ad + "," + dunyaAdi + "," + x + "," + y + "," + z + "," + yaricap;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public static GuvenliBolge satirdan(String satir) {
        String[] p = satir.split(",");
        if (p.length != 6) {
            return null;
        }
        try {
            return new GuvenliBolge(p[0], p[1],
                    Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                    Double.parseDouble(p[4]), Double.parseDouble(p[5]));
        } catch (NumberFormatException hata) {
            return null;
        }
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
