package com.sinifsistemi.silah;

import com.sinifsistemi.SinifSistemi;
import org.bukkit.Location;
import org.bukkit.entity.Allay;
import org.bukkit.entity.Ambient;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ComplexEntityPart;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Wither;
import org.bukkit.entity.WaterMob;
import org.bukkit.entity.AbstractVillager;

/**
 * Silah YETENEKLERININ (alan hasari, kanama, golge sicramasi, gizli vurus bonusu...)
 * hedef alamayacagi varliklar: hayvanlar, evcillestirilebilen her sey, Ender Dragon,
 * Wither, koylu / gezgin tuccar ve armor stand.
 * Duz vurus (vanilla hasar) bu siniftan etkilenmez.
 */
public final class HedefKorumasi {

    private static SinifSistemi eklenti;
    private static final java.util.Map<java.util.UUID, Long> UYARI = new java.util.HashMap<>();

    private HedefKorumasi() {
    }

    public static void baslat(SinifSistemi ana) {
        eklenti = ana;
    }

    /** Konum bir guvenli bolgenin icinde mi? */
    public static boolean bolgedeMi(Location konum) {
        if (eklenti == null || konum == null || eklenti.getDuelloYoneticisi() == null) {
            return false;
        }
        if (!eklenti.getConfig().getBoolean("guvenli-bolge-yetenek-yasagi", true)) {
            return false;
        }
        return eklenti.getDuelloYoneticisi().bolgeBul(konum) != null;
    }

    /**
     * Oyuncu su an silah yetenegi kullanamaz mi? Guvenli bolgede (duello disinda) yasak.
     */
    public static boolean yetenekYasak(Player oyuncu) {
        if (oyuncu == null || !bolgedeMi(oyuncu.getLocation())) {
            return false;
        }
        return eklenti.getDuelloYoneticisi().oturum(oyuncu) == null;
    }

    /** Yasak mesajini (3 sn'de bir) gosterir. */
    public static void yasakUyar(Player oyuncu) {
        long simdi = System.currentTimeMillis();
        Long son = UYARI.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < 3000L) {
            return;
        }
        UYARI.put(oyuncu.getUniqueId(), simdi);
        com.sinifsistemi.Mesaj.gonder(oyuncu, "yetenek-guvenli-bolge");
    }

    /**
     * Kaynak oyuncunun yetenegi bu hedefe islemeyecek mi?
     * - ayni irktan oyuncu (duello / arena istisnasi disinda)
     * - guvenli bolgedeki herhangi bir varlik (duello disinda)
     * - bolgedeki kaynak
     */
    public static boolean oyuncuEngeli(Player kaynak, Entity hedef) {
        if (kaynak == null || hedef == null || eklenti == null || kaynak.equals(hedef)) {
            return false;
        }
        if (hedef instanceof Player h) {
            if (eklenti.getConfig().getBoolean("irk.yetenek-ayni-irk-korumasi", true)
                    && eklenti.getIrkSistemi() != null
                    && !eklenti.getIrkSistemi().vurabilir(kaynak, h)) {
                return true;
            }
            var duello = eklenti.getDuelloYoneticisi();
            if (duello != null && (bolgedeMi(kaynak.getLocation()) || bolgedeMi(h.getLocation()))) {
                var ko = duello.oturum(kaynak);
                return ko == null || ko != duello.oturum(h);
            }
            return false;
        }
        return yetenekYasak(kaynak) || (bolgedeMi(hedef.getLocation())
                && eklenti.getDuelloYoneticisi().oturum(kaynak) == null);
    }

    /** Yetenek hedefi mi korunuyor: hayvan vb. VEYA irk / guvenli bolge kurali. */
    public static boolean korunuyor(Player kaynak, Entity hedef) {
        return korunuyor(hedef) || oyuncuEngeli(kaynak, hedef);
    }

    public static boolean korunuyor(Entity e) {
        if (e == null || e instanceof Player) {
            return false;
        }
        if (e instanceof ComplexEntityPart parca) {
            return korunuyor(parca.getParent());
        }
        if (e instanceof ArmorStand || e instanceof EnderDragon || e instanceof Wither
                || e instanceof AbstractVillager || e instanceof Villager
                || e instanceof Tameable) {
            return true;
        }
        if (e instanceof Monster) {
            return false;                        // Hoglin vb. dusmanca "hayvanlar" korunmaz
        }
        return e instanceof Animals || e instanceof WaterMob || e instanceof Ambient || e instanceof Allay;
    }
}
