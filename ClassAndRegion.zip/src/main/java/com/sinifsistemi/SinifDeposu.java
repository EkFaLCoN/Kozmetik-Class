/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package com.sinifsistemi;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Oyuncu -> sinif eslesmelerini bellekte tutar ve veriler.yml dosyasina yazar.
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public class SinifDeposu {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final DateTimeFormatter BICIM =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final SinifSistemi eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Sinif> onbellek = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, String> tarihler = new HashMap<>();

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private File dosya;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private FileConfiguration veri;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public SinifDeposu(SinifSistemi eklenti) {
        this.eklenti = eklenti;
        yukle();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void yukle() {
        onbellek.clear();
        tarihler.clear();

        dosya = new File(eklenti.getDataFolder(), "veriler.yml");
        if (!dosya.exists()) {
            try {
                if (!eklenti.getDataFolder().exists() && !eklenti.getDataFolder().mkdirs()) {
                    eklenti.getLogger().warning("Eklenti klasoru olusturulamadi!");
                }
                if (!dosya.createNewFile()) {
                    eklenti.getLogger().warning("veriler.yml olusturulamadi!");
                }
            } catch (IOException hata) {
                eklenti.getLogger().log(Level.SEVERE, "veriler.yml olusturulurken hata olustu", hata);
            }
        }

        veri = YamlConfiguration.loadConfiguration(dosya);

        if (veri.isConfigurationSection("oyuncular")) {
            for (String anahtar : veri.getConfigurationSection("oyuncular").getKeys(false)) {
                try {
                    UUID kimlik = UUID.fromString(anahtar);
                    Sinif sinif = Sinif.bul(veri.getString("oyuncular." + anahtar + ".sinif"));
                    if (sinif != null) {
                        onbellek.put(kimlik, sinif);
                        String tarih = veri.getString("oyuncular." + anahtar + ".tarih", "-");
                        tarihler.put(kimlik, tarih);
                    }
                } catch (IllegalArgumentException yoksay) {
                    eklenti.getLogger().warning("Gecersiz UUID atlandi: " + anahtar);
                }
            }
        }

        eklenti.getLogger().info(onbellek.size() + " oyuncunun sinif verisi yuklendi.");
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kaydet() {
        if (veri == null || dosya == null) {
            return;
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().log(Level.SEVERE, "veriler.yml kaydedilemedi", hata);
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean sinifiVar(Player oyuncu) {
        return onbellek.containsKey(oyuncu.getUniqueId());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean sinifiVar(UUID kimlik) {
        return onbellek.containsKey(kimlik);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Sinif getSinif(Player oyuncu) {
        return onbellek.get(oyuncu.getUniqueId());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Sinif getSinif(UUID kimlik) {
        return onbellek.get(kimlik);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String getTarih(UUID kimlik) {
        return tarihler.getOrDefault(kimlik, "-");
    }

    /** Sinifi atar ve diske yazar. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void ayarla(UUID kimlik, String ad, Sinif sinif) {
        String tarih = LocalDateTime.now().format(BICIM);
        onbellek.put(kimlik, sinif);
        tarihler.put(kimlik, tarih);

        veri.set("oyuncular." + kimlik + ".ad", ad);
        veri.set("oyuncular." + kimlik + ".sinif", sinif.kod());
        veri.set("oyuncular." + kimlik + ".tarih", tarih);
        kaydet();
    }

    /** Oyuncunun sinifini tamamen siler. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void sifirla(UUID kimlik) {
        onbellek.remove(kimlik);
        tarihler.remove(kimlik);
        veri.set("oyuncular." + kimlik, null);
        kaydet();
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
