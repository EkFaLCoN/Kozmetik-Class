# ClassAndRegion — Sınıf, Silah, Irk ve Düello Sistemi

Paper sunucuları için tamamen Türkçe sınıf, silah, ırk ve düello sistemi.
Oyuncular sunucuya girdiğinde bir GUI açılır ve **hayatlarında yalnızca bir kez** sınıf seçerler.

---

## Sınıflar

| Sıra | Sınıf | Menü Simgesi |
|------|-------|--------------|
| 1 | **Savaşçı** | +2 kalp, +2 zırh, yakın dövüşte %20 fazla hasar | Oklardan %15 az hasar |
| **Suikastçı** | Hareket hızı %20 | Kılıçla %25, arkadan %60 hasar; %10 fazla hasar alır |
| **Rahip** | — | 2 saniyede bir can yenilenmesi, 6 blok şifa aurası, aldığı şifa %50 güçlü, yakın dövüşü zayıf (%15) |
| **Okçu** | Yay/arbalet tutarken hareket hızı %20 | Ok hasarı %35, düşme hasarı %50 azalır, yakın dövüşü zayıf (%15) |
| **Büyücü** | -1 kalp, gece görüşü | Büyü/iksir hasarına %50 direnç, attığı iksirler %40 güçlü |
| **Avcı** | +1 kalp, +1 zırh, saldırı hızı %15, hareket hızı %8, +0.5 etkileşim menzili | Tüm mızrak türlerinde %30 ekstra hasar; mızrak dışı silahlarla %10 zayıf |

### Avcı hakkında

Avcı, Okçu'ya benzer şekilde **silaha bağlı** bir sınıftır: doğru silahla güçlü,
onun dışında zayıf.

- **Tüm mızrak türlerinde %30 ekstra hasar.** Buna `_SPEAR` ile biten her eşya
  (wooden, stone, copper, iron, golden, diamond, netherite) ve üç dişli mızrak
  (trident) dahildir. Fırlatılan üç dişli mızrak da aynı bonusu alır.
- Mızrak dışındaki her silahla %10 daha az hasar.

Saldırı hızı bonusu, mızrağın yavaş temposunu dengelemek içindir; mızrak zaten
düşük saldırı hızına sahip bir silahtır. Mızrak tespiti materyal adının
`_SPEAR` ile bitmesine bakar, yani ileride yeni bir mızrak türü eklenirse
kod değiştirmeden otomatik kapsanır.

Menü ikonu `NETHERITE_SPEAR`'dır. İkonlar Material sabiti yerine isimle
tutulup çalışma zamanında çözülür; sunucu sürümünde bulunamazsa yedeğe
(Avcı için `TRIDENT`) düşer. Menü slotları da sınıf sayısına göre otomatik
ortalanır, yeni sınıf eklerken slot ayarlamaya gerek yoktur.

Attribute isimleri Minecraft 1.21.3'te değişti (`GENERIC_MAX_HEALTH` → `MAX_HEALTH`).
Eklenti her iki ismi de deneyerek çözer, bu yüzden sürüm farkı sorun çıkarmaz.
Bulunamayan bir attribute konsola uyarı yazıp sessizce atlanır.

---

## Kurulum

1. Jar dosyasını sunucunun `plugins/` klasörüne at.
2. Sunucuyu yeniden başlat.
3. `plugins/ClassAndRegion/config.yml` dosyasından her şeyi özelleştir.

**Gereksinimler:** Paper 26.2 ve Java 25.

`pom.xml` bağımlılığı `[26.2.build,)` aralığını kullanır, yani en güncel 26.2
derlemesini otomatik çeker. Sabit bir derlemeye kilitlemek istersen
`26.2.build.112-stable` gibi tam sürüm yazabilirsin.

## Derleme

Bilgisayarında Maven varsa:

```bash
mvn clean package
```

Jar dosyası `target/ClassAndRegion.jar` yolunda oluşur. Java 25 gerekir.

Maven kurmak istemiyorsan: proje içindeki `.github/workflows/derle.yml` dosyası hazır.
Projeyi GitHub'a yükle, Actions sekmesinden derlenmiş jar'ı indir.

---

## Komutlar

### Oyuncu komutları

| Komut | Açıklama |
|-------|----------|
| `/class` | Sınıf seçim menüsünü açar |
| `/class info` | Kendi sınıfını ve yeteneklerini gösterir |
| `/class list` | Tüm sınıfları listeler |

Kısayollar: `/class`, `/sinifim`

### Yetkili komutları

| Komut | Açıklama |
|-------|----------|
| `/classadmin set <oyuncu> <sınıf>` | Oyuncuya zorla sınıf verir |
| `/classadmin reset <oyuncu>` | Sınıfı siler, oyuncu yeniden seçebilir |
| `/classadmin info <oyuncu>` | Oyuncunun sınıfını ve seçim tarihini gösterir |
| `/classadmin menu <oyuncu>` | Oyuncuya seçim menüsünü açar |
| `/classadmin reload` | Ayarları yeniden yükler |

Kısayollar: `/sy`, `/sinifadmin`

Sınıf adları: `savasci`, `suikastci`, `rahip`, `okcu`, `buyucu`

---

## İzinler

| İzin | Varsayılan | Açıklama |
|------|-----------|----------|
| `sinif.kullan` | herkes | `/class` komutunu kullanabilir |
| `sinif.admin` | OP | Yönetim komutlarını kullanabilir |
| `sinif.degistir` | OP | Tek seferlik kilidi aşar, istediği zaman değiştirir |

---

## Önemli Ayarlar

```yaml
ayarlar:
  bir-kere-secim: true        # false = herkes istediği zaman değiştirebilir
  menu-kapatilabilir: false   # false = sınıf seçmeden menü KAPATILAMAZ
  menu-denetim-araligi: 20    # zorunlu menü denetiminin sıklığı (tick)
```

### Zorunlu sınıf seçim menüsü

`menu-kapatilabilir: false` iken menü gerçekten zorunludur:

- ESC ile kapatılırsa **1 tick içinde** geri açılır
- Ayrıca bir denetim görevi her saniye tüm çevrimiçi oyuncuları tarar;
  sınıfsız bir oyuncunun menüsü herhangi bir sebeple kapalıysa
  (ölüm, dünya değişimi, başka bir eklenti, komut) menüyü tekrar önüne getirir
- Girişte sınıfsız oyuncuya menü koşulsuz açılır
- Uyarı mesajı 4 saniyede birden sık gönderilmez, sohbet dolmaz

Tek kaçış yolu `sinif.menu.muaf` iznidir. Bu izin **varsayılan olarak kimsede yoktur** —
OP'larda bile. Sunucuda kendini kilitlemekten çekiniyorsan bu izni kendine ver;
aksi halde sınıf seçmeden hiçbir şey yapamazsın.

Tüm mesajlar `config.yml` içindeki `mesajlar:` bölümündedir ve MiniMessage
formatını destekler (`<red>`, `<gradient:#FFD200:#FF8A00>`, `<bold>` vb.).

---

## Veriler

Oyuncu sınıfları `plugins/ClassAndRegion/veriler.yml` dosyasında UUID bazlı tutulur.
Oyuncu adını değiştirse bile sınıfı korunur.

---

# Özel Silahlar

Sınıflara özel, yalnızca kendi sınıfının kullanabildiği silahlar.

## Kanlı Savaş Baltası — Savaşçı

Çift ağızlı bir savaş baltası. **Sağ ağız** cilalı çelik, **sol ağız** kanla kaplı ve
üzerinden sürekli kan akıyor. Sol ağzın altındaki çapraz saydam düzlemlerde
kan damlaları aşağı doğru düşer — 12 kareli animasyonlu texture ile.

**Verme:** `/weapon give kanli_savas_baltasi [oyuncu]`

**Yetenekler**
- Vuruş hasarı %30 artar
- Vurduğu hedefe 4 saniye **Kanama** uygular (saniyede yarım kalp, zırhı delip geçer)
- Kanama hasarının %35'i kullanıcıya can olarak döner
- **Sağ tık — Kan Çağrısı:** 4.5 blok çevredeki tüm canlılara 5 saniye kanama,
  kullanıcıya 5 saniye Güç I. 20 saniye bekleme süresi.

**Sınıf kısıtı**
Savaşçı olmayan biri baltayı eline alırsa uyarı alır ve balta otomatik olarak
elinden envanterine geri konur. Vuruş ve sağ tık da engellenir.
`sinif.silah.serbest` izni bu kısıtı aşar.

## Komutlar

| Komut | Açıklama |
|-------|----------|
| `/weapon give <silah> [oyuncu]` | Özel silahı verir |
| `/weapon list` | Tüm özel silahları listeler |

## İzinler

| İzin | Varsayılan |
|------|-----------|
| `sinif.silah.yonet` | OP |
| `sinif.silah.serbest` | OP |

## Resourcepack

Balta varlıkları `Created_By_MRWQLF.zip` paketinin içine eklendi:

```
assets/cursedclasses/items/kanli_savas_baltasi.json
assets/cursedclasses/models/item/kanli_savas_baltasi.json
assets/cursedclasses/textures/item/kanli_savas_baltasi.png        (384x4608, 12 kare)
assets/cursedclasses/textures/item/kanli_savas_baltasi.png.mcmeta (frametime 2, interpolate)
```

Model 26 elemandan oluşur, `texture_size` [64, 64] atlas kullanır.
Eklenti eşyayı `netherite_axe` tabanı üzerine `item_model` bileşeniyle bağlar —
mevcut eşyalarının hiçbiriyle çakışmaz.

Ayarlar `config.yml` içindeki `silahlar:` bölümündedir.

### Modeli düzenleme

`kanli_savas_baltasi.bbmodel` dosyası Blockbench ile doğrudan açılabilir.
Texture içine gömülüdür, ayrıca dosya yüklemen gerekmez.

Elde tutuş görünümünü ayarlamak için: Blockbench'te sağ üstteki **Display**
sekmesine geç, soldan **First Person / Third Person** pozlarını seç ve
modeli sürükleyerek konumlandır. İşin bitince `File > Export > Export Block/Item Model`
ile dışa aktar ve çıkan JSON'u
`assets/cursedclasses/models/item/kanli_savas_baltasi.json` üzerine yaz.

Dışa aktarırken dikkat: Blockbench `texture_size` alanı ekleyebilir. Minecraft
bu alanı yok sayıp UV'leri her zaman 0-16 aralığında okuduğu için, alan eklenirse
sil — aksi halde doku kayar.

---

# Irk Sistemi — Emberon & Rhodar

Sınıf seçiminden **sonra** gelen taraf seçimi. Aynı ırktan oyuncular
birbirine zarar veremez.

| Irk | Bayrak | Pasif | Etki |
|-----|--------|-------|------|
| **Emberon** | Kırmızı | Kor Kabuğu | Yakın dövüşten alınan hasar %8 azalır |
| **Rhodar** | Mavi | Gelgit Adımı | Hareket hızı %6 artar |

**Emberon** — Külün altında sönmeyen közden doğdular. Bittikleri sanılır,
sonra yeniden alevlenirler.

**Rhodar** — Derin suların ve seher göğünün halkı. Vururlar ve gökyüzü
kadar sessiz çekilirler.

Irk pasifleri **sınıf yeteneklerinin üzerine eklenir** — ayrı attribute
anahtarları kullandıkları için sınıf bonuslarını ezmezler. Bir Suikastçı
Rhodar, sınıfından gelen %20 hızın üstüne ırkından %6 daha alır.

Oyuncuların ismi ırk renginde görünür ve yanında ırk bayrağı (`⚑`) taşır —
baş üstü isimde ve sekme listesinde.

### Seçim akışı

Oyuncu girer → sınıf menüsü → sınıf seçilir → **ırk menüsü** → ırk seçilir.
Irk seçimi de sınıf gibi zorunlu ve tek seferliktir.

### Aynı ırk koruması

Kapatılan hasar yolları: yakın dövüş, ok ve trident, atılan iksir, iksir
bulutu, TNT patlaması, alev okuyla tutuşturma. Bütün dünyalarda geçerlidir.

Yalnızca üç durumda devre dışı kalır: arena dünyası, arena bölgesi kutusu,
ya da aktif düello.

### Komutlar

| Komut | Açıklama |
|-------|----------|
| `/race` | Irkını gösterir, yoksa seçim ekranını açar |
| `/race list` | Irkları ve pasiflerini listeler |
| `/race members` | Çevrimiçi ırk dağılımı |
| `/raceadmin set <oyuncu> <ırk>` | Irk verir |
| `/raceadmin reset <oyuncu>` | Irkı siler |
| `/raceadmin info <oyuncu>` | Irkı görüntüler |
| `/raceadmin duel <o1> <o2>` | Geçici vuruşma izni |

Irk kodları: `emberon`, `rhodar`

---

# Düello Sistemi

Güvenli bölge içinde, karşılıklı rızayla yapılan 1v1 dövüş.

### Kurallar

- Düello **yalnızca güvenli bölgede** atılır; ikisi de bölge içinde olmalı
- Rakip **10 blok** içinde olmalı
- Güvenli bölgede düello dışı PvP **tamamen kapalıdır**
- Farklı ırklar da güvenli bölgede düello atabilir; aynı ırk koruması düello boyunca aşılır
- Düello sırasında **bölgeden çıkılamaz** — sınıra gelen içeri itilir, ışınlanma engellenir
- **Ölümcül hasarda oyuncu ölmez**; canı 1'e sabitlenir ve düello biter
- Harcanan **iksir, ok ve zırh dayanıklılığı geri gelir** — başta envanter,
  zırh, can, açlık, efektler, deneyim ve konum yedeklenir
- Düelloda atılan ok ve iksirler **dışarıdakilere zarar vermez**
- Dışarıdan **müdahale edilemez**
- Kazanan sohbette duyurulur; çıkan kaybeder, süre dolarsa berabere

### Güvenli bölge oluşturma

Merkez olmasını istediğin yere git ve yarıçapı yaz:

```
/duelarea create arena1 r=25
```

Silindir şeklindedir, yükseklik sınırsızdır (yatay mesafeye bakılır).

| Komut | Açıklama |
|-------|----------|
| `/duel <oyuncu>` | Düello daveti gönderir |
| `/duel accept` · `/duel deny` | Daveti cevaplar |
| `/duelarea create <ad> r=<yarıçap>` | Bölge oluşturur (3-500 blok) |
| `/duelarea delete <ad>` | Bölgeyi siler |
| `/duelarea list` | Bölgeleri listeler |
| `/duelarea info` | Bulunduğun bölgeyi gösterir |

### Ayarlar

```yaml
duello:
  davet-menzili: 10.0
  davet-suresi: 30
  sure-limiti: 180          # 0 = sinirsiz
  bitince-isinla: true
  baslangic-duyurusu: true
```

---

## Veri dosyaları

```
plugins/ClassAndRegion/config.yml
plugins/ClassAndRegion/veriler.yml            (sinifllar)
plugins/ClassAndRegion/irklar.yml             (irklar)
plugins/ClassAndRegion/guvenli_bolgeler.txt   (duello bolgeleri)
```

Hepsi UUID bazlıdır; oyuncu adını değiştirse bile verisi korunur.

## Ek izinler

| İzin | Varsayılan |
|------|-----------|
| `irk.admin` | OP |
| `irk.degistir` | OP |
| `irk.menu.muaf` | kimsede yok |
| `duello.admin` | OP |

## Sınıf kilidi ve sınıf zırhları

- `/weapon lock <sınıf> [sınıf...]` — elindeki eşyayı o sınıflara kilitler (`hepsi` = hepsi). Eşyaya "🔒 Yalnızca X sınıfı kullanabilir" satırı eklenir.
  Yanlış sınıf: vuramaz, sağ tık/ok atma çalışmaz, zırh giyemez (giyilmişse çıkarılır).
- `/weapon lock remove` — kilidi kaldırır.
- `/weapon armor <sınıf> [kask|gogusluk|pantolon|bot|hepsi] [oyuncu]` — sınıfa özel 3D zırh seti verir (otomatik o sınıfa kilitli).
- Zırh değerleri `config.yml` > `zirh:` bölümünden ayarlanır.
- `sinif.silah.serbest` yetkisi kilidi yok sayar.
- Kasklar kafada gerçek 3D model olarak görünür; göğüslük/pantolon/botlar envanterde 3D, giyilince sınıfın zırh katmanıyla görünür.
- Okçu: düşme hasarı %50 azalır (`dusme-hasari-carpani`), yakın dövüş %15 zayıf. Avcı: mızrak dışı %10 zayıf.

### Güncelleme notları
- Kilit artık OP'leri de bağlar; aşmak için `sinif.kilit.gec` yetkisi gerekir.
- Zırhlar envanterde 2D ikon, kasklar kafada 3D. 4 parça giyince sınıfa özel **set bonusu** (config: `zirh.<sınıf>.set-bonus`).
- Gölge Pelerini giyilmez; elde tutup sağ tıkla (10 sn görünmezlik, zırh/weapon/isim dahil her şey gizlenir).
- Eski sürümlerden kalan gizli `*_can` max-can bonusları temizlenir.

### Zırh / silah güncellemesi (2)
- Zırh setleri elmastan güçlü (zırh 22-28, sertlik 9-11). Her parçada 2 sınıf bonusu + 4 parça set bonusu; hepsi `config.yml > zirh:` altında.
- Hançerler: 8 hasar, 2.4 saldırı hızı. Kanlı Savaş Baltası: 12 hasar, 1.2 hız, yetenekleri güçlendirildi.
- Şafak Kesişi'nin vurma sorunu düzeltildi (hasar bağışıklığı yutuyordu). Ayrıca Gölgeden Vuruş artık gizliyken çalışıyor.
- Gölge Pelerini: 15 sn görünmezlik, bitince 15 sn bekleme; gizliyken ilk vuruş %50 fazla.
- Tüm özel silahlar kendi sınıfına kilitli (OP bile `sinif.kilit.gec` olmadan kullanamaz).
- KozmetikSistemi: herhangi bir görünmezlikte (efekt dahil) kanat/peri gizlenir, bitince geri gelir.

### Güncelleme (3)
- Zırh parçalarında 3'er bonus; yeni türler: `can_calma` (vuruşta can çalma), `diken` (hasar yansıtma).
- Sınıf kilidi artık yetkiyle bile aşılamaz (`ayarlar.kilit-yetkiyle-gecilebilir: false`).
- Hançer hasarı 7.5. Her sınıfın giyilen zırh dokusu ve ikonları ayrı tasarım; kasklar yeniden modellendi.

### Sınıfa özel zırh bonusları (4)
Her sınıfın bonus havuzu farklı; hepsi `config.yml > zirh > <sınıf> > parcalar`:
- **Savaşçı:** diken, can çalma, yakın dövüş gücü, itme direnci, saldırı gücü
- **Suikastçı:** kaçınma şansı, arkadan vuruş, saldırı hızı, hız
- **Rahip:** şifa gücü, aura menzili, can yenileme, +can
- **Okçu:** ok hasarı, ok kritik şansı, hız, düşme hasarı azaltma
- **Büyücü:** iksir hasarı, büyü direnci, vuruşta yakma/yavaşlatma, +can
- **Avcı:** mızrak hasarı, etkileşim menzili, mızrakla kanatma, hız
Eski zırhların lore'u güncellenmez; `/weapon armor ...` ile yenisini al.

## Komutlar (İngilizce)
Eski Türkçe komut adları alias olarak çalışmaya devam eder.

| Komut | Açıklama |
|---|---|
| `/class [info\|list]` | Sınıf menüsü / bilgi / liste |
| `/classadmin <set\|reset\|info\|menu> <oyuncu> [sınıf]`, `/classadmin reload` | Sınıf yönetimi |
| `/weapon give <silah> [oyuncu]` | Özel silah ver |
| `/weapon list` | Silahları listele |
| `/weapon lock <sınıf...\|all>`, `/weapon lock remove` | Eldeki eşyayı sınıfa kilitle / kilidi kaldır |
| `/weapon armor <sınıf> [helmet\|chestplate\|leggings\|boots\|all] [oyuncu]` | Sınıf zırhı ver |
| `/race [list\|members]` | Irk menüsü / liste / üyeler |
| `/raceadmin <set\|reset\|info> <oyuncu> [ırk]`, `/raceadmin duel <o1> <o2>` | Irk yönetimi |
| `/duel <oyuncu>`, `/duel accept`, `/duel deny` | Düello |
| `/duelarea create <ad> r=<yarıçap>`, `delete <ad>`, `list`, `info` | Güvenli bölge |
