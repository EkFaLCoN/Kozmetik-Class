package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sinif kilidi olan esyalarin yanlis sinifta kullanimini engeller:
 * vurma, sag tik, ok atma, zirh giyme.
 */
public class KilitDinleyici implements Listener {

    private final SinifSistemi eklenti;
    private final Map<UUID, Long> uyariZamani = new HashMap<>();
    private BukkitTask gorev;

    public KilitDinleyici(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    public void gorevBaslat() {
        gorevDurdur();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                zirhDenetle(oyuncu);
            }
        }, 20L, 10L);
    }

    public void gorevDurdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
    }

    /** Giyilmis zirhlardan siniflara uymayanlari cikarir. */
    private void zirhDenetle(Player oyuncu) {
        // Oyuncu envanterle ugrasirken (imlecte esya / baska menu acik) esya tasimayiz:
        // tikla-tasi sirasinda araya girmek esyanin kaybolmasina yol aciyordu.
        if (meliyorMu(oyuncu)) {
            return;
        }
        PlayerInventory env = oyuncu.getInventory();
        ItemStack[] zirhlar = env.getArmorContents();
        boolean degisti = false;
        for (int i = 0; i < zirhlar.length; i++) {
            ItemStack parca = zirhlar[i];
            if (parca == null || parca.getType().isAir()) {
                continue;
            }
            boolean eskiPelerin = eklenti.getSilahYoneticisi().tani(parca)
                    == com.sinifsistemi.silah.Silah.GOLGE_PELERINI;
            if (eskiPelerin || !eklenti.getSinifKilidi().kullanabilir(oyuncu, parca)) {
                zirhlar[i] = null;
                degisti = true;
                env.setArmorContents(zirhlar);
                Map<Integer, ItemStack> artan = env.addItem(parca.clone());
                for (ItemStack kalan : artan.values()) {
                    oyuncu.getWorld().dropItemNaturally(oyuncu.getLocation(), kalan);
                }
                if (!eskiPelerin) {
                    uyar(oyuncu, parca);
                }
            }
        }
        if (degisti) {
            env.setArmorContents(zirhlar);
            oyuncu.updateInventory();
        }
    }

    /** Imlecte esya var ya da oyuncunun kendi envanteri disinda bir menu acik mi? */
    static boolean meliyorMu(Player oyuncu) {
        var imlec = oyuncu.getItemOnCursor();
        if (imlec != null && !imlec.getType().isAir()) {
            return true;
        }
        return oyuncu.getOpenInventory().getTopInventory().getType() != InventoryType.CRAFTING;
    }

    private void uyar(Player oyuncu, ItemStack esya) {
        // Istemci giyme/tasima islemini tahmin edip esyayi gizleyebilir: iptalden sonra envanteri esitle
        Bukkit.getScheduler().runTask(eklenti, oyuncu::updateInventory);
        Bukkit.getScheduler().runTaskLater(eklenti, oyuncu::updateInventory, 2L);
        long simdi = System.currentTimeMillis();
        Long son = uyariZamani.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < 3000L) {
            return;
        }
        uyariZamani.put(oyuncu.getUniqueId(), simdi);
        Mesaj.gonder(oyuncu, "kilit-uyusmuyor", Mesaj.degisken("sinif",
                eklenti.getSinifKilidi().siniflarMetni(eklenti.getSinifKilidi().izinliler(esya))));
        oyuncu.playSound(oyuncu.getLocation(), "entity.villager.no", 1.0f, 0.8f);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void vurus(EntityDamageByEntityEvent olay) {
        if (!(olay.getDamager() instanceof Player saldiran)) {
            return;
        }
        ItemStack elde = saldiran.getInventory().getItemInMainHand();
        if (!eklenti.getSinifKilidi().kullanabilir(saldiran, elde)) {
            olay.setCancelled(true);
            uyar(saldiran, elde);
        }
    }

    /** Imleci surukleyerek yanlis sinif zirhini zirh yuvasina koyma. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void suruklemeGiyme(org.bukkit.event.inventory.InventoryDragEvent olay) {
        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        ItemStack imlec = olay.getOldCursor();
        if (imlec == null || imlec.getType().isAir() || eklenti.getSinifKilidi().kullanabilir(oyuncu, imlec)) {
            return;
        }
        for (int slot : olay.getRawSlots()) {
            if (olay.getView().getSlotType(slot) == InventoryType.SlotType.ARMOR) {
                olay.setCancelled(true);
                uyar(oyuncu, imlec);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void etkilesim(PlayerInteractEvent olay) {
        ItemStack esya = olay.getItem();
        if (esya == null || !eklenti.getSinifKilidi().kilitliMi(esya)) {
            return;
        }
        if (!eklenti.getSinifKilidi().kullanabilir(olay.getPlayer(), esya)) {
            olay.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
            olay.setCancelled(true);
            uyar(olay.getPlayer(), esya);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void okAtma(EntityShootBowEvent olay) {
        if (!(olay.getEntity() instanceof Player oyuncu)) {
            return;
        }
        ItemStack yay = olay.getBow();
        if (yay != null && !eklenti.getSinifKilidi().kullanabilir(oyuncu, yay)) {
            olay.setCancelled(true);
            uyar(oyuncu, yay);
        }
    }

    /** Zirh yuvasina kilitli ve uymayan esya konmasini engeller. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        if (olay.getSlotType() == org.bukkit.event.inventory.InventoryType.SlotType.ARMOR) {
            ItemStack imlec = olay.getCursor();
            if (imlec != null && !imlec.getType().isAir()
                    && !eklenti.getSinifKilidi().kullanabilir(oyuncu, imlec)) {
                olay.setCancelled(true);
                uyar(oyuncu, imlec);
                return;
            }
        }
        // Sayi tusu ile hotbar'dan zirh yuvasina giyme
        if (olay.getSlotType() == org.bukkit.event.inventory.InventoryType.SlotType.ARMOR
                && olay.getClick() == org.bukkit.event.inventory.ClickType.NUMBER_KEY
                && olay.getHotbarButton() >= 0) {
            ItemStack h = oyuncu.getInventory().getItem(olay.getHotbarButton());
            if (h != null && !h.getType().isAir() && !eklenti.getSinifKilidi().kullanabilir(oyuncu, h)) {
                olay.setCancelled(true);
                uyar(oyuncu, h);
                return;
            }
        }
        // Shift-tik ile otomatik giyme
        if (olay.isShiftClick() && olay.getClickedInventory() != null
                && olay.getClickedInventory().getType() == InventoryType.PLAYER) {
            ItemStack tiklanan = olay.getCurrentItem();
            if (tiklanan != null && !tiklanan.getType().isAir()
                    && !eklenti.getSinifKilidi().kullanabilir(oyuncu, tiklanan)
                    && tiklanan.getType().getEquipmentSlot() != org.bukkit.inventory.EquipmentSlot.HAND) {
                olay.setCancelled(true);
                uyar(oyuncu, tiklanan);
            }
        }
    }
}
