package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.HedefKorumasi;
import com.sinifsistemi.silah.Silah;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Buyucu asalari: Buz, Ates, Yildirim ve hepsinin birlesimi olan Element Asasi. */
final class AsaYetenekleri {

    private final SinifSistemi eklenti;
    private final Set<UUID> hasarIcinde;
    private final Map<String, Long> bekleme = new HashMap<>();

    AsaYetenekleri(SinifSistemi eklenti, Set<UUID> hasarIcinde) {
        this.eklenti = eklenti;
        this.hasarIcinde = hasarIcinde;
    }

    static boolean asaMi(Silah s) {
        return s == Silah.BUZ_ASASI || s == Silah.ATES_ASASI
                || s == Silah.YILDIRIM_ASASI || s == Silah.ELEMENT_ASASI;
    }

    void kullan(Player o, Silah silah) {
        boolean golge = o.isSneaking();
        String yol = "silahlar." + silah.kod() + ".";
        String anahtar = o.getUniqueId() + ":" + silah.kod() + ":" + (golge ? "b" : "a");
        int sn = eklenti.getConfig().getInt(yol + (golge ? "alan-bekleme" : "tek-bekleme"), golge ? 14 : 6);
        long simdi = System.currentTimeMillis();
        Long son = bekleme.get(anahtar);
        if (son != null && simdi - son < sn * 1000L) {
            long kalan = (sn * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(o, "yetenek-bekleme", Mesaj.degisken("saniye", String.valueOf(kalan)));
            return;
        }
        bekleme.put(anahtar, simdi);

        double hasar = eklenti.getConfig().getDouble(yol + (golge ? "alan-hasari" : "tek-hasari"), golge ? 6.0 : 8.0);
        double menzil = eklenti.getConfig().getDouble(yol + (golge ? "alan-menzili" : "tek-menzili"), golge ? 5.0 : 20.0);
        hasarIcinde.add(o.getUniqueId());
        try {
            if (golge) {
                alan(o, silah, hasar, menzil);
            } else {
                tek(o, silah, hasar, menzil);
            }
        } finally {
            hasarIcinde.remove(o.getUniqueId());
        }
    }

    // ---------------------------------------------------------- yan ozellikler (duz vurus)

    private static final class Yuk {
        UUID hedef;
        int sayi;
        long son;
    }

    private final Map<UUID, Yuk> yukler = new HashMap<>();

    /** Duz vurustaki yan ozellikler: Buz = Soguk Yuku, Ates = Kor, Yildirim = Statik, Element = hepsi. */
    void vurus(org.bukkit.event.entity.EntityDamageByEntityEvent olay, Player o, Silah silah) {
        if (!(olay.getEntity() instanceof LivingEntity h)) {
            return;
        }
        String yol = "silahlar." + silah.kod() + ".";
        var cfg = eklenti.getConfig();
        double carpan = 1.0;

        // Element Uyumu: diger elde baska bir asa varsa hasar artar
        Silah diger = eklenti.getSilahYoneticisi().tani(o.getInventory().getItemInOffHand());
        if (diger != null && asaMi(diger) && diger != silah) {
            carpan += cfg.getDouble(yol + "uyum-bonusu", 0.15);
        }

        boolean buz = silah == Silah.BUZ_ASASI || silah == Silah.ELEMENT_ASASI;
        boolean ates = silah == Silah.ATES_ASASI || silah == Silah.ELEMENT_ASASI;
        boolean statik = silah == Silah.YILDIRIM_ASASI || silah == Silah.ELEMENT_ASASI;

        if (ates) {
            // Kor: yanan hedefe fazladan hasar, her vurus hedefi yakar
            if (h.getFireTicks() > 0) {
                carpan += cfg.getDouble(yol + "kor-bonusu", 0.25);
            }
            h.setFireTicks(Math.max(h.getFireTicks(), cfg.getInt(yol + "kor-yanma", 3) * 20));
        }
        if (buz) {
            // Soguk Yuku: ayni hedefe ust uste vurdukca hasar artar, tavanda donma patlamasi
            long simdi = System.currentTimeMillis();
            Yuk y = yukler.computeIfAbsent(o.getUniqueId(), k -> new Yuk());
            if (!h.getUniqueId().equals(y.hedef) || simdi - y.son > cfg.getInt(yol + "yuk-unutma", 6) * 1000L) {
                y.hedef = h.getUniqueId();
                y.sayi = 0;
            }
            y.son = simdi;
            y.sayi++;
            h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 0));
            carpan += cfg.getDouble(yol + "yuk-basina", 0.10) * y.sayi;
            if (y.sayi >= cfg.getInt(yol + "yuk-tavani", 5)) {
                y.sayi = 0;
                h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 3));
                h.setFreezeTicks(h.getMaxFreezeTicks() + 60);
                h.getWorld().spawnParticle(Particle.SNOWFLAKE, h.getLocation().add(0, 1, 0), 40, 0.4, 0.6, 0.4, 0.05);
                h.getWorld().playSound(h.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.3f);
                hasarIcinde.add(o.getUniqueId());
                try {
                    h.damage(cfg.getDouble(yol + "yuk-patlama-hasari", 5.0), o);
                } finally {
                    hasarIcinde.remove(o.getUniqueId());
                }
            }
        }
        olay.setDamage(olay.getDamage() * carpan);

        if (statik) {
            // Statik: her N. vurusta hedefe yildirim bosalir
            int say = statikSayac.merge(o.getUniqueId(), 1, Integer::sum);
            if (say >= cfg.getInt(yol + "statik-vurus", 4)) {
                statikSayac.remove(o.getUniqueId());
                h.getWorld().strikeLightningEffect(h.getLocation());
                h.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, h.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.2);
                hasarIcinde.add(o.getUniqueId());
                try {
                    h.damage(cfg.getDouble(yol + "statik-hasari", 5.0), o);
                } finally {
                    hasarIcinde.remove(o.getUniqueId());
                }
            }
        }
    }

    private final Map<UUID, Integer> statikSayac = new HashMap<>();

    // ---------------------------------------------------------- tek hedef

    private LivingEntity bakilan(Player o, double menzil) {
        Location g = o.getEyeLocation();
        var r = o.getWorld().rayTraceEntities(g, g.getDirection(), menzil, 0.6,
                e -> e instanceof LivingEntity && !e.equals(o) && !HedefKorumasi.korunuyor(e));
        return r == null ? null : (LivingEntity) r.getHitEntity();
    }

    private Location bakilanNokta(Player o, double menzil) {
        Location g = o.getEyeLocation();
        var r = o.getWorld().rayTraceBlocks(g, g.getDirection(), menzil);
        return r == null ? g.clone().add(g.getDirection().multiply(menzil)) : r.getHitPosition().toLocation(o.getWorld());
    }

    private void cizgi(Player o, Location hedef, Particle p, Particle.DustOptions toz) {
        Location a = o.getEyeLocation().add(0, -0.25, 0);
        Vector v = hedef.toVector().subtract(a.toVector());
        double uz = v.length();
        if (uz < 0.1) {
            return;
        }
        v.normalize();
        for (double d = 0.8; d < uz; d += 0.5) {
            Location q = a.clone().add(v.clone().multiply(d));
            if (toz != null) {
                o.getWorld().spawnParticle(Particle.DUST, q, 1, 0.03, 0.03, 0.03, 0, toz);
            } else {
                o.getWorld().spawnParticle(p, q, 1, 0.03, 0.03, 0.03, 0.0);
            }
        }
    }

    private void tek(Player o, Silah silah, double hasar, double menzil) {
        switch (silah) {
            case BUZ_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location son = h != null ? h.getLocation().add(0, 1, 0) : bakilanNokta(o, menzil);
                cizgi(o, son, Particle.SNOWFLAKE, null);
                o.getWorld().playSound(o.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.6f);
                if (h != null) {
                    buz(h, o, hasar, 4);
                }
            }
            case ATES_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location son = h != null ? h.getLocation().add(0, 1, 0) : bakilanNokta(o, menzil);
                cizgi(o, son, Particle.FLAME, null);
                o.getWorld().playSound(o.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
                o.getWorld().spawnParticle(Particle.EXPLOSION, son, 1);
                if (h != null) {
                    ates(h, o, hasar, 5);
                }
            }
            case YILDIRIM_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location nokta = h != null ? h.getLocation() : bakilanNokta(o, menzil);
                yildirim(o, nokta, hasar, 3.0);
            }
            default -> {   // ELEMENT_ASASI
                LivingEntity h = bakilan(o, menzil);
                Location nokta = h != null ? h.getLocation() : bakilanNokta(o, menzil);
                cizgi(o, nokta.clone().add(0, 1, 0), null, new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.2f));
                if (h != null) {
                    buz(h, o, hasar * 0.4, 3);
                    ates(h, o, hasar * 0.3, 4);
                }
                yildirim(o, nokta, hasar * 0.3, 2.5);
            }
        }
    }

    // ---------------------------------------------------------- alan

    private List<LivingEntity> cevre(Player o, Location merkez, double r) {
        List<LivingEntity> l = new ArrayList<>();
        for (var e : merkez.getWorld().getNearbyEntities(merkez, r, r, r)) {
            if (e instanceof LivingEntity c && !c.equals(o) && !HedefKorumasi.korunuyor(c)) {
                l.add(c);
            }
        }
        return l;
    }

    private void halka(Location m, double r, Particle p) {
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40.0;
            m.getWorld().spawnParticle(p, m.clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r), 1, 0, 0, 0, 0.0);
        }
    }

    private void alan(Player o, Silah silah, double hasar, double r) {
        Location m = o.getLocation();
        switch (silah) {
            case BUZ_ASASI -> {
                halka(m, r, Particle.SNOWFLAKE);
                m.getWorld().spawnParticle(Particle.SNOWFLAKE, m.clone().add(0, 1, 0), 60, r / 2, 0.6, r / 2, 0.02);
                o.getWorld().playSound(m, Sound.BLOCK_GLASS_BREAK, 1f, 0.7f);
                for (LivingEntity h : cevre(o, m, r)) {
                    buz(h, o, hasar, 5);
                }
            }
            case ATES_ASASI -> {
                halka(m, r, Particle.FLAME);
                m.getWorld().spawnParticle(Particle.LAVA, m.clone().add(0, 1, 0), 30, r / 2, 0.5, r / 2, 0.0);
                o.getWorld().playSound(m, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.6f);
                for (LivingEntity h : cevre(o, m, r)) {
                    ates(h, o, hasar, 6);
                    itme(o, h, 0.9);
                }
            }
            case YILDIRIM_ASASI -> zincir(o, hasar, r, 4);
            default -> {   // ELEMENT_ASASI
                halka(m, r, Particle.SNOWFLAKE);
                halka(m, r * 0.7, Particle.FLAME);
                int vurulan = 0;
                for (LivingEntity h : cevre(o, m, r)) {
                    buz(h, o, hasar * 0.4, 4);
                    ates(h, o, hasar * 0.3, 5);
                    if (vurulan++ < 3) {
                        yildirim(o, h.getLocation(), hasar * 0.3, 2.0);
                    }
                }
            }
        }
    }

    private void zincir(Player o, double hasar, double r, int adet) {
        Location m = o.getLocation();
        LivingEntity simdiki = null;
        double en = Double.MAX_VALUE;
        for (LivingEntity h : cevre(o, m, 14)) {
            double d = h.getLocation().distanceSquared(m);
            if (d < en) {
                en = d;
                simdiki = h;
            }
        }
        if (simdiki == null) {
            o.sendActionBar(net.kyori.adventure.text.Component.text("Yakında hedef yok",
                    net.kyori.adventure.text.format.NamedTextColor.RED));
            return;
        }
        Set<UUID> vurulan = new HashSet<>();
        Location onceki = o.getEyeLocation();
        for (int i = 0; i < adet && simdiki != null; i++) {
            vurulan.add(simdiki.getUniqueId());
            Location nokta = simdiki.getLocation().add(0, 1, 0);
            Vector v = nokta.toVector().subtract(onceki.toVector());
            double uz = v.length();
            if (uz > 0.1) {
                v.normalize();
                for (double d = 0; d < uz; d += 0.4) {
                    o.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, onceki.clone().add(v.clone().multiply(d)), 1, 0, 0, 0, 0);
                }
            }
            simdiki.getWorld().strikeLightningEffect(simdiki.getLocation());
            simdiki.damage(hasar, o);
            simdiki.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
            onceki = nokta;
            LivingEntity sonraki = null;
            double e2 = Double.MAX_VALUE;
            for (LivingEntity h : cevre(o, simdiki.getLocation(), r + 1)) {
                if (vurulan.contains(h.getUniqueId())) {
                    continue;
                }
                double d = h.getLocation().distanceSquared(simdiki.getLocation());
                if (d < e2) {
                    e2 = d;
                    sonraki = h;
                }
            }
            simdiki = sonraki;
        }
    }

    // ---------------------------------------------------------- etkiler

    private void buz(LivingEntity h, Player o, double hasar, int sn) {
        h.damage(hasar, o);
        h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, sn * 20, 2));
        h.setFreezeTicks(Math.min(h.getMaxFreezeTicks() + 60, h.getFreezeTicks() + sn * 40));
        h.getWorld().spawnParticle(Particle.SNOWFLAKE, h.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.02);
    }

    private void ates(LivingEntity h, Player o, double hasar, int sn) {
        h.damage(hasar, o);
        h.setFireTicks(sn * 20);
        h.getWorld().spawnParticle(Particle.FLAME, h.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.03);
    }

    private void yildirim(Player o, Location nokta, double hasar, double r) {
        nokta.getWorld().strikeLightningEffect(nokta);
        for (LivingEntity h : cevre(o, nokta, r)) {
            h.damage(hasar, o);
            h.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, h.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
        }
    }

    private void itme(Player o, LivingEntity h, double guc) {
        Vector v = h.getLocation().toVector().subtract(o.getLocation().toVector()).setY(0);
        if (v.lengthSquared() > 0.0001) {
            h.setVelocity(v.normalize().multiply(guc).setY(0.35));
        }
    }
}
