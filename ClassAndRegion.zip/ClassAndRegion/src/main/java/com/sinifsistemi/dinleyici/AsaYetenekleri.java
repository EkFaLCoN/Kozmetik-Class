package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.HedefKorumasi;
import com.sinifsistemi.silah.Silah;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Buyucu asalari: Buz, Ates, Yildirim ve hepsinin birlesimi olan Element Asasi. */
final class AsaYetenekleri {

    private final SinifSistemi eklenti;
    private final Set<UUID> hasarIcinde;
    private final Map<String, Long> bekleme = new HashMap<>();

    AsaYetenekleri(SinifSistemi eklenti, Set<UUID> hasarIcinde) {
        this.eklenti = eklenti;
        this.hasarIcinde = hasarIcinde;
    }

    static boolean asaMi(Silah s) {
        return s == Silah.BUZ_ASASI || s == Silah.ATES_ASASI
                || s == Silah.YILDIRIM_ASASI || s == Silah.ELEMENT_ASASI;
    }

    void kullan(Player o, Silah silah) {
        boolean golge = o.isSneaking();
        String yol = "silahlar." + silah.kod() + ".";
        String anahtar = o.getUniqueId() + ":" + silah.kod() + ":" + (golge ? "b" : "a");
        int sn = eklenti.getConfig().getInt(yol + (golge ? "alan-bekleme" : "tek-bekleme"), golge ? 14 : 6);
        long simdi = System.currentTimeMillis();
        Long son = bekleme.get(anahtar);
        if (son != null && simdi - son < sn * 1000L) {
            long kalan = (sn * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(o, "yetenek-bekleme", Mesaj.degisken("saniye", String.valueOf(kalan)));
            return;
        }
        bekleme.put(anahtar, simdi);

        double hasar = eklenti.getConfig().getDouble(yol + (golge ? "alan-hasari" : "tek-hasari"), golge ? 6.0 : 8.0)
                * uyum(o, silah);
        double menzil = eklenti.getConfig().getDouble(yol + (golge ? "alan-menzili" : "tek-menzili"), golge ? 5.0 : 20.0);
        hasarIcinde.add(o.getUniqueId());
        try {
            if (golge) {
                alan(o, silah, hasar, menzil);
            } else {
                tek(o, silah, hasar, menzil);
            }
        } finally {
            hasarIcinde.remove(o.getUniqueId());
        }
    }

    // ---------------------------------------------------------- pasifler (asa elde tutulurken)

    private boolean atesBagisik(Silah s) {
        return s == Silah.ATES_ASASI || s == Silah.ELEMENT_ASASI;
    }

    /** Hasar turu ates mi ve oyuncu ateş asasi tutuyor mu? SilahDinleyici.hasarAlma cagirir. */
    boolean atesHasariniEngelle(Player o, Silah silah, org.bukkit.event.entity.EntityDamageEvent.DamageCause c) {
        if (silah == null || !atesBagisik(silah)) {
            return false;
        }
        return c == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FIRE
                || c == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FIRE_TICK
                || c == org.bukkit.event.entity.EntityDamageEvent.DamageCause.LAVA
                || c == org.bukkit.event.entity.EntityDamageEvent.DamageCause.HOT_FLOOR;
    }

    /**
     * Elde tutarken surekli pasifler (denetim gorevinden her 0.5 sn):
     *  Buz  = Soguk Aura: yakindaki dusmanlar yavaslar, donma hasari yemezsin
     *  Ates = Alev Zirhi: ates/lav hasari almazsin
     *  Yildirim = Elektrik Yuku: Hiz I
     *  Element = ucunun hafif hali
     */
    void pasif(Player o, Silah silah) {
        var cfg = eklenti.getConfig();
        String yol = "silahlar." + silah.kod() + ".";
        boolean buz = silah == Silah.BUZ_ASASI || silah == Silah.ELEMENT_ASASI;
        boolean ates = atesBagisik(silah);
        boolean yildirim = silah == Silah.YILDIRIM_ASASI || silah == Silah.ELEMENT_ASASI;
        if (buz) {
            // Soguk Aura + Buz Zirhi (Direnc I)
            o.setFreezeTicks(0);
            double r = cfg.getDouble(yol + "aura-menzili", 5.0);
            for (LivingEntity h : cevre(o, o.getLocation(), r)) {
                h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 1, true, false, false));
                h.getWorld().spawnParticle(Particle.SNOWFLAKE, h.getLocation().add(0, 1, 0), 2, 0.3, 0.4, 0.3, 0.0);
            }
            o.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 30, 0, true, false, false));
        }
        if (ates) {
            // Alev Zirhi + Kor Ruhu (Guc I)
            if (o.getFireTicks() > 0) {
                o.setFireTicks(0);
            }
            o.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 30, 0, true, false, false));
        }
        if (yildirim) {
            // Elektrik Yuku: Hiz II + Hizli El (Acele I)
            o.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, silah == Silah.ELEMENT_ASASI ? 0 : 1, true, false, false));
            if (silah == Silah.YILDIRIM_ASASI) {
                o.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 30, 0, true, false, false));
            }
        }
    }

    private final Map<UUID, Long> karsilikZamani = new HashMap<>();

    /** Asa tutan oyuncu hasar alinca saldirgana karsilik verir (pasif). */
    void karsilik(Player o, Silah silah, org.bukkit.entity.Entity saldiran) {
        if (!(saldiran instanceof LivingEntity h) || h.equals(o) || HedefKorumasi.korunuyor(h)) {
            return;
        }
        long simdi = System.currentTimeMillis();
        Long son = karsilikZamani.get(o.getUniqueId());
        if (son != null && simdi - son < 2000L) {
            return;
        }
        boolean buz = silah == Silah.BUZ_ASASI || silah == Silah.ELEMENT_ASASI;
        boolean ates = atesBagisik(silah);
        boolean yildirim = silah == Silah.YILDIRIM_ASASI || silah == Silah.ELEMENT_ASASI;
        boolean oldu = false;
        if (buz) {      // Donmus Karsilik: saldirgan yavaslar
            h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2));
            h.getWorld().spawnParticle(Particle.SNOWFLAKE, h.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.02);
            oldu = true;
        }
        if (ates) {     // Kizgin Karsilik: saldirgan yanar
            h.setFireTicks(Math.max(h.getFireTicks(), 60));
            oldu = true;
        }
        if (yildirim && java.util.concurrent.ThreadLocalRandom.current().nextDouble() < eklenti.getConfig().getDouble("silahlar." + silah.kod() + ".refleks-sansi", 0.35)) {
            // Yildirim Refleksi: %25 sansla saldirgana yildirim
            h.getWorld().strikeLightningEffect(h.getLocation());
            hasarIcinde.add(o.getUniqueId());
            try {
                h.damage(eklenti.getConfig().getDouble("silahlar." + silah.kod() + ".refleks-hasari", 6.0), o);
            } finally {
                hasarIcinde.remove(o.getUniqueId());
            }
            oldu = true;
        }
        if (oldu) {
            karsilikZamani.put(o.getUniqueId(), simdi);
        }
    }

    /** Yanan dusman olurse Ates / Element Asasi sahibi can kazanir (Kor Hasadi). */
    @SuppressWarnings("deprecation")
    void oldurdu(Player o, Silah silah, LivingEntity olen) {
        if (atesBagisik(silah) && olen.getFireTicks() > 0) {
            double kazan = eklenti.getConfig().getDouble("silahlar." + silah.kod() + ".kor-hasadi", 5.0);
            o.setHealth(Math.min(o.getMaxHealth(), o.getHealth() + kazan));
            o.getWorld().spawnParticle(Particle.HEART, o.getLocation().add(0, 1.8, 0), 3, 0.3, 0.2, 0.3, 0);
        }
    }

    /** Element Uyumu: diger elde baska bir asa varsa buyu hasari artar. */
    private double uyum(Player o, Silah silah) {
        Silah diger = eklenti.getSilahYoneticisi().tani(o.getInventory().getItemInOffHand());
        if (diger != null && asaMi(diger) && diger != silah) {
            return 1.0 + eklenti.getConfig().getDouble("silahlar." + silah.kod() + ".uyum-bonusu", 0.15);
        }
        return 1.0;
    }

    // ---------------------------------------------------------- tek hedef

    private LivingEntity bakilan(Player o, double menzil) {
        Location g = o.getEyeLocation();
        var r = o.getWorld().rayTraceEntities(g, g.getDirection(), menzil, 0.6,
                e -> e instanceof LivingEntity && !e.equals(o) && !HedefKorumasi.korunuyor(e));
        return r == null ? null : (LivingEntity) r.getHitEntity();
    }

    private Location bakilanNokta(Player o, double menzil) {
        Location g = o.getEyeLocation();
        var r = o.getWorld().rayTraceBlocks(g, g.getDirection(), menzil);
        return r == null ? g.clone().add(g.getDirection().multiply(menzil)) : r.getHitPosition().toLocation(o.getWorld());
    }

    private void cizgi(Player o, Location hedef, Particle p, Particle.DustOptions toz) {
        Location a = o.getEyeLocation().add(0, -0.25, 0);
        Vector v = hedef.toVector().subtract(a.toVector());
        double uz = v.length();
        if (uz < 0.1) {
            return;
        }
        v.normalize();
        for (double d = 0.8; d < uz; d += 0.5) {
            Location q = a.clone().add(v.clone().multiply(d));
            if (toz != null) {
                o.getWorld().spawnParticle(Particle.DUST, q, 1, 0.03, 0.03, 0.03, 0, toz);
            } else {
                o.getWorld().spawnParticle(p, q, 1, 0.03, 0.03, 0.03, 0.0);
            }
        }
    }

    private void tek(Player o, Silah silah, double hasar, double menzil) {
        switch (silah) {
            case BUZ_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location son = h != null ? h.getLocation().add(0, 1, 0) : bakilanNokta(o, menzil);
                cizgi(o, son, Particle.SNOWFLAKE, null);
                o.getWorld().playSound(o.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.6f);
                if (h != null) {
                    buz(h, o, hasar, 4);
                }
            }
            case ATES_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location son = h != null ? h.getLocation().add(0, 1, 0) : bakilanNokta(o, menzil);
                cizgi(o, son, Particle.FLAME, null);
                o.getWorld().playSound(o.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
                o.getWorld().spawnParticle(Particle.EXPLOSION, son, 1);
                if (h != null) {
                    ates(h, o, hasar, 5);
                }
            }
            case YILDIRIM_ASASI -> {
                LivingEntity h = bakilan(o, menzil);
                Location nokta = h != null ? h.getLocation() : bakilanNokta(o, menzil);
                yildirim(o, nokta, hasar, 3.0);
            }
            default -> {   // ELEMENT_ASASI
                LivingEntity h = bakilan(o, menzil);
                Location nokta = h != null ? h.getLocation() : bakilanNokta(o, menzil);
                cizgi(o, nokta.clone().add(0, 1, 0), null, new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.2f));
                if (h != null) {
                    buz(h, o, hasar * 0.4, 3);
                    ates(h, o, hasar * 0.3, 4);
                }
                yildirim(o, nokta, hasar * 0.3, 2.5);
            }
        }
    }

    // ---------------------------------------------------------- alan

    private List<LivingEntity> cevre(Player o, Location merkez, double r) {
        List<LivingEntity> l = new ArrayList<>();
        for (var e : merkez.getWorld().getNearbyEntities(merkez, r, r, r)) {
            if (e instanceof LivingEntity c && !c.equals(o) && !HedefKorumasi.korunuyor(c)) {
                l.add(c);
            }
        }
        return l;
    }

    private void halka(Location m, double r, Particle p) {
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40.0;
            m.getWorld().spawnParticle(p, m.clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r), 1, 0, 0, 0, 0.0);
        }
    }

    private void alan(Player o, Silah silah, double hasar, double r) {
        Location m = o.getLocation();
        switch (silah) {
            case BUZ_ASASI -> {
                halka(m, r, Particle.SNOWFLAKE);
                m.getWorld().spawnParticle(Particle.SNOWFLAKE, m.clone().add(0, 1, 0), 60, r / 2, 0.6, r / 2, 0.02);
                o.getWorld().playSound(m, Sound.BLOCK_GLASS_BREAK, 1f, 0.7f);
                for (LivingEntity h : cevre(o, m, r)) {
                    buz(h, o, hasar, 5);
                }
            }
            case ATES_ASASI -> {
                halka(m, r, Particle.FLAME);
                m.getWorld().spawnParticle(Particle.LAVA, m.clone().add(0, 1, 0), 30, r / 2, 0.5, r / 2, 0.0);
                o.getWorld().playSound(m, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.6f);
                for (LivingEntity h : cevre(o, m, r)) {
                    ates(h, o, hasar, 6);
                    itme(o, h, 0.9);
                }
            }
            case YILDIRIM_ASASI -> zincir(o, hasar, r, 4);
            default -> {   // ELEMENT_ASASI
                halka(m, r, Particle.SNOWFLAKE);
                halka(m, r * 0.7, Particle.FLAME);
                int vurulan = 0;
                for (LivingEntity h : cevre(o, m, r)) {
                    buz(h, o, hasar * 0.4, 4);
                    ates(h, o, hasar * 0.3, 5);
                    if (vurulan++ < 3) {
                        yildirim(o, h.getLocation(), hasar * 0.3, 2.0);
                    }
                }
            }
        }
    }

    private void zincir(Player o, double hasar, double r, int adet) {
        Location m = o.getLocation();
        LivingEntity simdiki = null;
        double en = Double.MAX_VALUE;
        for (LivingEntity h : cevre(o, m, 14)) {
            double d = h.getLocation().distanceSquared(m);
            if (d < en) {
                en = d;
                simdiki = h;
            }
        }
        if (simdiki == null) {
            o.sendActionBar(net.kyori.adventure.text.Component.text("Yakında hedef yok",
                    net.kyori.adventure.text.format.NamedTextColor.RED));
            return;
        }
        Set<UUID> vurulan = new HashSet<>();
        Location onceki = o.getEyeLocation();
        for (int i = 0; i < adet && simdiki != null; i++) {
            vurulan.add(simdiki.getUniqueId());
            Location nokta = simdiki.getLocation().add(0, 1, 0);
            Vector v = nokta.toVector().subtract(onceki.toVector());
            double uz = v.length();
            if (uz > 0.1) {
                v.normalize();
                for (double d = 0; d < uz; d += 0.4) {
                    o.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, onceki.clone().add(v.clone().multiply(d)), 1, 0, 0, 0, 0);
                }
            }
            simdiki.getWorld().strikeLightningEffect(simdiki.getLocation());
            simdiki.damage(hasar, o);
            simdiki.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
            onceki = nokta;
            LivingEntity sonraki = null;
            double e2 = Double.MAX_VALUE;
            for (LivingEntity h : cevre(o, simdiki.getLocation(), r + 1)) {
                if (vurulan.contains(h.getUniqueId())) {
                    continue;
                }
                double d = h.getLocation().distanceSquared(simdiki.getLocation());
                if (d < e2) {
                    e2 = d;
                    sonraki = h;
                }
            }
            simdiki = sonraki;
        }
    }

    // ---------------------------------------------------------- etkiler

    private void buz(LivingEntity h, Player o, double hasar, int sn) {
        // Kirilgan: zaten yavaslamis hedef buyulerden %20 fazla hasar alir
        if (h.hasPotionEffect(PotionEffectType.SLOWNESS)) {
            hasar *= 1.25;
        }
        h.damage(hasar, o);
        h.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, sn * 20, 2));
        h.setFreezeTicks(Math.min(h.getMaxFreezeTicks() + 60, h.getFreezeTicks() + sn * 40));
        h.getWorld().spawnParticle(Particle.SNOWFLAKE, h.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.02);
    }

    private void ates(LivingEntity h, Player o, double hasar, int sn) {
        // Kor: zaten yanan hedef buyulerden %20 fazla hasar alir
        if (h.getFireTicks() > 0) {
            hasar *= 1.25;
        }
        h.damage(hasar, o);
        h.setFireTicks(sn * 20);
        h.getWorld().spawnParticle(Particle.FLAME, h.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.03);
    }

    private void yildirim(Player o, Location nokta, double hasar, double r) {
        nokta.getWorld().strikeLightningEffect(nokta);
        for (LivingEntity h : cevre(o, nokta, r)) {
            h.damage(hasar, o);
            h.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, h.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
        }
    }

    private void itme(Player o, LivingEntity h, double guc) {
        Vector v = h.getLocation().toVector().subtract(o.getLocation().toVector()).setY(0);
        if (v.lengthSquared() > 0.0001) {
            h.setVelocity(v.normalize().multiply(guc).setY(0.35));
        }
    }
}
