package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Material;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

/**
 * Siniflara ozel hasar ve sifa hesaplamalari.
 */
public class SavasDinleyici implements Listener {

    private final SinifSistemi eklenti;

    public SavasDinleyici(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    // ---------------- Genel hasar (dusme, buyu) ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void genelHasar(EntityDamageEvent olay) {
        if (!(olay.getEntity() instanceof Player oyuncu)) {
            return;
        }
        Sinif sinif = eklenti.getDepo().getSinif(oyuncu);
        if (sinif == null) {
            return;
        }

        // Zirh bonuslari: dusme azaltma + genel alinan hasar azaltma
        if (olay.getCause() == EntityDamageEvent.DamageCause.FALL) {
            double azalt = eklenti.getZirhYoneticisi().bonus(oyuncu, sinif, "dusme_azalt");
            if (azalt > 0) {
                olay.setDamage(olay.getDamage() * Math.max(0.0, 1.0 - azalt));
            }
        }
        double genelAzalt = eklenti.getZirhYoneticisi().bonus(oyuncu, sinif, "alinan_hasar");
        if (genelAzalt > 0) {
            olay.setDamage(olay.getDamage() * Math.max(0.1, 1.0 - genelAzalt));
        }

        // Okcu: dusme hasari azalir (tam muafiyet degil)
        if (sinif == Sinif.OKCU
                && olay.getCause() == EntityDamageEvent.DamageCause.FALL) {
            double carpan = eklenti.getConfig().getDouble("siniflar.okcu.dusme-hasari-carpani", 0.50);
            olay.setDamage(olay.getDamage() * carpan);
            return;
        }

        // Buyucu: buyu ve iksir hasarina direnc
        if (sinif == Sinif.BUYUCU) {
            EntityDamageEvent.DamageCause sebep = olay.getCause();
            if (sebep == EntityDamageEvent.DamageCause.MAGIC
                    || sebep == EntityDamageEvent.DamageCause.POISON
                    || sebep == EntityDamageEvent.DamageCause.WITHER
                    || sebep == EntityDamageEvent.DamageCause.DRAGON_BREATH) {
                double carpan = eklenti.getConfig().getDouble("siniflar.buyucu.sihir-hasari-direnci", 0.50);
                carpan *= 1.0 - eklenti.getZirhYoneticisi().setBonusu(oyuncu, Sinif.BUYUCU)
                        - eklenti.getZirhYoneticisi().bonus(oyuncu, Sinif.BUYUCU, "buyu_direnci");
                olay.setDamage(olay.getDamage() * carpan);
            }
        }
    }

    // ---------------- Varliklar arasi hasar ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void varlikHasari(EntityDamageByEntityEvent olay) {
        Entity vuran = olay.getDamager();

        // 1) Mermi (ok / iksir) hasari
        if (vuran instanceof Projectile mermi) {
            mermiHasari(olay, mermi);
        }
        // 2) Yakin dovus
        else if (vuran instanceof Player saldiran) {
            yakinDovus(olay, saldiran);
        }

        // 3) Hedefin sinifina gore alinan hasar duzenlemesi
        if (olay.getEntity() instanceof Player hedef) {
            alinanHasar(olay, hedef, vuran);
        }
    }

    private void mermiHasari(EntityDamageByEntityEvent olay, Projectile mermi) {
        ProjectileSource kaynak = mermi.getShooter();
        if (!(kaynak instanceof Player atici)) {
            return;
        }
        Sinif sinif = eklenti.getDepo().getSinif(atici);
        if (sinif == null) {
            return;
        }

        if (sinif == Sinif.OKCU && mermi instanceof AbstractArrow) {
            double carpan = eklenti.getConfig().getDouble("siniflar.okcu.ok-hasar-carpani", 1.35);
            carpan *= 1.0 + eklenti.getZirhYoneticisi().setBonusu(atici, Sinif.OKCU)
                    + eklenti.getZirhYoneticisi().bonus(atici, Sinif.OKCU, "ok_hasari");
            double kritik = eklenti.getZirhYoneticisi().bonus(atici, Sinif.OKCU, "ok_kritik");
            if (kritik > 0 && java.util.concurrent.ThreadLocalRandom.current().nextDouble() < kritik) {
                carpan *= 1.75;
                olay.getEntity().getWorld().spawnParticle(org.bukkit.Particle.CRIT,
                        olay.getEntity().getLocation().add(0, 1.0, 0), 20, 0.3, 0.4, 0.3, 0.2);
                atici.playSound(atici.getLocation(), "entity.player.attack.crit", 1.0f, 1.2f);
            }
            olay.setDamage(olay.getDamage() * carpan);
        }

        if (sinif == Sinif.AVCI && mizrakMermisiMi(mermi)) {
            double carpan = eklenti.getConfig()
                    .getDouble("siniflar.avci.mizrak-hasar-carpani", 1.30);
            carpan *= 1.0 + eklenti.getZirhYoneticisi().setBonusu(atici, Sinif.AVCI)
                    + eklenti.getZirhYoneticisi().bonus(atici, Sinif.AVCI, "mizrak_hasari");
            olay.setDamage(olay.getDamage() * carpan);
        }

        if (sinif == Sinif.BUYUCU && mermi instanceof ThrownPotion) {
            double carpan = eklenti.getConfig().getDouble("siniflar.buyucu.iksir-hasar-carpani", 1.40);
            carpan *= 1.0 + eklenti.getZirhYoneticisi().setBonusu(atici, Sinif.BUYUCU)
                    + eklenti.getZirhYoneticisi().bonus(atici, Sinif.BUYUCU, "iksir_hasari");
            olay.setDamage(olay.getDamage() * carpan);
        }
    }

    private void yakinDovus(EntityDamageByEntityEvent olay, Player saldiran) {
        Sinif sinif = eklenti.getDepo().getSinif(saldiran);
        if (sinif == null) {
            return;
        }

        double carpan = 1.0;
        switch (sinif) {
            case RAHIP -> carpan = eklenti.getConfig()
                    .getDouble("siniflar.rahip.yakin-dovus-carpani", 0.85);
            case OKCU -> carpan = eklenti.getConfig()
                    .getDouble("siniflar.okcu.yakin-dovus-carpani", 0.85);
            case AVCI -> {
                Material elde = saldiran.getInventory().getItemInMainHand().getType();
                carpan = mizrakMi(elde)
                        ? eklenti.getConfig().getDouble("siniflar.avci.mizrak-hasar-carpani", 1.30)
                                * (1.0 + eklenti.getZirhYoneticisi().setBonusu(saldiran, Sinif.AVCI)
                                + eklenti.getZirhYoneticisi().bonus(saldiran, Sinif.AVCI, "mizrak_hasari"))
                        : eklenti.getConfig().getDouble("siniflar.avci.diger-silah-carpani", 0.90);
            }
            case SUIKASTCI -> {
                ItemStack elde = saldiran.getInventory().getItemInMainHand();
                if (kilicMi(elde.getType()) && eklenti.getSilahYoneticisi().tani(elde) == null) {
                    carpan = eklenti.getConfig()
                            .getDouble("siniflar.suikastci.kilic-hasar-carpani", 1.25);
                }
                if (arkadanMi(saldiran, olay.getEntity())) {
                    carpan = Math.max(carpan, eklenti.getConfig()
                            .getDouble("siniflar.suikastci.arkadan-vurus-carpani", 1.60))
                            * (1.0 + eklenti.getZirhYoneticisi().setBonusu(saldiran, Sinif.SUIKASTCI)
                            + eklenti.getZirhYoneticisi().bonus(saldiran, Sinif.SUIKASTCI, "arkadan_vurus"));
                }
            }
            default -> {
                // Savasci'nin saldiri hasari attribute ile verilir,
                // Buyucu icin yakin dovus degisikligi yoktur
            }
        }

        // Zirh bonusu: yakin dovus hasari (her sinif kendi setinden)
        double yakin = eklenti.getZirhYoneticisi().bonus(saldiran, sinif, "yakin_hasar");
        if (yakin > 0) {
            carpan *= 1.0 + yakin;
        }

        if (carpan != 1.0) {
            olay.setDamage(olay.getDamage() * carpan);
        }
    }

    private void alinanHasar(EntityDamageByEntityEvent olay, Player hedef, Entity vuran) {
        Sinif sinif = eklenti.getDepo().getSinif(hedef);
        if (sinif == null) {
            return;
        }

        double kacinma = eklenti.getZirhYoneticisi().bonus(hedef, sinif, "kacinma");
        if (kacinma > 0 && java.util.concurrent.ThreadLocalRandom.current().nextDouble() < kacinma) {
            olay.setCancelled(true);
            hedef.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, hedef.getLocation().add(0, 1.0, 0), 12, 0.3, 0.5, 0.3, 0.02);
            hedef.playSound(hedef.getLocation(), "entity.player.attack.sweep", 0.8f, 1.6f);
            return;
        }

        if (sinif == Sinif.SAVASCI) {
            double set = eklenti.getZirhYoneticisi().setBonusu(hedef, Sinif.SAVASCI);
            if (set > 0) {
                olay.setDamage(olay.getDamage() * (1.0 - set));
            }
        }

        if (sinif == Sinif.SAVASCI && vuran instanceof AbstractArrow) {
            double carpan = eklenti.getConfig()
                    .getDouble("siniflar.savasci.alinan-ok-hasari-carpani", 0.85);
            olay.setDamage(olay.getDamage() * carpan);
        }

        if (sinif == Sinif.SUIKASTCI) {
            double carpan = eklenti.getConfig()
                    .getDouble("siniflar.suikastci.alinan-hasar-carpani", 1.10);
            olay.setDamage(olay.getDamage() * carpan);
        }
    }

    // ---------------- Zirh: can calma + diken ----------------

    private boolean yansitiyor = false;

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    @SuppressWarnings("deprecation")
    public void zirhVurusEtkileri(EntityDamageByEntityEvent olay) {
        if (yansitiyor) {
            return;
        }
        double hasar = olay.getFinalDamage();
        if (hasar <= 0) {
            return;
        }
        // Saldiran: can calma
        Player saldiran = null;
        if (olay.getDamager() instanceof Player p) {
            saldiran = p;
        } else if (olay.getDamager() instanceof Projectile m && m.getShooter() instanceof Player p) {
            saldiran = p;
        }
        if (saldiran != null) {
            Sinif s = eklenti.getDepo().getSinif(saldiran);
            double calma = eklenti.getZirhYoneticisi().bonus(saldiran, s, "can_calma");
            if (calma > 0) {
                double yeni = Math.min(saldiran.getMaxHealth(), saldiran.getHealth() + hasar * calma);
                saldiran.setHealth(Math.max(0.1, yeni));
            }
        }
        // Vurus efektleri: yakma, yavaslatma, kanama (sinifa ozgu zirh bonuslari)
        if (saldiran != null && olay.getEntity() instanceof org.bukkit.entity.LivingEntity kurban
                && !kurban.equals(saldiran)) {
            Sinif s = eklenti.getDepo().getSinif(saldiran);
            double yakma = eklenti.getZirhYoneticisi().bonus(saldiran, s, "yakma");
            if (yakma > 0) {
                kurban.setFireTicks(Math.max(kurban.getFireTicks(), (int) (yakma * 20)));
            }
            double yavas = eklenti.getZirhYoneticisi().bonus(saldiran, s, "yavaslatma");
            if (yavas > 0) {
                kurban.addPotionEffect(new org.bukkit.potion.PotionEffect(
                        org.bukkit.potion.PotionEffectType.SLOWNESS, (int) (yavas * 20) + 20, 0, false, true, true));
            }
            double kanama = eklenti.getZirhYoneticisi().bonus(saldiran, s, "kanama");
            boolean mizrakla = mizrakMi(saldiran.getInventory().getItemInMainHand().getType())
                    || (olay.getDamager() instanceof Projectile pm && mizrakMermisiMi(pm));
            if (kanama > 0 && mizrakla) {
                eklenti.getKanamaYoneticisi().uygula(kurban, saldiran, (int) Math.ceil(kanama), 2.0, 0.0);
            }
        }

        // Savunan: diken (yalniz dogrudan yakin dovus)
        if (olay.getEntity() instanceof Player hedef && olay.getDamager() instanceof org.bukkit.entity.LivingEntity vuran
                && !vuran.equals(hedef)) {
            Sinif s = eklenti.getDepo().getSinif(hedef);
            double diken = eklenti.getZirhYoneticisi().bonus(hedef, s, "diken");
            if (diken > 0) {
                yansitiyor = true;
                try {
                    vuran.damage(hasar * diken, hedef);
                } finally {
                    yansitiyor = false;
                }
            }
        }
    }

    // ---------------- Sifa ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void sifaAlma(EntityRegainHealthEvent olay) {
        if (!(olay.getEntity() instanceof Player oyuncu)) {
            return;
        }
        if (eklenti.getDepo().getSinif(oyuncu) != Sinif.RAHIP) {
            return;
        }
        double carpan = eklenti.getConfig().getDouble("siniflar.rahip.alinan-sifa-carpani", 1.50)
                + eklenti.getZirhYoneticisi().bonus(oyuncu, Sinif.RAHIP, "sifa_gucu");
        olay.setAmount(olay.getAmount() * carpan);
    }

    // ---------------- Yardimcilar ----------------

    /**
     * Mizrak sayilan her sey: her tur mizrak (_SPEAR ile biten wooden, stone,
     * copper, iron, golden, diamond, netherite) ve uc disli mizrak (TRIDENT).
     *
     * Material sabiti yerine isim kontrolu yapilir; boylece ileride eklenen
     * yeni mizrak turleri kod degismeden otomatik kapsanir.
     */
    private boolean mizrakMi(Material materyal) {
        if (materyal == null) {
            return false;
        }
        String ad = materyal.name();
        return ad.endsWith("_SPEAR") || ad.equals("SPEAR") || ad.equals("TRIDENT");
    }

    /** Firlatilmis mizrak mermisi (uc disli mizrak). */
    private boolean mizrakMermisiMi(Projectile mermi) {
        return mermi != null && mermi.getType().name().equals("TRIDENT");
    }

    /** Her tur kilic (_SWORD ile biten); yeni eklenen turler (bakir vb.) otomatik kapsanir. */
    private boolean kilicMi(Material materyal) {
        return materyal != null && materyal.name().endsWith("_SWORD");
    }

    /** Saldiran, hedefin arkasinda mi? */
    private boolean arkadanMi(Player saldiran, Entity hedef) {
        Vector hedefBakis = hedef.getLocation().getDirection().setY(0).normalize();
        Vector fark = saldiran.getLocation().toVector()
                .subtract(hedef.getLocation().toVector()).setY(0);
        if (fark.lengthSquared() < 0.0001) {
            return false;
        }
        return hedefBakis.dot(fark.normalize()) < -0.4;
    }
}
