package com.sinifsistemi.zirh;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Herhangi bir esyayi bir veya birden fazla sinifa kilitler.
 * Kilit PDC'de "savasci,okcu" gibi saklanir ve lore'a bir satir eklenir.
 */
public class SinifKilidi {

    private final SinifSistemi eklenti;
    private final NamespacedKey kilitAnahtar;
    private final NamespacedKey satirAnahtar;

    public SinifKilidi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
        this.kilitAnahtar = new NamespacedKey(eklenti, "sinif_kilit");
        this.satirAnahtar = new NamespacedKey(eklenti, "sinif_kilit_satir");
    }

    /** Esyanin izinli siniflari; kilitli degilse bos kume. */
    public Set<Sinif> izinliler(ItemStack esya) {
        Set<Sinif> sonuc = EnumSet.noneOf(Sinif.class);
        if (esya == null || !esya.hasItemMeta()) {
            return sonuc;
        }
        String ham = esya.getItemMeta().getPersistentDataContainer()
                .get(kilitAnahtar, PersistentDataType.STRING);
        if (ham == null || ham.isBlank()) {
            return sonuc;
        }
        for (String parca : ham.split(",")) {
            Sinif s = Sinif.bul(parca);
            if (s != null) {
                sonuc.add(s);
            }
        }
        return sonuc;
    }

    public boolean kilitliMi(ItemStack esya) {
        return !izinliler(esya).isEmpty();
    }

    /** Oyuncu (sinifi ve yetkisiyle) bu esyayi kullanabilir mi? */
    public boolean kullanabilir(org.bukkit.entity.Player oyuncu, ItemStack esya) {
        Set<Sinif> izinli = izinliler(esya);
        if (izinli.isEmpty() || oyuncu.hasPermission("sinif.silah.serbest")) {
            return true;
        }
        return izinli.contains(eklenti.getDepo().getSinif(oyuncu));
    }

    public String siniflarMetni(Set<Sinif> siniflar) {
        List<String> adlar = new ArrayList<>();
        for (Sinif s : siniflar) {
            adlar.add(s.basitRenkliAd());
        }
        return String.join("<gray>, ", adlar);
    }

    /** Esyayi verilen siniflara kilitler (onceki kilidin lore satirini degistirir). */
    public ItemStack kilitle(ItemStack esya, List<Sinif> siniflar) {
        ItemMeta meta = esya.getItemMeta();
        kilitSatiriniSil(meta);

        StringBuilder kod = new StringBuilder();
        Set<Sinif> kume = EnumSet.noneOf(Sinif.class);
        for (Sinif s : siniflar) {
            if (kume.add(s)) {
                if (kod.length() > 0) {
                    kod.append(',');
                }
                kod.append(s.kod());
            }
        }

        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Mesaj.esya(""));
        String satir = Mesaj.ham("kilit-satiri").replace("<sinif>", siniflarMetni(kume));
        lore.add(Mesaj.esya(satir));
        meta.lore(lore);

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(kilitAnahtar, PersistentDataType.STRING, kod.toString());
        pdc.set(satirAnahtar, PersistentDataType.INTEGER, 2);
        esya.setItemMeta(meta);
        return esya;
    }

    /** Kilidi kaldirir. */
    public ItemStack kilidiKaldir(ItemStack esya) {
        ItemMeta meta = esya.getItemMeta();
        kilitSatiriniSil(meta);
        meta.getPersistentDataContainer().remove(kilitAnahtar);
        meta.getPersistentDataContainer().remove(satirAnahtar);
        esya.setItemMeta(meta);
        return esya;
    }

    private void kilitSatiriniSil(ItemMeta meta) {
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        Integer eklenen = pdc.get(satirAnahtar, PersistentDataType.INTEGER);
        List<Component> lore = meta.lore();
        if (eklenen != null && lore != null && lore.size() >= eklenen) {
            lore = new ArrayList<>(lore.subList(0, lore.size() - eklenen));
            meta.lore(lore.isEmpty() ? null : lore);
        }
        pdc.remove(satirAnahtar);
    }
}
