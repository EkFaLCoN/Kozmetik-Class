package com.sinifsistemi.zirh;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Her sinifa ozel 4 parcalik zirh seti (3D modelli) uretir.
 * Her parca uretilirken o sinifa kilitlenir.
 */
public class ZirhYoneticisi {

    public enum Parca {
        KASK("kask", EquipmentSlot.HEAD, EquipmentSlotGroup.HEAD, Material.NETHERITE_HELMET, 0.15),
        GOGUSLUK("gogusluk", EquipmentSlot.CHEST, EquipmentSlotGroup.CHEST, Material.NETHERITE_CHESTPLATE, 0.40),
        PANTOLON("pantolon", EquipmentSlot.LEGS, EquipmentSlotGroup.LEGS, Material.NETHERITE_LEGGINGS, 0.30),
        BOT("bot", EquipmentSlot.FEET, EquipmentSlotGroup.FEET, Material.NETHERITE_BOOTS, 0.15);

        public final String kod;
        public final EquipmentSlot slot;
        public final EquipmentSlotGroup grup;
        public final Material taban;
        public final double pay;

        Parca(String kod, EquipmentSlot slot, EquipmentSlotGroup grup, Material taban, double pay) {
            this.kod = kod;
            this.slot = slot;
            this.grup = grup;
            this.taban = taban;
            this.pay = pay;
        }

        public static Parca bul(String metin) {
            if (metin == null) {
                return null;
            }
            String m = metin.toLowerCase(Locale.ROOT).replace('ğ', 'g').replace('ı', 'i')
                    .replace('ş', 's').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c');
            for (Parca p : values()) {
                if (p.kod.equals(m)) {
                    return p;
                }
            }
            return switch (m) {
                case "migfer", "baslik", "kukuleta", "sapka", "helmet" -> KASK;
                case "yelek", "kaftan", "gogus", "chestplate" -> GOGUSLUK;
                case "tozluk", "etek", "leggings" -> PANTOLON;
                case "ayakkabi", "boots", "botlar" -> BOT;
                default -> null;
            };
        }
    }

    private final SinifSistemi eklenti;
    private final NamespacedKey anahtar;

    public ZirhYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
        this.anahtar = new NamespacedKey(eklenti, "ozel_zirh");
    }

    /** Oyun ici ad. */
    private String parcaAdi(Sinif sinif, Parca parca) {
        String[][] adlar = {
                // kask, gogusluk, pantolon, bot  (Sinif enum sirasi: SAVASCI, SUIKASTCI, RAHIP, OKCU, BUYUCU, AVCI)
                {"Savaş Miğferi", "Savaş Göğüslüğü", "Savaş Tozluğu", "Savaş Çizmeleri"},
                {"Gölge Kukuleta", "Gölge Yeleği", "Gölge Pantolonu", "Sessiz Adımlar"},
                {"Şafak Tacı", "Şafak Cübbesi", "Şafak Eteği", "Şafak Sandaletleri"},
                {"Gözcü Kukuletası", "Gözcü Yeleği", "Gözcü Pantolonu", "Gözcü Çizmeleri"},
                {"Kadim Büyücü Şapkası", "Kadim Büyücü Cübbesi", "Kadim Büyücü Eteği", "Kadim Büyücü Ayakkabıları"},
                {"Kemik Başlık", "Postlu Göğüslük", "Postlu Pantolon", "Postlu Çizmeler"}
        };
        int sira = switch (sinif) {
            case SAVASCI -> 0;
            case SUIKASTCI -> 1;
            case RAHIP -> 2;
            case OKCU -> 3;
            case BUYUCU -> 4;
            case AVCI -> 5;
        };
        return adlar[sira][parca.ordinal()];
    }

    /** Insan gorunumlu zirh katmani (resourcepack equipment dosyasi adi). */
    private String katmanAdi(Sinif sinif) {
        return switch (sinif) {
            case SAVASCI -> "warrior";
            case SUIKASTCI -> "assassin";
            case RAHIP -> "shaman";
            case OKCU -> "archer";
            case BUYUCU -> "mage";
            case AVCI -> "hunter";
        };
    }

    private String modelAdi(Sinif sinif) {
        return switch (sinif) {
            case SAVASCI -> "savasci";
            case SUIKASTCI -> "suikastci";
            case RAHIP -> "rahip";
            case OKCU -> "okcu";
            case BUYUCU -> "buyucu";
            case AVCI -> "avci";
        };
    }

    public ItemStack uret(Sinif sinif, Parca parca) {
        ItemStack esya = new ItemStack(parca.taban);
        ItemMeta meta = esya.getItemMeta();

        meta.displayName(Mesaj.esya(sinif.renk() + "<bold>" + parcaAdi(sinif, parca)));

        List<Component> lore = new ArrayList<>();
        lore.add(Mesaj.esya("<dark_gray><italic>" + sinif.ad() + " sınıfının zırhı"));
        lore.add(Mesaj.esya(""));
        String yol = "zirh." + modelAdi(sinif) + ".";
        double puan = eklenti.getConfig().getDouble(yol + "puan", 10.0) * parca.pay;
        double sertlik = eklenti.getConfig().getDouble(yol + "sertlik", 0.0) * parca.pay;
        double hiz = eklenti.getConfig().getDouble(yol + "hiz-yuzde", 0.0) * parca.pay;
        double can = eklenti.getConfig().getDouble(yol + "can", 0.0) * parca.pay;
        double itme = eklenti.getConfig().getDouble(yol + "itme-direnci", 0.0) * parca.pay;
        lore.add(Mesaj.esya("<gold>✦ <gray>Zırh: <white>" + sayi(puan)));
        if (sertlik > 0) {
            lore.add(Mesaj.esya("<gold>✦ <gray>Sertlik: <white>" + sayi(sertlik)));
        }
        if (hiz > 0) {
            lore.add(Mesaj.esya("<gold>✦ <gray>Hareket hızı: <white>+%" + sayi(hiz * 100)));
        }
        if (can > 0) {
            lore.add(Mesaj.esya("<gold>✦ <gray>Can: <white>+" + sayi(can / 2.0) + " kalp"));
        }
        if (itme > 0) {
            lore.add(Mesaj.esya("<gold>✦ <gray>İtme direnci: <white>+%" + sayi(itme * 100)));
        }
        lore.add(Mesaj.esya(""));
        lore.add(Mesaj.esya("<light_purple>✦ <gray>Set bonusu <dark_gray>(4 parça): <white>" + setAciklama(sinif)));
        meta.lore(lore);

        // Resourcepack 3D modeli
        try {
            meta.setItemModel(new NamespacedKey("cursedclasses",
                    "zirh_" + modelAdi(sinif) + "_" + parca.kod));
        } catch (Throwable hata) {
            eklenti.getLogger().warning("Zirh item_model ayarlanamadi: " + hata.getMessage());
        }

        // Giyilince gorunum: kask kafada 3D item modeli olarak cizilir (katman yok),
        // diger parcalar sinifin zirh katmanini kullanir.
        try {
            EquippableComponent giyilebilir = meta.getEquippable();
            giyilebilir.setSlot(parca.slot);
            if (parca == Parca.KASK) {
                giyilebilir.setModel(null);
            } else {
                giyilebilir.setModel(new NamespacedKey("cursedclasses", katmanAdi(sinif)));
            }
            meta.setEquippable(giyilebilir);
        } catch (Throwable hata) {
            eklenti.getLogger().warning("Zirh equippable ayarlanamadi: " + hata.getMessage());
        }

        // Ozel attribute'lar (varsayilan netherite degerlerinin yerine gecer)
        ekle(meta, "ARMOR", puan, AttributeModifier.Operation.ADD_NUMBER, parca, "zirh_puan",
                "ARMOR", "GENERIC_ARMOR");
        ekle(meta, "TOUGHNESS", sertlik, AttributeModifier.Operation.ADD_NUMBER, parca, "zirh_sertlik",
                "ARMOR_TOUGHNESS", "GENERIC_ARMOR_TOUGHNESS");
        ekle(meta, "SPEED", hiz, AttributeModifier.Operation.ADD_SCALAR, parca, "zirh_hiz",
                "MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");
        ekle(meta, "HEALTH", can, AttributeModifier.Operation.ADD_NUMBER, parca, "zirh_can",
                "MAX_HEALTH", "GENERIC_MAX_HEALTH");
        ekle(meta, "KB", itme, AttributeModifier.Operation.ADD_NUMBER, parca, "zirh_itme",
                "KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE");

        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ADDITIONAL_TOOLTIP);

        meta.getPersistentDataContainer().set(anahtar, PersistentDataType.STRING,
                sinif.kod() + "_" + parca.kod);
        esya.setItemMeta(meta);

        // Sinif kilidi (sadece o sinif giyebilir)
        return eklenti.getSinifKilidi().kilitle(esya, java.util.List.of(sinif));
    }

    /** Set bonusunun kisa aciklamasi (lore icin). */
    private String setAciklama(Sinif sinif) {
        double b = eklenti.getConfig().getDouble("zirh." + modelAdi(sinif) + ".set-bonus", 0.0);
        int y = (int) Math.round(b * 100);
        return switch (sinif) {
            case SAVASCI -> "alınan tüm hasar %" + y + " azalır";
            case SUIKASTCI -> "arkadan vuruş hasarı %" + y + " artar";
            case RAHIP -> "şifa aurası menzili +" + (int) Math.round(b) + " blok";
            case OKCU -> "ok hasarı %" + y + " artar";
            case BUYUCU -> "iksir hasarı %" + y + " artar, büyü direnci %" + y + " artar";
            case AVCI -> "mızrak hasarı %" + y + " artar";
        };
    }

    /** Oyuncu bu sinifin 4 parcalik setini tamamen giymis mi? */
    public boolean setTam(org.bukkit.entity.Player oyuncu, Sinif sinif) {
        ItemStack[] parcalar = oyuncu.getInventory().getArmorContents();
        for (Parca p : Parca.values()) {
            ItemStack esya = parcalar[p.slot == EquipmentSlot.FEET ? 0 : p.slot == EquipmentSlot.LEGS ? 1
                    : p.slot == EquipmentSlot.CHEST ? 2 : 3];
            if (esya == null || !esya.hasItemMeta()) {
                return false;
            }
            String deger = esya.getItemMeta().getPersistentDataContainer()
                    .get(anahtar, PersistentDataType.STRING);
            if (deger == null || !deger.equals(sinif.kod() + "_" + p.kod)) {
                return false;
            }
        }
        return true;
    }

    /** Set tamamsa bonus degeri (yoksa 0). */
    public double setBonusu(org.bukkit.entity.Player oyuncu, Sinif sinif) {
        if (sinif == null || !setTam(oyuncu, sinif)) {
            return 0.0;
        }
        return eklenti.getConfig().getDouble("zirh." + modelAdi(sinif) + ".set-bonus", 0.0);
    }

    public boolean zirhMi(ItemStack esya) {
        return esya != null && esya.hasItemMeta()
                && esya.getItemMeta().getPersistentDataContainer().has(anahtar, PersistentDataType.STRING);
    }

    private void ekle(ItemMeta meta, String etiket, double deger, AttributeModifier.Operation islem,
                      Parca parca, String ad, String... adaylar) {
        if (deger == 0) {
            return;
        }
        Attribute attr = coz(adaylar);
        if (attr == null) {
            return;
        }
        meta.addAttributeModifier(attr, new AttributeModifier(
                new NamespacedKey(eklenti, ad + "_" + parca.kod), deger, islem, parca.grup));
    }

    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Field alan = Attribute.class.getField(ad);
                Object deger = alan.get(null);
                if (deger instanceof Attribute a) {
                    return a;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // sonraki aday
            }
        }
        eklenti.getLogger().warning("Attribute bulunamadi: " + String.join(" / ", adaylar));
        return null;
    }

    private String sayi(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(Locale.US, "%.1f", d);
    }
}
