package com.sinifsistemi.silah;

import org.bukkit.entity.Allay;
import org.bukkit.entity.Ambient;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ComplexEntityPart;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Wither;
import org.bukkit.entity.WaterMob;
import org.bukkit.entity.AbstractVillager;

/**
 * Silah YETENEKLERININ (alan hasari, kanama, golge sicramasi, gizli vurus bonusu...)
 * hedef alamayacagi varliklar: hayvanlar, evcillestirilebilen her sey, Ender Dragon,
 * Wither, koylu / gezgin tuccar ve armor stand.
 * Duz vurus (vanilla hasar) bu siniftan etkilenmez.
 */
public final class HedefKorumasi {

    private HedefKorumasi() {
    }

    public static boolean korunuyor(Entity e) {
        if (e == null || e instanceof Player) {
            return false;
        }
        if (e instanceof ComplexEntityPart parca) {
            return korunuyor(parca.getParent());
        }
        if (e instanceof ArmorStand || e instanceof EnderDragon || e instanceof Wither
                || e instanceof AbstractVillager || e instanceof Villager
                || e instanceof Tameable) {
            return true;
        }
        if (e instanceof Monster) {
            return false;                        // Hoglin vb. dusmanca "hayvanlar" korunmaz
        }
        return e instanceof Animals || e instanceof WaterMob || e instanceof Ambient || e instanceof Allay;
    }
}
