package com.sinifsistemi.silah;

import com.sinifsistemi.Sinif;
import org.bukkit.Material;

import java.util.List;
import java.util.Locale;

/**
 * Sunucudaki ozel siniflara ait silahlar.
 * Her silah yalnizca kendi sinifi tarafindan kullanilabilir.
 */
public enum Silah {

    KANLI_SAVAS_BALTASI(
            "kanli_savas_baltasi",
            "Kanlı Savaş Baltası",
            "#C41E1E",
            "#4A0507",
            Material.NETHERITE_AXE,
            "cursedclasses:kanli_savas_baltasi",
            Sinif.SAVASCI,
            List.of(
                    "<dark_gray><italic>Çift ağzının biri hâlâ kurumadı.",
                    "",
                    "<gray>Kadim bir savaş alanından çıkarılan bu balta,",
                    "<gray>döktüğü kanı asla unutmaz. Sol ağzı sürekli",
                    "<gray><dark_red>kan damlatır<gray> ve her vuruşta daha da susar.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_red>✦ <gray>Saldırı hasarı: <white>12 <dark_gray>(6 kalp, 1.2 hız)",
                    "<dark_red>✦ <gray>Vuruşta <white>Kanama <dark_gray>(6 sn, saniyede 1.75 kalp)",
                    "<dark_red>✦ <gray>Kanama hasarının <white>%35'ini <gray>can olarak emer",
                    "<dark_red>✦ <white>Öfke<gray>: canın azaldıkça <white>%50<gray>'a kadar fazla hasar",
                    "<dark_red>✦ <white>Kanlı Hasat<gray>: kanayan hedefe <white>%35 <gray>fazla hasar",
                    "<dark_red>✦ <white>Kan Zırhı<gray>: çevrende kanayan her hedef için",
                    "<dark_gray>   <white>%8 <dark_gray>az hasar alırsın <dark_gray>(en fazla %32)",
                    "<dark_red>✦ <white>Kan Kalkanı<gray>: her öldürmede <white>+2 kalp <gray>kalkan",
                    "<dark_gray>   ve yetenek beklemeleri <white>5 sn <dark_gray>kısalır",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_red>➤ <gray>Sağ tık: <white>Kan Çağrısı <dark_gray>(çevreyi kanatır, 20 sn)",
                    "<dark_red>➤ <gray>Shift + sağ tık: <white>Kan Fırtınası",
                    "<dark_gray>   4 kalp alan hasarı + savurma + kanama <dark_gray>(35 sn)",
                    "",
                    "<dark_red>⚔ <gray>Yalnızca <red><bold>Savaşçı<gray> sınıfı kullanabilir."
            )
    ),

    ALACAKARANLIK(
            "alacakaranlik",
            "Alacakaranlık",
            "#8A5CFF",
            "#1B0A33",
            Material.NETHERITE_SWORD,
            "cursedclasses:alacakaranlik",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Işığın bittiği yerde başlar.",
                    "",
                    "<gray>Karanlık tarafın hançeri. Gölgeye çekilmeyi",
                    "<gray>ve arkadan gelmeyi sever; ışıkta işe yaramaz.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_purple>✦ <gray>Saldırı hasarı: <white>7.5 <dark_gray>(çok hızlı tempo)",
                    "<dark_purple>✦ <white>Gölgeden Vuruş<gray>: arkadan veya görünmezken",
                    "<dark_gray>   <white>%30 <dark_gray>fazla hasar + hedefe körlük",
                    "<dark_purple>✦ <white>Kardeş Ağız<gray>: diğer el <white>Şafak <gray>tutuyorsa <white>%15 <gray>hasar",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_purple>➤ <gray>Sağ tık: <white>Gölge Sıçraması",
                    "<dark_gray>   en yakın hedefin arkasına ışınlanırsın <dark_gray>(12 sn)",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    ),

    SAFAK(
            "safak",
            "Şafak",
            "#FFD98A",
            "#B26B00",
            Material.NETHERITE_SWORD,
            "cursedclasses:safak",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Karanlığın en koyu anından hemen sonra.",
                    "",
                    "<gray>Aydınlık tarafın hançeri. Aynı hedefe binen",
                    "<gray>vuruşlarla ışık toplar ve son darbede boşaltır.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_purple>✦ <gray>Saldırı hasarı: <white>7.5 <dark_gray>(çok hızlı tempo)",
                    "<gold>✦ <white>Işık Yükü<gray>: aynı hedefe her vuruş <white>%12 <gray>hasar ekler",
                    "<dark_gray>   <white>5. yükte <dark_gray>patlar: ek hasar + sana <white>2 kalp",
                    "<gold>✦ <white>Kardeş Ağız<gray>: diğer el <white>Alacakaranlık <gray>tutuyorsa <white>%15 <gray>hasar",
                    "",
                    "<gold><bold>Kullanım",
                    "<gold>➤ <gray>Sağ tık: <white>Şafak Kesişi",
                    "<dark_gray>   öne atılıp önündeki herkesi biçersin <dark_gray>(14 sn)",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    ),

    BUZ_ASASI(
            "buz_asasi",
            "Buz Asası",
            "#C8F3FF",
            "#3A8DDE",
            Material.STICK,
            "cursedclasses:asa_buz",
            Sinif.BUYUCU,
            List.of(
                    "<dark_gray><italic>Donmuş bir kış, tek bir değnekte.",
                    "",
                    "<gray>Hedeflerini yavaşlatır, dondurur ve hareketsiz bırakır.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<aqua>✦ <white>Soğuk Aura<gray>: elde tutarken yakındaki düşmanlar <white>yavaşlar<gray>, donmazsın",
                    "<aqua>✦ <white>Buz Zırhı<gray>: elde tutarken <white>Direnç I",
                    "<aqua>✦ <white>Donmuş Karşılık<gray>: sana vuran düşman <white>yavaşlar",
                    "<aqua>✦ <white>Kırılgan<gray>: yavaşlamış hedefler büyülerden <white>%25 <gray>fazla hasar alır",
                    "<aqua>✦ <white>Element Uyumu<gray>: diğer elde başka bir asa varsa büyü hasarı <white>%15 <gray>artar",
                    "",
                    "<gold><bold>Kullanım",
                    "<aqua>➤ <gray>Sağ tık: <white>Buz Mızrağı <dark_gray>(6 sn)",
                    "<aqua>➤ <gray>Shift + sağ tık: <white>Don Çemberi <dark_gray>(çevreyi dondurur, 14 sn)",
                    "",
                    "<blue>⚔ <gray>Yalnızca <blue><bold>Büyücü<gray> sınıfı kullanabilir."
            )
    ),

    ATES_ASASI(
            "ates_asasi",
            "Ateş Asası",
            "#FFD27A",
            "#D8350F",
            Material.STICK,
            "cursedclasses:asa_ates",
            Sinif.BUYUCU,
            List.of(
                    "<dark_gray><italic>Alevin boynuzları hâlâ sıcak.",
                    "",
                    "<gray>Hedeflerini yakar, alev halkasıyla etrafını sarar.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<red>✦ <white>Alev Zırhı<gray>: elde tutarken <white>ateş ve lav hasarı <gray>almazsın",
                    "<red>✦ <white>Kor Ruhu<gray>: elde tutarken <white>Güç I",
                    "<red>✦ <white>Kızgın Karşılık<gray>: sana vuran düşman <white>yanar",
                    "<red>✦ <white>Kor<gray>: yanan hedefler büyülerden <white>%25 <gray>fazla hasar alır",
                    "<red>✦ <white>Kor Hasadı<gray>: yanan düşmanı öldürünce <white>2.5 kalp <gray>kazanırsın",
                    "<red>✦ <white>Element Uyumu<gray>: diğer elde başka bir asa varsa büyü hasarı <white>%15 <gray>artar",
                    "",
                    "<gold><bold>Kullanım",
                    "<red>➤ <gray>Sağ tık: <white>Alev Topu <dark_gray>(5 sn)",
                    "<red>➤ <gray>Shift + sağ tık: <white>Alev Halkası <dark_gray>(çevreyi yakar, 14 sn)",
                    "",
                    "<blue>⚔ <gray>Yalnızca <blue><bold>Büyücü<gray> sınıfı kullanabilir."
            )
    ),

    YILDIRIM_ASASI(
            "yildirim_asasi",
            "Yıldırım Asası",
            "#E6D9FF",
            "#7B4DFF",
            Material.STICK,
            "cursedclasses:asa_yildirim",
            Sinif.BUYUCU,
            List.of(
                    "<dark_gray><italic>Gök gürültüsü elinin içinde.",
                    "",
                    "<gray>Gökten yıldırım indirir, hedefler arasında zincirleme sıçrar.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<light_purple>✦ <white>Elektrik Yükü<gray>: elde tutarken <white>Hız II <gray>ve <white>Acele I",
                    "<light_purple>✦ <white>Element Uyumu<gray>: diğer elde başka bir asa varsa büyü hasarı <white>%15 <gray>artar",
                    "<light_purple>✦ <white>Yıldırım Refleksi<gray>: sana vurana <white>%35 <gray>şansla yıldırım düşer",
                    "",
                    "<gold><bold>Kullanım",
                    "<light_purple>➤ <gray>Sağ tık: <white>Yıldırım Çarpması <dark_gray>(8 sn)",
                    "<light_purple>➤ <gray>Shift + sağ tık: <white>Zincir Yıldırım <dark_gray>(4 hedefe sıçrar, 14 sn)",
                    "",
                    "<blue>⚔ <gray>Yalnızca <blue><bold>Büyücü<gray> sınıfı kullanabilir."
            )
    ),

    ELEMENT_ASASI(
            "element_asasi",
            "Element Asası",
            "#FFD27A",
            "#7B4DFF",
            Material.STICK,
            "cursedclasses:asa_elementler",
            Sinif.BUYUCU,
            List.of(
                    "<dark_gray><italic>Buz, ateş ve yıldırım tek elde.",
                    "",
                    "<gray>Üç elementin gücünü birleştirir.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<white>✦ <white>Üç Element<gray>: ateşe bağışıklık, <white>soğuk aura<gray>, <white>Direnç I, Güç I <gray>ve <white>Hız I <gray>birlikte",
                    "<white>✦ <white>Karşılık<gray>: sana vurana <white>yavaşlık + yanma + yıldırım refleksi",
                    "<white>✦ <white>Kırılgan, Kor, Kor Hasadı<gray>: üç elementin tüm bonusları",
                    "<white>✦ <white>Element Uyumu<gray>: diğer elde başka bir asa varsa büyü hasarı <white>%15 <gray>artar",
                    "",
                    "<gold><bold>Kullanım",
                    "<white>➤ <gray>Sağ tık: <white>Element Işını <dark_gray>(10 sn)",
                    "<white>➤ <gray>Shift + sağ tık: <white>Element Fırtınası <dark_gray>(geniş alan, 25 sn)",
                    "",
                    "<blue>⚔ <gray>Yalnızca <blue><bold>Büyücü<gray> sınıfı kullanabilir."
            )
    ),

    GOLGE_PELERINI(
            "golge_pelerini",
            "Gölge Pelerini",
            "#6F5CA8",
            "#120A20",
            Material.PHANTOM_MEMBRANE,
            "cursedclasses:golge_pelerini",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Üzerine çektiğinde dünya seni unutur.",
                    "",
                    "<gray>Gölgeden dokunmuş bir pelerin. Giyilmez;",
                    "<gray>elinde tutarken sağ tıkla, tüm benliğini örter.",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_purple>➤ <gray>Sağ tık: <white>Gölgeye Karış <dark_gray>(bekleme aynı anda akar: 45 sn)",
                    "<dark_gray>   <white>45 saniye <dark_gray>boyunca kimse seni göremez",
                    "<dark_gray>   zırhın, silahın ve isim etiketin de gizlenir",
                    "<dark_gray>   tekrar sağ tıklarsan gölge erken dağılır",
                    "<dark_purple>✦ <gray>Gizliyken yaptığın ilk vuruş <white>%50 <gray>fazla vurur",
                    "",
                    "<dark_red>✦ <gray>Saldırırsan veya hasar alırsan gölge dağılır.",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    );

    private final String kod;
    private final String ad;
    private final String gradyanBas;
    private final String gradyanSon;
    private final Material taban;
    private final String modelKimligi;
    private final Sinif gerekliSinif;
    private final List<String> aciklama;

    Silah(String kod, String ad, String gradyanBas, String gradyanSon, Material taban,
          String modelKimligi, Sinif gerekliSinif, List<String> aciklama) {
        this.kod = kod;
        this.ad = ad;
        this.gradyanBas = gradyanBas;
        this.gradyanSon = gradyanSon;
        this.taban = taban;
        this.modelKimligi = modelKimligi;
        this.gerekliSinif = gerekliSinif;
        this.aciklama = aciklama;
    }

    public String kod() {
        return kod;
    }

    public String ad() {
        return ad;
    }

    public String renkliAd() {
        return "<gradient:" + gradyanBas + ":" + gradyanSon + "><bold>" + ad + "</bold></gradient>";
    }

    public Material taban() {
        return taban;
    }

    public String modelKimligi() {
        return modelKimligi;
    }

    public Sinif gerekliSinif() {
        return gerekliSinif;
    }

    public List<String> aciklama() {
        return aciklama;
    }

    public static Silah bul(String metin) {
        if (metin == null || metin.isBlank()) {
            return null;
        }
        String temiz = metin.trim().toLowerCase(Locale.ROOT)
                .replace('ı', 'i').replace('ş', 's').replace('ç', 'c')
                .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')
                .replace(' ', '_');
        for (Silah silah : values()) {
            if (silah.kod.equals(temiz) || silah.name().equalsIgnoreCase(temiz)) {
                return silah;
            }
        }
        return null;
    }
}
