package com.sinifsistemi;

import com.sinifsistemi.dinleyici.MenuDinleyici;
import com.sinifsistemi.dinleyici.OyuncuDinleyici;
import com.sinifsistemi.dinleyici.SavasDinleyici;
import com.sinifsistemi.duello.DuelloKomutu;
import com.sinifsistemi.duello.DuelloYoneticisi;
import com.sinifsistemi.irk.IrkKomutu;
import com.sinifsistemi.irk.IrkSistemi;
import com.sinifsistemi.dinleyici.SilahDinleyici;
import com.sinifsistemi.komut.SilahKomutu;
import com.sinifsistemi.komut.SinifKomutu;
import com.sinifsistemi.komut.SinifYonetimKomutu;
import com.sinifsistemi.silah.GolgeYoneticisi;
import com.sinifsistemi.silah.KanamaYoneticisi;
import com.sinifsistemi.silah.SilahYoneticisi;
import com.sinifsistemi.yetenek.YetenekYoneticisi;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class SinifSistemi extends JavaPlugin {

    private SinifDeposu depo;
    private YetenekYoneticisi yetenekYoneticisi;
    private SilahYoneticisi silahYoneticisi;
    private com.sinifsistemi.zirh.SinifKilidi sinifKilidi;
    private com.sinifsistemi.zirh.ZirhYoneticisi zirhYoneticisi;
    private com.sinifsistemi.dinleyici.KilitDinleyici kilitDinleyici;
    private KanamaYoneticisi kanamaYoneticisi;
    private GolgeYoneticisi golgeYoneticisi;
    private SilahDinleyici silahDinleyici;
    private MenuDinleyici menuDinleyici;
    private IrkSistemi irkSistemi;
    private DuelloYoneticisi duelloYoneticisi;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        Mesaj.baslat(this);

        this.depo = new SinifDeposu(this);
        this.yetenekYoneticisi = new YetenekYoneticisi(this);
        this.silahYoneticisi = new SilahYoneticisi(this);
        this.kanamaYoneticisi = new KanamaYoneticisi(this);
        this.golgeYoneticisi = new GolgeYoneticisi(this);
        this.sinifKilidi = new com.sinifsistemi.zirh.SinifKilidi(this);
        this.zirhYoneticisi = new com.sinifsistemi.zirh.ZirhYoneticisi(this);
        this.kilitDinleyici = new com.sinifsistemi.dinleyici.KilitDinleyici(this);
        this.silahDinleyici = new SilahDinleyici(this);
        this.menuDinleyici = new MenuDinleyici(this);

        komutKaydet("class", new SinifKomutu(this));
        komutKaydet("classadmin", new SinifYonetimKomutu(this));
        komutKaydet("weapon", new SilahKomutu(this));

        Bukkit.getPluginManager().registerEvents(menuDinleyici, this);
        Bukkit.getPluginManager().registerEvents(new OyuncuDinleyici(this), this);
        Bukkit.getPluginManager().registerEvents(new SavasDinleyici(this), this);
        Bukkit.getPluginManager().registerEvents(silahDinleyici, this);
        Bukkit.getPluginManager().registerEvents(kilitDinleyici, this);

        yetenekYoneticisi.baslat();
        kanamaYoneticisi.baslat();
        golgeYoneticisi.baslat();
        silahDinleyici.gorevBaslat();
        kilitDinleyici.gorevBaslat();
        menuDinleyici.gorevBaslat();

        // Reload sonrasi cevrimici oyunculara efektleri geri ver
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            yetenekYoneticisi.uygula(oyuncu);
        }

        // ---- Irk ve duello sistemleri ----
        this.irkSistemi = new IrkSistemi(this);
        this.irkSistemi.baslat();

        this.duelloYoneticisi = new DuelloYoneticisi(this);
        this.duelloYoneticisi.baslat();

        komutKaydet("race", new IrkKomutu(this, irkSistemi, false));
        komutKaydet("raceadmin", new IrkKomutu(this, irkSistemi, true));
        komutKaydet("duel", new DuelloKomutu(this, duelloYoneticisi, false));
        komutKaydet("duelarea", new DuelloKomutu(this, duelloYoneticisi, true));

        getLogger().info("ClassAndRegion etkinlestirildi. Iyi oyunlar!");
    }

    @Override
    public void onDisable() {
        if (duelloYoneticisi != null) {
            duelloYoneticisi.durdur();
        }
        if (irkSistemi != null) {
            irkSistemi.durdur();
        }
        if (menuDinleyici != null) {
            menuDinleyici.gorevDurdur();
        }
        if (silahDinleyici != null) {
            silahDinleyici.gorevDurdur();
        }
        if (kilitDinleyici != null) {
            kilitDinleyici.gorevDurdur();
        }
        if (kanamaYoneticisi != null) {
            kanamaYoneticisi.durdur();
        }
        if (golgeYoneticisi != null) {
            golgeYoneticisi.durdur();
        }
        if (yetenekYoneticisi != null) {
            yetenekYoneticisi.durdur();
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                yetenekYoneticisi.temizle(oyuncu);
            }
        }
        if (depo != null) {
            depo.kaydet();
        }
        getLogger().info("ClassAndRegion devre disi birakildi.");
    }

    private <T extends CommandExecutor & TabCompleter> void komutKaydet(String ad, T calistirici) {
        PluginCommand komut = getCommand(ad);
        if (komut == null) {
            getLogger().severe("Komut bulunamadi: " + ad);
            return;
        }
        komut.setExecutor(calistirici);
        komut.setTabCompleter(calistirici);
    }

    public SinifDeposu getDepo() {
        return depo;
    }

    public YetenekYoneticisi getYetenekYoneticisi() {
        return yetenekYoneticisi;
    }

    public MenuDinleyici getMenuDinleyici() {
        return menuDinleyici;
    }

    public IrkSistemi getIrkSistemi() {
        return irkSistemi;
    }

    public DuelloYoneticisi getDuelloYoneticisi() {
        return duelloYoneticisi;
    }

    public com.sinifsistemi.zirh.SinifKilidi getSinifKilidi() {
        return sinifKilidi;
    }

    public com.sinifsistemi.zirh.ZirhYoneticisi getZirhYoneticisi() {
        return zirhYoneticisi;
    }

    public SilahYoneticisi getSilahYoneticisi() {
        return silahYoneticisi;
    }

    public GolgeYoneticisi getGolgeYoneticisi() {
        return golgeYoneticisi;
    }

    public KanamaYoneticisi getKanamaYoneticisi() {
        return kanamaYoneticisi;
    }
}
