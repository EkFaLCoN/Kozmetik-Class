package com.sinifsistemi.komut;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.zirh.ZirhYoneticisi;
import com.sinifsistemi.silah.Silah;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SilahKomutu implements CommandExecutor, TabCompleter {

    private final SinifSistemi eklenti;

    public SilahKomutu(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender gonderen, @NotNull Command komut,
                             @NotNull String etiket, @NotNull String[] argumanlar) {
        argumanlar = KomutCeviri.cevir(argumanlar);

        if (!gonderen.hasPermission("sinif.silah.yonet")) {
            Mesaj.gonder(gonderen, "yetkin-yok");
            return true;
        }

        if (argumanlar.length == 0) {
            Mesaj.gonderHam(gonderen, "kullanim-silah");
            return true;
        }

        String altKomut = argumanlar[0].toLowerCase(Locale.ROOT);

        switch (altKomut) {
            case "ver" -> {
                if (argumanlar.length < 2) {
                    Mesaj.gonderHam(gonderen, "kullanim-silah");
                    return true;
                }
                Silah silah = Silah.bul(argumanlar[1]);
                if (silah == null) {
                    Mesaj.gonder(gonderen, "silah-bulunamadi",
                            Mesaj.degisken("silah", argumanlar[1]));
                    return true;
                }

                Player hedef;
                if (argumanlar.length >= 3) {
                    hedef = Bukkit.getPlayerExact(argumanlar[2]);
                    if (hedef == null) {
                        Mesaj.gonder(gonderen, "oyuncu-bulunamadi",
                                Mesaj.degisken("oyuncu", argumanlar[2]));
                        return true;
                    }
                } else if (gonderen instanceof Player oyuncu) {
                    hedef = oyuncu;
                } else {
                    Mesaj.gonder(gonderen, "sadece-oyuncu");
                    return true;
                }

                ItemStack esya = eklenti.getSilahYoneticisi().uret(silah);
                var artan = hedef.getInventory().addItem(esya);
                for (ItemStack kalan : artan.values()) {
                    hedef.getWorld().dropItemNaturally(hedef.getLocation(), kalan);
                }

                Mesaj.gonder(hedef, "silah-alindi", Mesaj.degisken("silah", silah.renkliAd()));
                if (!hedef.equals(gonderen)) {
                    Mesaj.gonder(gonderen, "silah-verildi", Mesaj.degisken(
                            "oyuncu", hedef.getName(), "silah", silah.renkliAd()));
                }
            }
            case "kilit" -> {
                if (!(gonderen instanceof Player oyuncu)) {
                    Mesaj.gonder(gonderen, "sadece-oyuncu");
                    return true;
                }
                ItemStack elde = oyuncu.getInventory().getItemInMainHand();
                if (elde.getType().isAir()) {
                    Mesaj.gonder(oyuncu, "kilit-elde-esya-yok");
                    return true;
                }
                if (argumanlar.length < 2) {
                    Mesaj.gonderHam(gonderen, "kullanim-silah");
                    return true;
                }
                if (argumanlar[1].equalsIgnoreCase("kaldir") || argumanlar[1].equalsIgnoreCase("sil")) {
                    oyuncu.getInventory().setItemInMainHand(eklenti.getSinifKilidi().kilidiKaldir(elde));
                    Mesaj.gonder(oyuncu, "kilit-kaldirildi");
                    return true;
                }
                List<Sinif> siniflar = new ArrayList<>();
                for (int i = 1; i < argumanlar.length; i++) {
                    if (argumanlar[i].equalsIgnoreCase("hepsi")) {
                        siniflar.addAll(List.of(Sinif.values()));
                        continue;
                    }
                    Sinif sinif = Sinif.bul(argumanlar[i]);
                    if (sinif == null) {
                        Mesaj.gonder(oyuncu, "sinif-bulunamadi", Mesaj.degisken("sinif", argumanlar[i]));
                        return true;
                    }
                    siniflar.add(sinif);
                }
                oyuncu.getInventory().setItemInMainHand(eklenti.getSinifKilidi().kilitle(elde, siniflar));
                Mesaj.gonder(oyuncu, "kilit-konuldu", Mesaj.degisken("sinif",
                        eklenti.getSinifKilidi().siniflarMetni(
                                eklenti.getSinifKilidi().izinliler(oyuncu.getInventory().getItemInMainHand()))));
            }
            case "zirh" -> {
                if (argumanlar.length < 2) {
                    Mesaj.gonderHam(gonderen, "kullanim-silah");
                    return true;
                }
                Sinif sinif = Sinif.bul(argumanlar[1]);
                if (sinif == null) {
                    Mesaj.gonder(gonderen, "sinif-bulunamadi", Mesaj.degisken("sinif", argumanlar[1]));
                    return true;
                }
                List<ZirhYoneticisi.Parca> parcalar = new ArrayList<>();
                String parcaMetni = argumanlar.length >= 3 ? argumanlar[2] : "hepsi";
                if (parcaMetni.equalsIgnoreCase("hepsi")) {
                    parcalar.addAll(List.of(ZirhYoneticisi.Parca.values()));
                } else {
                    ZirhYoneticisi.Parca parca = ZirhYoneticisi.Parca.bul(parcaMetni);
                    if (parca == null) {
                        Mesaj.gonder(gonderen, "zirh-bulunamadi", Mesaj.degisken("parca", parcaMetni));
                        return true;
                    }
                    parcalar.add(parca);
                }
                Player hedef;
                if (argumanlar.length >= 4) {
                    hedef = Bukkit.getPlayerExact(argumanlar[3]);
                    if (hedef == null) {
                        Mesaj.gonder(gonderen, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", argumanlar[3]));
                        return true;
                    }
                } else if (gonderen instanceof Player oyuncu) {
                    hedef = oyuncu;
                } else {
                    Mesaj.gonder(gonderen, "sadece-oyuncu");
                    return true;
                }
                for (ZirhYoneticisi.Parca parca : parcalar) {
                    ItemStack esya = eklenti.getZirhYoneticisi().uret(sinif, parca);
                    for (ItemStack kalan : hedef.getInventory().addItem(esya).values()) {
                        hedef.getWorld().dropItemNaturally(hedef.getLocation(), kalan);
                    }
                }
                Mesaj.gonder(hedef, "zirh-alindi", Mesaj.degisken("sinif", sinif.basitRenkliAd()));
                if (!hedef.equals(gonderen)) {
                    Mesaj.gonder(gonderen, "zirh-verildi", Mesaj.degisken(
                            "oyuncu", hedef.getName(), "sinif", sinif.basitRenkliAd()));
                }
            }
            case "liste", "listele" -> {
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
                gonderen.sendMessage(Mesaj.ayristir(" <gold><bold>ÖZEL SİLAHLAR"));
                gonderen.sendMessage(Mesaj.ayristir(""));
                for (Silah silah : Silah.values()) {
                    gonderen.sendMessage(Mesaj.ayristir(" " + silah.renkliAd()));
                    gonderen.sendMessage(Mesaj.ayristir("   <dark_gray>kod: <gray>" + silah.kod()
                            + " <dark_gray>| sınıf: " + silah.gerekliSinif().basitRenkliAd()));
                }
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
            }
            default -> Mesaj.gonderHam(gonderen, "kullanim-silah");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender gonderen, @NotNull Command komut,
                                      @NotNull String etiket, @NotNull String[] argumanlar) {
        final String[] orijinal = argumanlar;
        argumanlar = KomutCeviri.cevir(argumanlar);
        List<String> sonuc = new ArrayList<>();
        if (!gonderen.hasPermission("sinif.silah.yonet")) {
            return sonuc;
        }
        if (argumanlar.length == 1) {
            for (String secenek : List.of("give", "list", "lock", "armor")) {
                if (secenek.startsWith(orijinal[0].toLowerCase(Locale.ROOT))) {
                    sonuc.add(secenek);
                }
            }
        } else if (argumanlar.length == 2 && argumanlar[0].equalsIgnoreCase("ver")) {
            for (Silah silah : Silah.values()) {
                if (silah.kod().startsWith(argumanlar[1].toLowerCase(Locale.ROOT))) {
                    sonuc.add(silah.kod());
                }
            }
        } else if (argumanlar.length >= 2 && argumanlar[0].equalsIgnoreCase("kilit")) {
            List<String> aday = new ArrayList<>(List.of("remove", "all"));
            for (Sinif sinif : Sinif.values()) {
                aday.add(sinif.kod());
            }
            for (String a : aday) {
                if (a.startsWith(orijinal[orijinal.length - 1].toLowerCase(Locale.ROOT))) {
                    sonuc.add(a);
                }
            }
        } else if (argumanlar.length == 2 && argumanlar[0].equalsIgnoreCase("zirh")) {
            for (Sinif sinif : Sinif.values()) {
                if (sinif.kod().startsWith(argumanlar[1].toLowerCase(Locale.ROOT))) {
                    sonuc.add(sinif.kod());
                }
            }
        } else if (argumanlar.length == 3 && argumanlar[0].equalsIgnoreCase("zirh")) {
            for (String a : List.of("helmet", "chestplate", "leggings", "boots", "all")) {
                if (a.startsWith(orijinal[2].toLowerCase(Locale.ROOT))) {
                    sonuc.add(a);
                }
            }
        } else if (argumanlar.length == 4 && argumanlar[0].equalsIgnoreCase("zirh")) {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                if (oyuncu.getName().toLowerCase(Locale.ROOT).startsWith(argumanlar[3].toLowerCase(Locale.ROOT))) {
                    sonuc.add(oyuncu.getName());
                }
            }
        } else if (argumanlar.length == 3 && argumanlar[0].equalsIgnoreCase("ver")) {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                if (oyuncu.getName().toLowerCase(Locale.ROOT)
                        .startsWith(argumanlar[2].toLowerCase(Locale.ROOT))) {
                    sonuc.add(oyuncu.getName());
                }
            }
        }
        return sonuc;
    }
}
