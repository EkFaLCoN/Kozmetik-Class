package com.sinifsistemi.komut;

import java.util.Locale;
import java.util.Map;

/** Ingilizce alt komutlari ic (eski) adlara cevirir; eski Turkce adlar da calismaya devam eder. */
public final class KomutCeviri {

    private static final Map<String, String> ILK = Map.ofEntries(
            Map.entry("info", "bilgi"), Map.entry("list", "liste"), Map.entry("set", "ver"),
            Map.entry("give", "ver"), Map.entry("reset", "sifirla"), Map.entry("lock", "kilit"),
            Map.entry("armor", "zirh"), Map.entry("members", "uyeler"), Map.entry("duel", "duello"),
            Map.entry("create", "olustur"), Map.entry("delete", "sil"), Map.entry("accept", "kabul"),
            Map.entry("deny", "ret"), Map.entry("decline", "ret"), Map.entry("reload", "yenile"));

    private static final Map<String, String> DIGER = Map.of(
            "all", "hepsi", "remove", "kaldir", "helmet", "kask", "chestplate", "gogusluk",
            "leggings", "pantolon", "boots", "bot");

    private KomutCeviri() {
    }

    public static String[] cevir(String[] a) {
        String[] s = a.clone();
        for (int i = 0; i < s.length; i++) {
            String k = s[i].toLowerCase(Locale.ROOT);
            String m = i == 0 ? ILK.get(k) : DIGER.get(k);
            if (m != null) {
                s[i] = m;
            }
        }
        return s;
    }
}
