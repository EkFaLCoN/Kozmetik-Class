# KozmetikSistemi

Paper 26.x için kanat ve peri kozmetikleri (güç + görünüm). **ClassAndRegion eklentisinden bağımsızdır**, tek başına çalışır.

- `/cosmetic` — menü (`liste`, `cikar`, `kanat`, `peri`)
- `/cosmeticadmin unlock|kilitle|bilgi <oyuncu> [kod|hepsi]`
- İzinler: `kozmetik.kullan` (varsayılan herkes), `kozmetik.admin`, `kozmetik.hepsi`

## ClassAndRegion ile birlikte kullanım (isteğe bağlı)
İki eklenti birbirine bağımlı değildir; yalnızca scoreboard etiketi üzerinden konuşurlar:
- ClassAndRegion Gölge Pelerini aktifken oyuncuya `cv_golge` etiketi ekler → kozmetikler gizlenir.
- Peri takılıyken oyuncuya `cv_peri` etiketi eklenir → mob eklentisi ganimet sandığını boşaltır.

## ClassAndRegion'dan geçiş
Eski `plugins/ClassAndRegion/kozmetikler.yml` dosyasını `plugins/KozmetikSistemi/` klasörüne kopyala (oyuncuların açtığı/taktığı kozmetikler korunur). Config yeni eklentide ayrıdır: `plugins/KozmetikSistemi/config.yml`.

## Resourcepack
Modeller `Created_By_MRWQLF` resourcepack'indedir (`cursedclasses:kozmetik_*`).

## Komutlar (İngilizce) ve Kozmetik Kilidi
- `/cosmetic [list|unequip|wings]` — menü / liste / hepsini çıkar
- `/cosmeticadmin unlock <oyuncu> <kod|all>` — istediğin kanadı/kozmetiği o oyuncu için aç
- `/cosmeticadmin lock <oyuncu> <kod|all>` — geri kilitle (takılıysa çıkarılır)
- `/cosmeticadmin info <oyuncu>` — durum
- Kodlar: `/cosmetic list`. Eski Türkçe adlar alias olarak çalışır.
- Kilit: `kozmetik.yetkiyle-acilabilir: false` (varsayılan) iken OP / `*` kilidi aşamaz; kozmetikler yalnızca yönetici açınca kullanılır. Girişte kilitli takılı kozmetik otomatik çıkarılır.
