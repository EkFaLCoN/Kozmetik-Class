# KozmetikSistemi

Paper 26.x için kanat ve peri kozmetikleri (güç + görünüm). **ClassAndRegion eklentisinden bağımsızdır**, tek başına çalışır.

- `/kozmetik` — menü (`liste`, `cikar`, `kanat`, `peri`)
- `/kozmetikyonetim ac|kilitle|bilgi <oyuncu> [kod|hepsi]`
- İzinler: `kozmetik.kullan` (varsayılan herkes), `kozmetik.admin`, `kozmetik.hepsi`

## ClassAndRegion ile birlikte kullanım (isteğe bağlı)
İki eklenti birbirine bağımlı değildir; yalnızca scoreboard etiketi üzerinden konuşurlar:
- ClassAndRegion Gölge Pelerini aktifken oyuncuya `cv_golge` etiketi ekler → kozmetikler gizlenir.
- Peri takılıyken oyuncuya `cv_peri` etiketi eklenir → mob eklentisi ganimet sandığını boşaltır.

## ClassAndRegion'dan geçiş
Eski `plugins/ClassAndRegion/kozmetikler.yml` dosyasını `plugins/KozmetikSistemi/` klasörüne kopyala (oyuncuların açtığı/taktığı kozmetikler korunur). Config yeni eklentide ayrıdır: `plugins/KozmetikSistemi/config.yml`.

## Resourcepack
Modeller `Created_By_MRWQLF` resourcepack'indedir (`cursedclasses:kozmetik_*`).
