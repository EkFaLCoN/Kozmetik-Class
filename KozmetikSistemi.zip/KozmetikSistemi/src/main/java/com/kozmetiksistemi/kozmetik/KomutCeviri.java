package com.kozmetiksistemi.kozmetik;

import java.util.Locale;
import java.util.Map;

/** Ingilizce alt komutlari ic (eski) adlara cevirir; eski Turkce adlar da calismaya devam eder. */
public final class KomutCeviri {

    private static final Map<String, String> ILK = Map.of(
            "list", "liste", "unequip", "cikar", "info", "bilgi", "unlock", "ac", "lock", "kilitle",
            "wings", "kanat");

    private KomutCeviri() {
    }

    public static String[] cevir(String[] a) {
        String[] s = a.clone();
        for (int i = 0; i < s.length; i++) {
            String k = s[i].toLowerCase(Locale.ROOT);
            if (i == 0 && ILK.containsKey(k)) {
                s[i] = ILK.get(k);
            } else if (i > 0 && k.equals("all")) {
                s[i] = "hepsi";
            }
        }
        return s;
    }
}
