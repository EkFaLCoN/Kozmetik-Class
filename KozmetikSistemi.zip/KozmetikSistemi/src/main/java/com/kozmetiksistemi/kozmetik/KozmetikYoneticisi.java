package com.kozmetiksistemi.kozmetik;

import com.kozmetiksistemi.KozmetikSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Kozmetiklerin tamami buradan yonetilir:
 *
 *  - Gorunum: oyuncuya binen (passenger) bir ItemDisplay. Boylece zirh
 *    slotlari bosta kalir, kozmetik oyunun kendi esyalariyla catismaz.
 *  - Guc: kozmetik_ onekli AttributeModifier'lar + surekli iksir etkileri.
 *    Sinif yeteneklerinden tamamen bagimsizdir, birbirini silmez.
 *  - Kayit: kozmetikler.yml (acilan kozmetikler + takili olanlar).
 */
public class KozmetikYoneticisi {

    private final KozmetikSistemi eklenti;

    /** Oyuncu -> kategori -> takili kozmetik */
    private final Map<UUID, Map<Kozmetik.Kategori, Kozmetik>> takililar = new HashMap<>();
    /** Oyuncu -> acilmis kozmetikler */
    private final Map<UUID, Set<Kozmetik>> acilanlar = new HashMap<>();
    /** Oyuncu -> kategori -> canli gorunum varligi */
    private final Map<UUID, Map<Kozmetik.Kategori, UUID>> gorunumler = new HashMap<>();

    private final Map<String, NamespacedKey> anahtarlar = new HashMap<>();

    /** Takip modunda: sandiga giden (serbest ucan) peri gorunumleri. */
    private final Set<UUID> serbestPeri = new HashSet<>();

    /**
     * true  -> gorunumler oyuncuya YOLCU olarak biner (eski yontem; bazi ortamlarda
     *          gorunumler kayboluyor).
     * false -> (varsayilan) gorunumler her tick oyuncunun omzuna isinlanir, istemci
     *          teleport-interpolation ile yumusatir; yolcu limiti/gorunmezlik sorunu yok.
     */
    private boolean binisModu() {
        return eklenti.getConfig().getBoolean("kozmetik.binis-modu", false);
    }

    /** Takip modunda gorunumu oyuncunun binis noktasina (ayakta 1.8 blok) tasir. */
    private void takip(Player oyuncu, ItemDisplay ekran, double egimFazi, float yon) {
        Location l = oyuncu.getLocation();
        l.add(0, OYUNCU_BOYU - egimFazi * 0.30, 0);
        l.setYaw(yon);
        l.setPitch(0f);
        Location e = ekran.getLocation();
        if (e.getWorld() != null && e.getWorld().equals(l.getWorld())
                && e.distanceSquared(l) < 1.0E-5 && Math.abs(e.getYaw() - yon) < 0.01f) {
            return;
        }
        ekran.teleport(l);
    }

    private final Attribute MAX_CAN;
    private final Attribute HAREKET_HIZI;
    private final Attribute ZIRH;
    private final Attribute ZIRH_SAGLAMLIGI;
    private final Attribute GERI_TEPME_DIRENCI;
    private final Attribute SALDIRI_HASARI;

    private File dosya;
    private FileConfiguration veri;
    private BukkitTask gorev;
    private BukkitTask yonGorevi;
    private int sayac;

    /** Oyuncu -> kategori -> o an gosterilen animasyon karesi */
    private final Map<UUID, Map<Kozmetik.Kategori, Integer>> kareler = new HashMap<>();
    /** Oyuncu -> kategori -> animasyon fazi (kare cinsinden, ondalikli) */
    private final Map<UUID, Map<Kozmetik.Kategori, Double>> animFazi = new HashMap<>();
    /** Oyuncu -> son konum (hareket hizini olcmek icin) */
    private final Map<UUID, Location> sonKonum = new HashMap<>();


    public KozmetikYoneticisi(KozmetikSistemi eklenti) {
        this.eklenti = eklenti;

        MAX_CAN = coz("MAX_HEALTH", "GENERIC_MAX_HEALTH");
        HAREKET_HIZI = coz("MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");
        ZIRH = coz("ARMOR", "GENERIC_ARMOR");
        ZIRH_SAGLAMLIGI = coz("ARMOR_TOUGHNESS", "GENERIC_ARMOR_TOUGHNESS");
        GERI_TEPME_DIRENCI = coz("KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE");
        SALDIRI_HASARI = coz("ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE");

        yukle();
    }

    /** Attribute alan adlari surumler arasi degisti; adaylari sirayla dener. */
    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Object deger = Attribute.class.getField(ad).get(null);
                if (deger instanceof Attribute attribute) {
                    return attribute;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // sonraki aday
            }
        }
        return null;
    }

    private NamespacedKey anahtar(String ad) {
        return anahtarlar.computeIfAbsent(ad, a -> new NamespacedKey(eklenti, "kozmetik_" + a));
    }

    // ------------------------------------------------------------------
    //  Veri
    // ------------------------------------------------------------------

    public void yukle() {
        takililar.clear();
        acilanlar.clear();

        dosya = new File(eklenti.getDataFolder(), "kozmetikler.yml");
        if (!dosya.exists()) {
            try {
                if (!eklenti.getDataFolder().exists() && !eklenti.getDataFolder().mkdirs()) {
                    eklenti.getLogger().warning("Eklenti klasoru olusturulamadi!");
                }
                if (!dosya.createNewFile()) {
                    eklenti.getLogger().warning("kozmetikler.yml olusturulamadi!");
                }
            } catch (IOException hata) {
                eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml olusturulurken hata", hata);
            }
        }
        veri = YamlConfiguration.loadConfiguration(dosya);

        if (veri.isConfigurationSection("oyuncular")) {
            for (String ham : veri.getConfigurationSection("oyuncular").getKeys(false)) {
                UUID kimlik;
                try {
                    kimlik = UUID.fromString(ham);
                } catch (IllegalArgumentException yoksay) {
                    eklenti.getLogger().warning("Gecersiz UUID atlandi: " + ham);
                    continue;
                }

                Set<Kozmetik> acik = new LinkedHashSet<>();
                for (String kod : veri.getStringList("oyuncular." + ham + ".acilanlar")) {
                    Kozmetik k = Kozmetik.bul(kod);
                    if (k != null) {
                        acik.add(k);
                    }
                }
                if (!acik.isEmpty()) {
                    acilanlar.put(kimlik, acik);
                }

                Map<Kozmetik.Kategori, Kozmetik> takili = new EnumMap<>(Kozmetik.Kategori.class);
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    Kozmetik k = Kozmetik.bul(
                            veri.getString("oyuncular." + ham + ".takili." + kategori.kod()));
                    if (k != null && k.kategori() == kategori) {
                        takili.put(kategori, k);
                    }
                }
                if (!takili.isEmpty()) {
                    takililar.put(kimlik, takili);
                }
            }
        }
        eklenti.getLogger().info(takililar.size() + " oyuncunun kozmetik verisi yuklendi.");
    }

    public void kaydet() {
        if (veri == null || dosya == null) {
            return;
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml kaydedilemedi", hata);
        }
    }

    private void diskeYaz(UUID kimlik) {
        String yol = "oyuncular." + kimlik;

        List<String> acikKodlar = new ArrayList<>();
        for (Kozmetik k : acilanlar.getOrDefault(kimlik, Collections.emptySet())) {
            acikKodlar.add(k.kod());
        }
        veri.set(yol + ".acilanlar", acikKodlar.isEmpty() ? null : acikKodlar);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            Kozmetik k = takili == null ? null : takili.get(kategori);
            veri.set(yol + ".takili." + kategori.kod(), k == null ? null : k.kod());
        }
        kaydet();
    }

    // ------------------------------------------------------------------
    //  Erisim / kilit
    // ------------------------------------------------------------------

    /** Oyuncu bu kozmetigi kullanabiliyor mu? */
    public boolean acikMi(Player oyuncu, Kozmetik kozmetik) {
        if (eklenti.getConfig().getBoolean("kozmetik.hepsi-acik", false)) {
            return true;
        }
        // Varsayilan: yetki (OP / "*") kilidi ASLA asmaz; yalnizca yonetici acinca acilir.
        if (eklenti.getConfig().getBoolean("kozmetik.yetkiyle-acilabilir", false)
                && (oyuncu.hasPermission("kozmetik.hepsi")
                || oyuncu.hasPermission("kozmetik." + kozmetik.kod()))) {
            return true;
        }
        return acilanlar.getOrDefault(oyuncu.getUniqueId(), Collections.emptySet()).contains(kozmetik);
    }

    /** Kilitli olup takili kalan kozmetikleri cikarir (giriste / kilit politikasi degisince). */
    public void kilitlileriCikar(Player oyuncu) {
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            Kozmetik t = takili(oyuncu, kategori);
            if (t != null && !acikMi(oyuncu, t)) {
                cikar(oyuncu, kategori);
            }
        }
    }

    /** Kozmetigi kalici olarak acar. true -> yeni acildi, false -> zaten aciktI. */
    public boolean ac(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.computeIfAbsent(kimlik, k -> new LinkedHashSet<>());
        if (!kume.add(kozmetik)) {
            return false;
        }
        diskeYaz(kimlik);
        return true;
    }

    /** Acilmis kozmetigi geri alir. Takiliysa cikarilir. */
    public boolean kilitle(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.get(kimlik);
        boolean vardi = kume != null && kume.remove(kozmetik);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        if (takili != null && takili.get(kozmetik.kategori()) == kozmetik) {
            Player oyuncu = Bukkit.getPlayer(kimlik);
            if (oyuncu != null) {
                cikar(oyuncu, kozmetik.kategori());
            } else {
                takili.remove(kozmetik.kategori());
            }
        }
        if (vardi) {
            diskeYaz(kimlik);
        }
        return vardi;
    }

    public Set<Kozmetik> acilanlari(UUID kimlik) {
        return Collections.unmodifiableSet(
                acilanlar.getOrDefault(kimlik, Collections.emptySet()));
    }

    public Kozmetik takili(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        return harita == null ? null : harita.get(kategori);
    }

    // ------------------------------------------------------------------
    //  Takma / cikarma
    // ------------------------------------------------------------------

    public void tak(Player oyuncu, Kozmetik kozmetik) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita =
                takililar.computeIfAbsent(kimlik, k -> new EnumMap<>(Kozmetik.Kategori.class));

        Kozmetik eski = harita.get(kozmetik.kategori());
        if (eski != null) {
            gucKaldir(oyuncu, eski);
        }
        harita.put(kozmetik.kategori(), kozmetik);

        gorunumKaldir(oyuncu, kozmetik.kategori());
        gorunumKur(oyuncu, kozmetik);
        if (kozmetik.kategori().ucucu()) {
            periIsaretiVer(oyuncu);
        }
        gucVer(oyuncu, kozmetik);
        diskeYaz(kimlik);
    }

    public void cikar(Player oyuncu, Kozmetik.Kategori kategori) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(kimlik);
        if (harita == null) {
            return;
        }
        Kozmetik kozmetik = harita.remove(kategori);
        if (kozmetik == null) {
            return;
        }
        gucKaldir(oyuncu, kozmetik);
        gorunumKaldir(oyuncu, kategori);
        if (kategori.ucucu()) {
            periIsaretiAl(oyuncu);
        }
        if (harita.isEmpty()) {
            takililar.remove(kimlik);
        }
        diskeYaz(kimlik);
    }

    /** Giris / respawn / dunya degisimi sonrasi her seyi yeniden kurar. */
    public void yenidenUygula(Player oyuncu) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        tumGucleriKaldir(oyuncu);
        gorunumleriKaldir(oyuncu);
        if (harita == null) {
            return;
        }
        for (Kozmetik kozmetik : harita.values()) {
            gucVer(oyuncu, kozmetik);
            gorunumKur(oyuncu, kozmetik);
            if (kozmetik.kategori().ucucu()) {
                periIsaretiVer(oyuncu);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Gorunum (ItemDisplay)
    // ------------------------------------------------------------------

    private void gorunumKur(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.gorunum-acik", true)) {
            return;
        }
        if (eklenti.golgeGizliMi(oyuncu)) {
            return; // Gorunmezken kozmetik de gorunmez
        }

        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        ItemStack esya = kareEsyasi(kozmetik, 0);

        // Konum her tick konumTazele() tarafindan verilir; burada yalnizca
        // olcek ayarlanir.
        float olcek = (float) eklenti.getConfig().getDouble(yol + "olcek", 1.0);

        Location konum = oyuncu.getLocation().clone();
        konum.setYaw(govdeYonu(oyuncu));
        konum.setPitch(0f);
        try {
            ItemDisplay ekran = oyuncu.getWorld().spawn(konum, ItemDisplay.class, varlik -> {
                varlik.setItemStack(esya);
                varlik.setPersistent(false);
                varlik.setBillboard(Display.Billboard.FIXED);
                // Modelin "fixed" display blogu uygulansin diye baglam FIXED secilir
                varlik.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                varlik.setTransformation(new Transformation(
                        new Vector3f(0f, 0f, 0f),
                        new AxisAngle4f(0f, 0f, 0f, 1f),
                        new Vector3f(olcek, olcek, olcek),
                        new AxisAngle4f(0f, 0f, 0f, 1f)));
                varlik.setViewRange(0.7f);
                varlik.setInterpolationDuration(kozmetik.kategori().ucucu() ? 2 : 0);
                varlik.setTeleportDuration(binisModu() ? 2 : 0);
                varlik.getPersistentDataContainer().set(
                        anahtar("gorunum"), org.bukkit.persistence.PersistentDataType.STRING,
                        kozmetik.kod());
            });
            // Kanat ve peri oyuncuya BINER: konum istemcide oyuncuyla birlikte
            // hesaplanir, bu yuzden hareket ederken titreme/geri kalma olmaz.
            // Peri yalnizca ganimet sandigina giderken serbest birakilir.
            bindir(oyuncu, ekran, kozmetik.kategori());
            gorunumler.computeIfAbsent(oyuncu.getUniqueId(),
                    k -> new EnumMap<>(Kozmetik.Kategori.class)).put(kozmetik.kategori(), ekran.getUniqueId());
            if (kozmetik.kategori() == Kozmetik.Kategori.KANAT) {
                // Peri zaten oyuncudaysa kanadin uzerine tasi (oyuncuda tek yolcu kalsin)
                UUID periKimlik = gorunumler.get(oyuncu.getUniqueId()).get(Kozmetik.Kategori.PERI);
                if (periKimlik != null && Bukkit.getEntity(periKimlik) instanceof ItemDisplay peri
                        && peri.isValid()) {
                    peri.leaveVehicle();
                    bindir(oyuncu, peri, Kozmetik.Kategori.PERI);
                }
            }
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik gorunumu olusturulamadi ("
                    + kozmetik.kod() + "): " + hata.getMessage());
        }
    }

    /**
     * Gorunumu bindirir. Ayni anda hem kanat hem peri takiliysa peri, oyuncuya degil
     * KANAT gorunumune biner: oyuncuya birden fazla yolcu binince gorunumler kayboluyordu.
     * Kanat gorunumu oyuncunun binis noktasinda durdugu icin peri ayni noktadan hesaplanir.
     */
    private void bindir(Player oyuncu, ItemDisplay ekran, Kozmetik.Kategori kategori) {
        if (!binisModu()) {
            serbestPeri.remove(ekran.getUniqueId());
            takip(oyuncu, ekran, 0.0, govdeYonu(oyuncu));
            return;
        }
        org.bukkit.entity.Entity ust = oyuncu;
        if (kategori.ucucu()) {
            Map<Kozmetik.Kategori, UUID> h = gorunumler.get(oyuncu.getUniqueId());
            UUID kanat = h == null ? null : h.get(Kozmetik.Kategori.KANAT);
            org.bukkit.entity.Entity k = kanat == null ? null : Bukkit.getEntity(kanat);
            if (k instanceof ItemDisplay kd && kd.isValid() && kd.getWorld().equals(oyuncu.getWorld())) {
                ust = kd;
            }
        }
        ust.addPassenger(ekran);
    }

    /**
     * Kozmetigin verilen animasyon karesi icin gosterilecek esyayi uretir.
     * Kare 0 ana model, digerleri "_1", "_2" ... son ekli modellerdir.
     */
    private ItemStack kareEsyasi(Kozmetik kozmetik, int kare) {
        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        Material materyal = materyalGetir(
                eklenti.getConfig().getString(yol + "materyal"), kozmetik.varsayilanModel());

        ItemStack esya = new ItemStack(materyal);
        ItemMeta meta = esya.getItemMeta();
        if (meta == null) {
            return esya;
        }
        String modelAnahtari = eklenti.getConfig().getString(yol + "model-anahtari");
        if (modelAnahtari != null && !modelAnahtari.isBlank()) {
            itemModelAyarla(meta, kare > 0 ? modelAnahtari + "_" + kare : modelAnahtari);
        }
        int modelVerisi = eklenti.getConfig().getInt(yol + "model-verisi", 0);
        if (modelVerisi > 0) {
            modelVerisiAyarla(meta, modelVerisi + kare);
        }
        esya.setItemMeta(meta);
        return esya;
    }

    /** Kategoriye gore makul varsayilan yukseklik (oyuncunun sirti hizasi). */
    private float varsayilanYukseklik(Kozmetik kozmetik) {
        return switch (kozmetik.kategori()) {
            // Binen kozmetiklerde deger, binis noktasina gore ofsettir
            case KANAT -> -0.94f;
            // Peri serbest ucar: deger AYAK hizasindan yuksekliktir
            case PERI -> 2.05f;
        };
    }

    private float varsayilanDerinlik(Kozmetik kozmetik) {
        // Arkaya mesafe (negatif = sirta dogru)
        return switch (kozmetik.kategori()) {
            case KANAT -> 0.0625f;
            case PERI -> -0.40f;
        };
    }

    private void gorunumKaldir(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        if (harita == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> kareHaritasi = kareler.get(oyuncu.getUniqueId());
        if (kareHaritasi != null) {
            kareHaritasi.remove(kategori);
        }
        UUID varlikKimligi = harita.remove(kategori);
        if (varlikKimligi != null) {
            serbestPeri.remove(varlikKimligi);
            var varlik = Bukkit.getEntity(varlikKimligi);
            if (varlik != null) {
                varlik.remove();
            }
        }
        if (harita.isEmpty()) {
            gorunumler.remove(oyuncu.getUniqueId());
        }
    }

    public void gorunumleriKaldir(Player oyuncu) {
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            gorunumKaldir(oyuncu, kategori);
        }
        kareler.remove(oyuncu.getUniqueId());
        animFazi.remove(oyuncu.getUniqueId());
        egimi.remove(oyuncu.getUniqueId());
        acilma.remove(oyuncu.getUniqueId());
        govdeYaw.remove(oyuncu.getUniqueId());
        sonBasYaw.remove(oyuncu.getUniqueId());
        donusHizi.remove(oyuncu.getUniqueId());
        govdeOnceki.remove(oyuncu.getUniqueId());
        acilim.remove(oyuncu.getUniqueId());
        sonKonum.remove(oyuncu.getUniqueId());
    }

    /** Cikista peri isaretini de silmek icin dinleyicinin cagirdigi metot. */
    public void oyuncuAyrildi(Player oyuncu) {
        gorunumleriKaldir(oyuncu);
        periIsaretiAl(oyuncu);
    }

    /**
     * Gorunumler olum, dunya degisimi veya chunk bosalmasi gibi durumlarda
     * kopabilir. Bu gorev her saniye kontrol edip eksigi tamamlar.
     */
    public void baslat() {
        durdur();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            sayac++;
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
                if (harita == null || harita.isEmpty()) {
                    continue;
                }
                boolean gizli = eklenti.golgeGizliMi(oyuncu);

                for (Map.Entry<Kozmetik.Kategori, Kozmetik> giris : harita.entrySet()) {
                    if (gizli) {
                        gorunumKaldir(oyuncu, giris.getKey());
                        continue;
                    }
                    gorunumTazele(oyuncu, giris.getKey(), giris.getValue());
                    if (sayac % 2 == 0) {
                        parcacikCal(oyuncu, giris.getValue());
                    }
                }
                // Peri takiliysa isareti canli tut (baska eklenti silmis olabilir)
                if (harita.containsKey(Kozmetik.Kategori.PERI)) {
                    periIsaretiVer(oyuncu);
                }

                // Surekli iksir etkileri
                for (Kozmetik kozmetik : harita.values()) {
                    if (kozmetik.bonus().surekliEtki() != null) {
                        oyuncu.addPotionEffect(new PotionEffect(
                                kozmetik.bonus().surekliEtki(), 60, 0, true, false, false));
                    }
                }
            }
        }, 40L, 20L);

        yonGoreviBaslat();
    }

    private void gorunumTazele(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        UUID varlikKimligi = harita == null ? null : harita.get(kategori);
        if (varlikKimligi != null) {
            var varlik = Bukkit.getEntity(varlikKimligi);
            boolean yerinde = varlik != null && varlik.isValid()
                    && varlik.getWorld().equals(oyuncu.getWorld())
                    && (kategori.ucucu() || !binisModu() || oyuncu.getPassengers().contains(varlik));
            if (yerinde) {
                return; // her sey yolunda
            }
            gorunumKaldir(oyuncu, kategori);
        }
        gorunumKur(oyuncu, kozmetik);
    }

    private void parcacikCal(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.parcacik-acik", true)) {
            return;
        }
        if (kozmetik.parcacik() == null) {
            return;
        }
        try {
            org.bukkit.Particle parcacik =
                    org.bukkit.Particle.valueOf(kozmetik.parcacik().toUpperCase(Locale.ROOT));
            if (parcacik.getDataType() != Void.class) {
                return; // ek veri isteyen parcaciklari atla
            }
            oyuncu.getWorld().spawnParticle(parcacik,
                    oyuncu.getLocation().add(0, 1.0, 0), 4, 0.25, 0.3, 0.25, 0.01);
        } catch (RuntimeException yoksay) {
            // Bu surumde bulunmayan parcacik adi -> sessizce gec
        }
    }

    public void durdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        if (yonGorevi != null) {
            yonGorevi.cancel();
            yonGorevi = null;
        }
    }

    /**
     * Oyuncuya binen ItemDisplay kendi yonunu mount'tan DEVRALMAZ; oyuncu
     * donunce model oldugu yerde kalir ve yanda/onde gorunur. Bu gorev her
     * tick modelin yonunu oyuncunun govde yonune esitler.
     */
    private void yonGoreviBaslat() {
        yonGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                if (gorunumler.containsKey(oyuncu.getUniqueId())) {
                    animasyonIlerlet(oyuncu);
                    konumTazele(oyuncu);
                }
            }
        }, 1L, 1L);
    }

    /**
     * Kanat carpma / pelerin savrulma animasyonu.
     *
     * Hiz arttikca kare degistirme araligi kisalir; oyuncu dururken kanatlar
     * yavasca dinlenme karesine doner. Kareler resourcepack'teki ayri
     * modellerdir, ItemDisplay'in esyasi degistirilerek gecis yapilir.
     */
    private void animasyonIlerlet(Player oyuncu) {
        if (!eklenti.getConfig().getBoolean("kozmetik.animasyon-acik", true)) {
            return;
        }
        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(oyuncu.getUniqueId());
        Map<Kozmetik.Kategori, UUID> ekranlar = gorunumler.get(oyuncu.getUniqueId());
        if (takili == null || ekranlar == null) {
            return;
        }

        UUID kimlik = oyuncu.getUniqueId();
        Location simdi = oyuncu.getLocation();
        Location onceki = sonKonum.put(kimlik, simdi.clone());

        double hiz = 0.0;
        if (onceki != null && onceki.getWorld() != null
                && onceki.getWorld().equals(simdi.getWorld())) {
            hiz = onceki.distance(simdi);
        }
        boolean havada = !oyuncu.isOnGround();
        // Havadayken kanatlar her zaman calisir (suzulme hissi)
        double etki = havada ? Math.max(hiz, 0.16) : hiz;

        double carpan = eklenti.getConfig().getDouble("kozmetik.animasyon-hizi", 1.0);

        Map<Kozmetik.Kategori, Double> fazlar =
                animFazi.computeIfAbsent(kimlik, k -> new EnumMap<>(Kozmetik.Kategori.class));

        for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
            Kozmetik.Kategori kategori = giris.getKey();
            Kozmetik kozmetik = takili.get(kategori);
            if (kozmetik == null) {
                continue;
            }
            int toplam = kategori.kareSayisi();
            if (toplam <= 1) {
                continue;
            }

            if (kategori == Kozmetik.Kategori.KANAT) {
                // Kareler: 0 = tam acik (glb'deki hal), 1..9 = giderek kapanan,
                // 10..12 = yana dogru DAHA GENIS acilan kareler.
                double ilerleme = acilma.getOrDefault(kimlik, 0.0);
                double faz = fazlar.getOrDefault(kategori, 0.0);
                int kare;
                if (ilerleme < 1.0) {
                    double e = ilerleme * ilerleme * (3.0 - 2.0 * ilerleme);
                    kare = (int) Math.round((1.0 - e) * KAPALI_KARE);
                } else {
                    double h = Math.min(1.0, etki * 5.0);
                    // Yuruyunce/kosunca kanatlar yana acilir; durunca yumusakca doner.
                    double a = acilim.merge(kimlik, h, (eski, yeni) -> eski + (yeni - eski) * 0.15);
                    faz += (0.10 + h * 0.20) * carpan;
                    double s = 0.5 + 0.5 * Math.sin(faz);
                    double p = (1.0 - a) * (1.6 * s) - a * (1.0 + 2.0 * s);
                    int q = (int) Math.round(p);
                    kare = q >= 0 ? q : 10 + Math.min(2, -q - 1);
                }
                fazlar.put(kategori, faz);
                kareUygula(oyuncu, kategori, kozmetik, giris.getValue(),
                        Math.max(0, Math.min(toplam - 1, kare)));
                continue;
            }

            // Kare hizi TICK BASINA KARE cinsindendir ve ustten sinirlidir.
            // Sinir olmazsa hizli kosarken birkac kare birden atlanir ve
            // gecis puruzlu gorunur. 0.5 = iki tickte bir kare.
            double taban, tepki, tavan;
            switch (kategori) {
                case KANAT -> { taban = 0.16; tepki = 1.5; tavan = 0.55; }
                // Peri canlidir: oyuncu dursa bile kanat cirpmayi birakmaz
                case PERI -> { taban = 0.50; tepki = 0.8; tavan = 0.85; }
                default -> { taban = 0.0; tepki = 1.9; tavan = 0.42; }
            }

            double hizKare = Math.min(tavan, (taban + etki * tepki) * carpan);

            double faz = fazlar.getOrDefault(kategori, 0.0);
            if (hizKare < 0.012 && kategori != Kozmetik.Kategori.PERI) {
                // Duruyor: pelerin dinlenme karesine yumusakca dogru kayar
                if (faz > 0.05) {
                    faz = Math.max(0.0, faz - 0.25);
                } else {
                    faz = 0.0;
                }
            } else {
                faz = (faz + hizKare) % toplam;
            }
            fazlar.put(kategori, faz);

            kareUygula(oyuncu, kategori, kozmetik, giris.getValue(), (int) faz % toplam);
        }
    }

    /** Gosterilen kare degistiyse ItemDisplay'in esyasini gunceller. */
    private void kareUygula(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik,
                            UUID varlikKimligi, int kare) {
        if (kozmetik == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> harita =
                kareler.computeIfAbsent(oyuncu.getUniqueId(),
                        k -> new EnumMap<>(Kozmetik.Kategori.class));
        Integer mevcut = harita.get(kategori);
        if (mevcut != null && mevcut == kare) {
            return;   // zaten bu karede, bosuna paket gonderme
        }
        var varlik = Bukkit.getEntity(varlikKimligi);
        if (!(varlik instanceof ItemDisplay ekran) || !ekran.isValid()) {
            return;
        }
        ekran.setItemStack(kareEsyasi(kozmetik, kare));
        harita.put(kategori, kare);
    }

    // ------------------------------------------------------------------
    //  PERI: ganimet toplama isareti
    // ------------------------------------------------------------------
    //
    // Ganimet sandiklari CursedValleyMobs eklentisine ait. Iki eklenti
    // birbirine bagimli olmasin diye iletisim tek bir SCOREBOARD ETIKETI
    // uzerinden yapilir: peri takiliyken oyuncuya "cv_peri" etiketi eklenir,
    // mob eklentisi bu etiketi goren sahibin sandigini otomatik bosaltir.

    public static final String PERI_ETIKETI = "cv_peri";

    private void periIsaretiVer(Player oyuncu) {
        if (!oyuncu.getScoreboardTags().contains(PERI_ETIKETI)) {
            oyuncu.addScoreboardTag(PERI_ETIKETI);
        }
    }

    private void periIsaretiAl(Player oyuncu) {
        oyuncu.removeScoreboardTag(PERI_ETIKETI);
    }

    /**
     * Tum kozmetiklerin konumu. Kanat ve peri (omuzdayken) oyuncuya BINER;
     * konum varligin yerel ekseninde verilir. Peri sandiga giderken serbest ucar.
     *
     * Konum, oyuncunun govde yonune gore dondurulmus bir ofsettir:
     *   yana      -> saga (+) / sola (-)
     *   yukseklik -> AYAK hizasindan yukari (blok)
     *   derinlik  -> arkaya (-) / one (+)
     * Boylece oyuncu ne kadar donerse donsun kozmetik hep ayni noktada,
     * sirtta kalir; one savrulmasi ya da yuze girmesi mumkun degildir.
     */
    private void konumTazele(Player oyuncu) {
        Map<Kozmetik.Kategori, UUID> ekranlar = gorunumler.get(oyuncu.getUniqueId());
        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(oyuncu.getUniqueId());
        if (ekranlar == null || takili == null) {
            return;
        }

        // Shift'te govde one yatar ve alcalir; kozmetik de ayni sekilde iner.
        boolean egik = oyuncu.isSneaking();
        double egimFazi = egimi.merge(oyuncu.getUniqueId(),
                egik ? 0.18 : -0.18, (a, b) -> Math.max(0.0, Math.min(1.0, a + b)));

        govdeGuncelle(oyuncu);
        float yon = govdeYonu(oyuncu);
        double rad = Math.toRadians(yon);
        double sin = Math.sin(rad), cos = Math.cos(rad);

        for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
            Kozmetik.Kategori kategori = giris.getKey();
            Kozmetik kozmetik = takili.get(kategori);
            if (kozmetik == null) {
                continue;
            }
            var varlik = Bukkit.getEntity(giris.getValue());
            if (!(varlik instanceof ItemDisplay ekran) || !ekran.isValid()) {
                continue;
            }

            if (!binisModu() && !serbestPeri.contains(giris.getValue())) {
                takip(oyuncu, ekran, egimFazi, yon);
            }

            String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
            double yana = eklenti.getConfig().getDouble(yol + "yana",
                    kategori.ucucu() ? 0.45 : 0.0);
            double yukseklik = eklenti.getConfig().getDouble(
                    yol + "yukseklik", varsayilanYukseklik(kozmetik));
            double derinlik = eklenti.getConfig().getDouble(
                    yol + "derinlik", varsayilanDerinlik(kozmetik));
            float olcek = (float) eklenti.getConfig().getDouble(yol + "olcek", 1.0);

            if (kategori.ucucu()) {
                periUcur(oyuncu, ekran, yana, yukseklik, derinlik, olcek,
                        egimFazi, yon, sin, cos);
                continue;
            }

            // Binen kozmetik: konum, varligin KENDI ekseninde verilir. Dunya
            // isinlanmasi kullanilmaz; oyuncuya bindigi icin zaten onunla
            // birlikte hareket eder ve asla geride kalmaz.
            // Kanat; shift'e basinca ya da elytra TAKILIYKEN kapanip kaybolur,
            // islem bitince (shift birakildi / elytra cikarildi) yeniden acilir.
            boolean gizle = egik || elytraTakili(oyuncu);
            double ilerleme = acilma.merge(oyuncu.getUniqueId(),
                    gizle ? -1.0 / KAPANMA_TICK : 1.0 / ACILMA_TICK,
                    (eski, d) -> Math.max(0.0, Math.min(1.0, eski + d)));

            if (ilerleme <= 0.0) {
                // Tamamen kapali: gorunmez (olcek 0)
                ekran.setInterpolationDelay(0);
                ekran.setInterpolationDuration(0);
                ekran.setTransformation(new Transformation(
                        new Vector3f(0f, 0f, 0f),
                        new AxisAngle4f(0f, 0f, 1f, 0f),
                        new Vector3f(0f, 0f, 0f),
                        new AxisAngle4f(0f, 0f, 0f, 1f)));
                continue;
            }

            // Yon her tick govde yonune esitlenir (esik yok, gecikme yok).
            if (Math.abs(ekran.getLocation().getYaw() - yon) > 0.01f) {
                ekran.setRotation(yon, 0f);
            }

            // Acilma/kapanma kare modelleriyle yapilir (bkz. animasyonIlerlet);
            // burada olcek sabittir, yalnizca tam kapaliyken gizlenir.
            ekran.setInterpolationDelay(0);
            ekran.setInterpolationDuration(2);
            ekran.setTransformation(new Transformation(
                    new Vector3f((float) yana, (float) yukseklik, (float) derinlik),
                    new AxisAngle4f(0f, 1f, 0f, 0f),
                    new Vector3f(olcek, olcek, olcek),
                    new AxisAngle4f(0f, 0f, 0f, 1f)));
        }
    }

    /**
     * Perinin ucusu.
     *
     * Omuzdayken peri oyuncuya BINER ve yalnizca yerel konumu (hafif inip
     * cikma) degistirilir; istemci konumu oyuncuyla birlikte kendisi
     * hesapladigi icin yururken/kosarken titreme olmaz.
     *
     * Yakinda ganimet sandigi varsa peri binisten inip serbest ucar, sandiga
     * gider; sandik toplanip yok olunca ayni hizla omza geri doner ve tekrar
     * oyuncuya biner.
     */
    private static final double OYUNCU_BOYU = 1.8;

    private void periUcur(Player oyuncu, ItemDisplay ekran, double yana,
                          double yukseklik, double derinlik, float olcek,
                          double egimFazi, float yon, double sin, double cos) {
        double faz = oyuncu.getTicksLived() * 0.09
                + (Math.abs(oyuncu.getUniqueId().hashCode()) % 100) * 0.06;
        double salinim = Math.sin(faz) * 0.07;

        Location sandik = sandikNoktasi(oyuncu);
        boolean biniyor = binisModu() ? ekran.getVehicle() != null
                : !serbestPeri.contains(ekran.getUniqueId());

        // ------ OMUZDA (binen) ------
        if (biniyor && sandik == null) {
            if (Math.abs(ekran.getLocation().getYaw() - yon) > 0.01f) {
                ekran.setRotation(yon, 0f);
            }
            ekran.setInterpolationDelay(0);
            ekran.setInterpolationDuration(2);
            // Binis noktasi oyuncunun boyundadir (ayakta 1.8, shift'te kendiliginden
            // alcalir); degerler AYAK hizasindan yukseklige gore ayarlidir.
            ekran.setTransformation(new Transformation(
                    new Vector3f((float) -yana, (float) (yukseklik - OYUNCU_BOYU + salinim), (float) derinlik),
                    new AxisAngle4f(0f, 0f, 1f, 0f),
                    new Vector3f(olcek, olcek, olcek),
                    new AxisAngle4f(0f, 0f, 0f, 1f)));
            return;
        }

        // Omzun dunya konumu (serbest ucus icin hedef / baslangic)
        Location omuz = oyuncu.getLocation().clone().add(
                -yana * cos - derinlik * sin,
                yukseklik + salinim - egimFazi * 0.30,
                -yana * sin + derinlik * cos);

        // ------ SANDIGA GIDIS: binisten in ------
        if (biniyor) {
            if (binisModu()) {
                ekran.leaveVehicle();
            } else {
                serbestPeri.add(ekran.getUniqueId());
            }
            ekran.teleport(omuz);       // omuzdan kalksin
            ekran.setInterpolationDelay(0);
            ekran.setInterpolationDuration(0);
            ekran.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 1f, 0f),
                    new Vector3f(olcek, olcek, olcek),
                    new AxisAngle4f(0f, 0f, 0f, 1f)));
            return;
        }

        // ------ SERBEST UCUS ------
        Location hedef = sandik != null ? sandik : omuz;
        Location simdi = ekran.getLocation();

        if (!simdi.getWorld().equals(hedef.getWorld())
                || simdi.distanceSquared(hedef) > 3600) {
            ekran.teleport(omuz);       // dunya degisti / cok uzak -> omza isinla
            if (sandik == null) {
                bindir(oyuncu, ekran, Kozmetik.Kategori.PERI);
            }
            return;
        }

        if (sandik == null && simdi.distanceSquared(omuz) < 0.09) {
            // Omza ulasti -> tekrar oyuncuya bin
            ekran.setTeleportDuration(0);
            omuz.setYaw(yon);
            omuz.setPitch(0f);
            ekran.teleport(omuz);
            bindir(oyuncu, ekran, Kozmetik.Kategori.PERI);
            return;
        }

        // Ayni hizda suzulme (gidis ve donus ayni hiz). Birden fazla sandik
        // varsa hedef hep EN YAKINI oldugu icin hepsi sirayla toplanir.
        var fark = hedef.toVector().subtract(simdi.toVector());
        double uzaklik = fark.length();
        if (uzaklik > 0.05) {
            double hiz = eklenti.getConfig().getDouble("kozmetik.peri-hizi", 0.40);
            var adim = fark.normalize().multiply(Math.min(hiz, uzaklik));
            Location yeniKonum = simdi.clone().add(adim);

            float istenen = (float) Math.toDegrees(Math.atan2(-adim.getX(), adim.getZ()));
            float mevcut = simdi.getYaw();
            float fark2 = istenen - mevcut;
            while (fark2 > 180f) fark2 -= 360f;
            while (fark2 < -180f) fark2 += 360f;
            yeniKonum.setYaw(mevcut + fark2 * 0.30f);
            yeniKonum.setPitch(0f);

            ekran.setTeleportDuration(1);
            ekran.teleport(yeniKonum);
        }
    }

    /**
     * Oyuncunun yakinindaki ganimet sandigini bulur. Sandiklar mob eklentisi
     * tarafindan "cv_loot" scoreboard etiketiyle isaretlenir ve sahibi
     * disindaki oyunculardan gizlenir; bu yuzden ayrica sahiplik kontrolu
     * gerekmez, gorunmeyen sandik zaten yakinda sayilmaz.
     */
    private Location sandikNoktasi(Player oyuncu) {
        if (!eklenti.getConfig().getBoolean("kozmetik.peri-toplama", true)) {
            return null;
        }
        double menzil = eklenti.getConfig().getDouble("kozmetik.peri-menzili", 14.0);
        Location en = null;
        double enYakin = menzil * menzil;
        for (var varlik : oyuncu.getNearbyEntities(menzil, menzil * 0.6, menzil)) {
            if (!varlik.getScoreboardTags().contains("cv_loot")) {
                continue;
            }
            double d = varlik.getLocation().distanceSquared(oyuncu.getLocation());
            if (d < enYakin) {
                enYakin = d;
                en = varlik.getLocation().clone().add(0, 0.75, 0);
            }
        }
        return en;
    }

    /** Oyuncu -> shift egiminin yumusatilmis degeri (0 = dik, 1 = tam egik) */
    private final Map<UUID, Double> egimi = new HashMap<>();

    /** Kanat acilma ilerlemesi (0 = kapali/gorunmez, 1 = tam acik). */
    private final Map<UUID, Double> acilma = new HashMap<>();
    /** Yurume/kosma ile kanatlarin yana acilma miktari (0..1, yumusatilmis). */
    private final Map<UUID, Double> acilim = new HashMap<>();
    /** Kapali kanat karesi (kare 0 = acik ... 9 = tam kapali). */
    private static final int KAPALI_KARE = 9;
    private static final double ACILMA_TICK = 12.0;
    private static final double KAPANMA_TICK = 8.0;

    /** Gogusluk yerine elytra giyiliyse kanat gizlenir. */
    private boolean elytraTakili(Player oyuncu) {
        ItemStack gogus = oyuncu.getInventory().getChestplate();
        return gogus != null && gogus.getType() == Material.ELYTRA;
    }

    /**
     * Oyuncunun GOVDE yonu. Bas yonu kullanilirsa kanatlar saga sola bakinca
     * savruluyor; Paper'da getBodyYaw varsa o tercih edilir.
     */
    private float govdeYonu(Player oyuncu) {
        Float kayitli = govdeYaw.get(oyuncu.getUniqueId());
        return kayitli != null ? kayitli : oyuncu.getLocation().getYaw();
    }

    // Oyuncunun govde yonu: istemcinin kendi modeli icin hesapladigi yonun AYNISI
    // (vanilla LivingEntity.tickHeadTurn) sunucuda her tick yeniden hesaplanir.
    // Ek olarak, dondurme hizina gore ping kadar ileriye tahmin edilir; boylece
    // hizli donuste kanat gecikmeden govdenin arkasinda kalir.
    private final Map<UUID, Float> govdeYaw = new HashMap<>();
    private final Map<UUID, Float> sonBasYaw = new HashMap<>();
    private final Map<UUID, Float> donusHizi = new HashMap<>();
    private final Map<UUID, Location> govdeOnceki = new HashMap<>();

    private static float sar(float derece) {
        float d = derece % 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    private void govdeGuncelle(Player oyuncu) {
        UUID kimlik = oyuncu.getUniqueId();
        Location simdi = oyuncu.getLocation();
        float bas = simdi.getYaw();
        Float eskiBody = govdeYaw.get(kimlik);
        float body = eskiBody != null ? eskiBody : bas;

        // Bas donus hizi (yumusatilmis) -> ping kadar ileri tahmin. Kanat yonunu
        // sunucu gonderdigi icin, tahmin olmazsa donerken ping kadar geride kalir.
        Float eskiBas = sonBasYaw.put(kimlik, bas);
        float omega = eskiBas == null ? 0f : sar(bas - eskiBas);
        float ort = donusHizi.merge(kimlik, omega, (eski, yeni) -> eski * 0.5f + yeni * 0.5f);
        float carpanT = (float) eklenti.getConfig().getDouble("kozmetik.donus-tahmini", 1.0);
        float ileri = 1f;
        try {
            ileri += oyuncu.getPing() / 50f;
        } catch (RuntimeException | NoSuchMethodError yoksay) {
            // ping okunamadi
        }
        ileri = Math.max(1f, Math.min(6f, ileri)) * carpanT;
        float tahminBas = bas + Math.max(-70f, Math.min(70f, ort * ileri));

        // Hareket yonu
        Location onceki = govdeOnceki.put(kimlik, simdi.clone());
        float hedef = body;
        if (onceki != null && onceki.getWorld() != null && onceki.getWorld().equals(simdi.getWorld())) {
            double dx = simdi.getX() - onceki.getX();
            double dz = simdi.getZ() - onceki.getZ();
            if (dx * dx + dz * dz > 0.0025) {
                float yonH = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                float f4 = Math.abs(((bas % 360f) + 360f) % 360f - ((yonH % 360f) + 360f) % 360f);
                hedef = (95f < f4 && f4 < 265f) ? yonH - 180f : yonH;
            }
        }
        body += sar(hedef - body) * 0.3f;

        // Govde, basin +-75 derece disina cikamaz
        float f5 = sar(tahminBas - body);
        if (f5 < -75f) f5 = -75f;
        if (f5 >= 75f) f5 = 75f;
        body = tahminBas - f5;
        if (f5 * f5 > 2500f) body += f5 * 0.2f;

        govdeYaw.put(kimlik, body);
    }

    /** Sunucu kapanirken / oyuncu cikarken artik varlik birakmamak icin. */
    public void hepsiniTemizle() {
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            gorunumleriKaldir(oyuncu);
            tumGucleriKaldir(oyuncu);
            periIsaretiAl(oyuncu);
        }
        gorunumler.clear();
        kareler.clear();
        animFazi.clear();
        egimi.clear();
        sonKonum.clear();
    }

    // ------------------------------------------------------------------
    //  Guc (attribute)
    // ------------------------------------------------------------------

    private void gucVer(Player oyuncu, Kozmetik kozmetik) {
        Kozmetik.Bonus bonus = kozmetik.bonus();
        String ek = kozmetik.kategori().kod();

        ekle(oyuncu, MAX_CAN, "can_" + ek, bonus.maxCan(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, HAREKET_HIZI, "hiz_" + ek, bonus.hizYuzde(), AttributeModifier.Operation.ADD_SCALAR);
        ekle(oyuncu, ZIRH, "zirh_" + ek, bonus.zirh(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek, bonus.zirhSaglamlik(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek, bonus.geriTepme(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, SALDIRI_HASARI, "hasar_" + ek, bonus.saldiriHasari(), AttributeModifier.Operation.ADD_NUMBER);
    }

    private void gucKaldir(Player oyuncu, Kozmetik kozmetik) {
        String ek = kozmetik.kategori().kod();
        kaldir(oyuncu, MAX_CAN, "can_" + ek);
        kaldir(oyuncu, HAREKET_HIZI, "hiz_" + ek);
        kaldir(oyuncu, ZIRH, "zirh_" + ek);
        kaldir(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek);
        kaldir(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek);
        kaldir(oyuncu, SALDIRI_HASARI, "hasar_" + ek);
        canDuzelt(oyuncu);
    }

    /** Oyuncudaki TUM kozmetik_ modifier'larini siler (sinif yeteneklerine dokunmaz). */
    public void tumGucleriKaldir(Player oyuncu) {
        Attribute[] hepsi = {MAX_CAN, HAREKET_HIZI, ZIRH, ZIRH_SAGLAMLIGI,
                GERI_TEPME_DIRENCI, SALDIRI_HASARI};
        Set<String> silinen = new HashSet<>();
        for (Attribute attribute : hepsi) {
            if (attribute == null) {
                continue;
            }
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                continue;
            }
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                NamespacedKey k = mod.getKey();
                if (k != null && k.getNamespace().equals(anahtar("x").getNamespace())
                        && k.getKey().startsWith("kozmetik_")) {
                    ornek.removeModifier(mod);
                    silinen.add(k.getKey());
                }
            }
        }
        if (!silinen.isEmpty()) {
            canDuzelt(oyuncu);
        }
    }

    private void ekle(Player oyuncu, Attribute attribute, String ad, double miktar,
                      AttributeModifier.Operation islem) {
        if (attribute == null || miktar == 0) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mevcut : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mevcut.getKey())) {
                    ornek.removeModifier(mevcut);
                }
            }
            ornek.addModifier(new AttributeModifier(k, miktar, islem, EquipmentSlotGroup.ANY));
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik attribute eklenemedi (" + ad + "): " + hata.getMessage());
        }
    }

    private void kaldir(Player oyuncu, Attribute attribute, String ad) {
        if (attribute == null) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mod.getKey())) {
                    ornek.removeModifier(mod);
                }
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    /** Max can dustuyse mevcut cani tasirmamak icin kirpar. */
    private void canDuzelt(Player oyuncu) {
        try {
            if (MAX_CAN == null) {
                return;
            }
            AttributeInstance ornek = oyuncu.getAttribute(MAX_CAN);
            if (ornek != null && oyuncu.getHealth() > ornek.getValue()) {
                oyuncu.setHealth(Math.max(1.0, ornek.getValue()));
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    // ------------------------------------------------------------------
    //  Yardimcilar
    // ------------------------------------------------------------------

    private Material materyalGetir(String ad, Material varsayilan) {
        if (ad == null || ad.isBlank()) {
            return varsayilan;
        }
        Material materyal = Material.matchMaterial(ad.toUpperCase(Locale.ROOT));
        return materyal == null ? varsayilan : materyal;
    }

    /** ItemMeta#setItemModel surum farkliliklarina karsi reflection ile cagrilir. */
    private void itemModelAyarla(ItemMeta meta, String anahtarMetni) {
        try {
            NamespacedKey k = NamespacedKey.fromString(anahtarMetni.toLowerCase(Locale.ROOT));
            if (k == null) {
                return;
            }
            meta.getClass().getMethod("setItemModel", NamespacedKey.class).invoke(meta, k);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde item-model bilesenin yok -> model-verisi kullanilsin
        }
    }

    /** setCustomModelData(Integer) surumden bagimsiz cagrilir. */
    private void modelVerisiAyarla(ItemMeta meta, int deger) {
        try {
            meta.getClass().getMethod("setCustomModelData", Integer.class).invoke(meta, deger);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // gec
        }
    }
}
