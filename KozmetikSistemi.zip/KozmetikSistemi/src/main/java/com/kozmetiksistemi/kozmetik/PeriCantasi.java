package com.kozmetiksistemi.kozmetik;

import com.kozmetiksistemi.KozmetikSistemi;
import com.kozmetiksistemi.Mesaj;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Peri cantasi: 8 slotluk, oyuncuya ozel. Peri, oyuncunun envanteri doluyken topladigi
 * esyalari buraya koyar; oyuncu /fairy ile acip alir.
 */
public final class PeriCantasi implements Listener, CommandExecutor, TabCompleter {

    private static final int SLOT = 8;       // kullanilabilir slot (0..7); 8. yuva kilitli

    private final KozmetikSistemi eklenti;
    private final KozmetikYoneticisi yonetici;
    private final File dosya;
    private final YamlConfiguration veri;
    private final Map<UUID, Inventory> cantalar = new HashMap<>();

    public static final class Tutucu implements InventoryHolder {
        private Inventory env;

        @Override
        public Inventory getInventory() {
            return env;
        }
    }

    public PeriCantasi(KozmetikSistemi eklenti, KozmetikYoneticisi yonetici) {
        this.eklenti = eklenti;
        this.yonetici = yonetici;
        this.dosya = new File(eklenti.getDataFolder(), "periCantasi.yml");
        this.veri = YamlConfiguration.loadConfiguration(dosya);
    }

    private ItemStack kilit() {
        ItemStack e = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta m = e.getItemMeta();
        m.displayName(Mesaj.esya("<dark_gray>Kilitli"));
        e.setItemMeta(m);
        return e;
    }

    private boolean kilitMi(ItemStack e) {
        return e != null && e.getType() == Material.BLACK_STAINED_GLASS_PANE && e.hasItemMeta()
                && e.getItemMeta().hasDisplayName();
    }

    private Inventory canta(UUID kimlik) {
        return cantalar.computeIfAbsent(kimlik, k -> {
            Tutucu t = new Tutucu();
            t.env = Bukkit.createInventory(t, 9, Mesaj.esya("<light_purple><bold>Peri Çantası <dark_gray>(8 slot)"));
            for (int i = 0; i < SLOT; i++) {
                ItemStack e = veri.getItemStack("oyuncular." + k + "." + i);
                if (e != null) {
                    t.env.setItem(i, e);
                }
            }
            t.env.setItem(SLOT, kilit());
            return t.env;
        });
    }

    private void kaydet(UUID kimlik, Inventory env) {
        for (int i = 0; i < SLOT; i++) {
            veri.set("oyuncular." + kimlik + "." + i, env.getItem(i));
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().warning("periCantasi.yml kaydedilemedi: " + hata.getMessage());
        }
    }

    /** Esyayi peri cantasina koyar. Sigmayan kisim dondurulur. */
    public List<ItemStack> ekle(Player oyuncu, ItemStack esya) {
        Inventory env = canta(oyuncu.getUniqueId());
        List<ItemStack> kalan = new ArrayList<>(env.addItem(esya).values());
        kaydet(oyuncu.getUniqueId(), env);
        return kalan;
    }

    public boolean perisiVar(Player oyuncu) {
        for (Kozmetik k : Kozmetik.values()) {
            if (k.kategori() == Kozmetik.Kategori.PERI && yonetici.acikMi(oyuncu, k)) {
                return true;
            }
        }
        return false;
    }

    public void ac(Player oyuncu) {
        oyuncu.openInventory(canta(oyuncu.getUniqueId()));
    }

    @Override
    public boolean onCommand(CommandSender g, Command k, String e, String[] a) {
        if (!(g instanceof Player oyuncu)) {
            g.sendMessage("Bu komut yalnizca oyunculara ozeldir.");
            return true;
        }
        if (!oyuncu.hasPermission("kozmetik.kullan")) {
            Mesaj.gonder(oyuncu, "yetkin-yok");
            return true;
        }
        if (!perisiVar(oyuncu)) {
            oyuncu.sendMessage(Mesaj.ayristir("<red>Peri çantası yalnızca perisi olan oyunculara özeldir."));
            return true;
        }
        ac(oyuncu);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender g, Command k, String e, String[] a) {
        return List.of();
    }

    // ------------------------------------------------------------ olaylar

    @EventHandler(priority = EventPriority.LOWEST)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof Tutucu)) {
            return;
        }
        // kilitli yuvaya hicbir sey konmaz / alinmaz
        if (olay.getClickedInventory() == olay.getView().getTopInventory() && olay.getSlot() >= SLOT) {
            olay.setCancelled(true);
            return;
        }
        if (kilitMi(olay.getCurrentItem()) || kilitMi(olay.getCursor())
                || (olay.getClick() == org.bukkit.event.inventory.ClickType.NUMBER_KEY
                && olay.getClickedInventory() == olay.getView().getTopInventory() && olay.getSlot() >= SLOT)) {
            olay.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void surukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof Tutucu
                && olay.getRawSlots().contains(SLOT)) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void kapandi(InventoryCloseEvent olay) {
        if (olay.getInventory().getHolder() instanceof Tutucu && olay.getPlayer() instanceof Player p) {
            kaydet(p.getUniqueId(), olay.getInventory());
        }
    }

    /** Tiklama bitince (bir tik sonra) kaydet: sunucu cokerse esya kaybolmasin. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void tiklaSonra(InventoryClickEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof Tutucu
                && olay.getWhoClicked() instanceof Player p) {
            Bukkit.getScheduler().runTask(eklenti, () -> kaydet(p.getUniqueId(), olay.getView().getTopInventory()));
        }
    }
}
