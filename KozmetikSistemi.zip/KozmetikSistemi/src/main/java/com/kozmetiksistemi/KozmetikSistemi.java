package com.kozmetiksistemi;

import com.kozmetiksistemi.kozmetik.KozmetikDinleyici;
import com.kozmetiksistemi.kozmetik.KozmetikKomutu;
import com.kozmetiksistemi.kozmetik.KozmetikYoneticisi;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * KozmetikSistemi - kanat ve peri kozmetikleri.
 * ClassAndRegion eklentisinden bagimsiz calisir; ClassAndRegion varsa yalnizca
 * Golge Pelerini ile gizlenen oyuncunun kozmetiklerini de gizler
 * ("cv_golge" scoreboard etiketi uzerinden).
 */
public final class KozmetikSistemi extends JavaPlugin {

    /** ClassAndRegion Golge Pelerini aktifken oyuncuya bu etiketi ekler. */
    public static final String GOLGE_ETIKETI = "cv_golge";

    private KozmetikYoneticisi kozmetikYoneticisi;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Mesaj.baslat(this);

        this.kozmetikYoneticisi = new KozmetikYoneticisi(this);
        this.kozmetikYoneticisi.baslat();

        Bukkit.getPluginManager().registerEvents(
                new KozmetikDinleyici(this, kozmetikYoneticisi), this);

        komutKaydet("kozmetik", new KozmetikKomutu(this, kozmetikYoneticisi, false));
        komutKaydet("kozmetikyonetim", new KozmetikKomutu(this, kozmetikYoneticisi, true));

        // Reload sonrasi cevrimici oyunculara kozmetikleri geri ver
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            kozmetikYoneticisi.yenidenUygula(oyuncu);
        }

        getLogger().info("KozmetikSistemi etkinlestirildi.");
    }

    @Override
    public void onDisable() {
        if (kozmetikYoneticisi != null) {
            kozmetikYoneticisi.durdur();
            kozmetikYoneticisi.hepsiniTemizle();
            kozmetikYoneticisi.kaydet();
        }
    }

    /** Oyuncu gorunmez mu? (Golge Pelerini ya da herhangi bir gorunmezlik efekti) */
    public boolean golgeGizliMi(Player oyuncu) {
        if (oyuncu == null) {
            return false;
        }
        // Her turlu gorunmezlik: Golge Pelerini etiketi VEYA iksir/efekt gorunmezligi
        return oyuncu.getScoreboardTags().contains(GOLGE_ETIKETI)
                || oyuncu.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY);
    }

    private <T extends CommandExecutor & TabCompleter> void komutKaydet(String ad, T calistirici) {
        PluginCommand komut = getCommand(ad);
        if (komut == null) {
            getLogger().severe("Komut bulunamadi: " + ad);
            return;
        }
        komut.setExecutor(calistirici);
        komut.setTabCompleter(calistirici);
    }

    public KozmetikYoneticisi getKozmetikYoneticisi() {
        return kozmetikYoneticisi;
    }
}
